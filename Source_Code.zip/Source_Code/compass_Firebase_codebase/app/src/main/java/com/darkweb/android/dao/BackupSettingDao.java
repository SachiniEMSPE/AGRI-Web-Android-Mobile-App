package com.darkweb.android.dao;

import android.content.Context;
import android.widget.Toast;

import com.darkweb.android.model.User;
import com.darkweb.android.service.CryptoUtilServices;

import java.io.File;
import java.util.ArrayList;

public class BackupSettingDao {

    public void writeFilesToFirebase(Context context, User user, ArrayList<File> fileArrayList) {

        CryptoUtilServices cryptoUtilServices = new CryptoUtilServices();
        String key=user.getUserUID();
        for( File f :fileArrayList)
        {
           if(f.exists())
           {
               String url = context.getFilesDir().toString();
               File encryptedFile = new File(url,f.getName()+".enc");
               cryptoUtilServices.encrypt(key,f,encryptedFile);
               if(encryptedFile.exists()) {
                   //fileReference.putFile(Uri.fromFile(encryptedFile));
                   encryptedFile.delete();
                   Toast.makeText(context, "Backed up successfully", Toast.LENGTH_LONG);
               }
           }

        }
    }
}
