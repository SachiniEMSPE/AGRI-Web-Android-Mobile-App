package com.darkweb.android.adapter;

import android.content.Context;
import android.os.Build;
//import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.compass.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import androidx.annotation.*;


public class AndroidListAdapter extends ArrayAdapter<CalandarEvent> {

	private final Context context;
	private final ArrayList<CalandarEvent> values;
	private final SimpleDateFormat df;
	private ViewHolder viewHolder;
	private final int resourceId;

	public AndroidListAdapter(Context context, int resourceId,ArrayList<CalandarEvent> values) {
		super(context, resourceId, values);

		String pattern = "EEEE MM/dd/yyyy hh:mm a";
		 df = new SimpleDateFormat(pattern);
		//df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

		this.context = context;
		this.values = values;
		this.resourceId = resourceId;
	}




	@RequiresApi(api = Build.VERSION_CODES.M)
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(resourceId, parent, false);


			viewHolder = new ViewHolder();
			viewHolder.tv_date = (TextView) convertView.findViewById(R.id.tv_date);
			viewHolder.tv_event = (TextView) convertView.findViewById(R.id.tv_event);


			convertView.setTag(viewHolder);


		}else
		{
			viewHolder = (ViewHolder) convertView.getTag();
		}
		CalandarEvent list_obj=values.get(position);
		viewHolder.tv_date.setText(df.format(list_obj.getEventDateTime()));

		if(list_obj.getEventDateTime().compareTo(new Date()) < 0) {
			viewHolder.tv_date.setTextColor(context.getColor(R.color.grey_color));
			viewHolder.tv_event.setTextColor(context.getColor(R.color.grey_color));
		//rowView.setBackgroundColor(context.getColor(R.color.grey_color));
		}
		else
		{
			viewHolder.tv_date.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
			viewHolder.tv_event.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
		}
		//viewHolder.tv_event.setText(list_obj.getEventDescription());

		viewHolder.tv_event.setText(list_obj.getEventName());

		return convertView;
	}
	public class ViewHolder {

		TextView tv_event;
		TextView tv_date;

	}

}
