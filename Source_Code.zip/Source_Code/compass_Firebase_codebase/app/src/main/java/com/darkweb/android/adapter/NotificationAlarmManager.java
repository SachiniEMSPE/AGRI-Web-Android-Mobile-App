package com.darkweb.android.adapter;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.compass.R;
import com.darkweb.android.service.MinMaxFilter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/**
 * Created by kotak on 23/07/2018.
 */
public class NotificationAlarmManager  {
    SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm");

    public void addAlarmManager(int requestCode, Date date , Context context, UUID uuid, String objectType)
    {

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        Intent notificationIntent = new Intent(context, AlarmReceiver.class);
        notificationIntent.putExtra(context.getString(R.string.ObjectType),objectType);
        notificationIntent.putExtra(context.getString(R.string.id),uuid);
        PendingIntent broadcast = PendingIntent.getBroadcast(context, 100, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.SECOND, 1);

        Log.d("time:",date.getTime()+" d:"+date+" time:"+new Date().getTime()+" d:"+new Date());
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, date.getTime(), broadcast);


        //Toast.makeText(context, "Notification Added", Toast.LENGTH_SHORT).show();

    }

    public void cancelAlarmManager(int requestCode, Context context)
    {
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pendingIntent=null;
        if (intent!=null)
        pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, 0);
        AlarmManager alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager!=null && pendingIntent!=null)
        alarmManager.cancel(pendingIntent);
    }


    public static void addNotificationEventCalendarServiceDetails(Context context, ServiceDetails serviceDetails, EditText addNotificationDays,TextView addReminderTextView)
    {
        Date expectingDateandTime,serviceDate;
        Calendar myCalendar1 = Calendar.getInstance();
        Dialog customNotificationDialogue=new Dialog(context);
        customNotificationDialogue.setContentView(R.layout.custom_notificcation_dialogue_layout);

        customNotificationDialogue.setTitle("Custom Notifications : ");
        int width = (int)(context.getResources().getDisplayMetrics().widthPixels*0.90);
        customNotificationDialogue.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);

        EditText digitEditText = (EditText) customNotificationDialogue.findViewById(R.id.add_time_digits);
        TextView notificationDateAndTime=(TextView) customNotificationDialogue.findViewById(R.id.date_time_text_view);
        TextView addReminderCalendartextview = (TextView) customNotificationDialogue.findViewById(R.id.add_reminder_calendar_text_view);
        Button dialog_submit= (Button) customNotificationDialogue.findViewById(R.id.dialog_submit);
        ArrayList<CheckBox> arrayCheckBox=new ArrayList<CheckBox>();
        arrayCheckBox.add(customNotificationDialogue.findViewById(R.id.minutes_checkox));
        arrayCheckBox.add(customNotificationDialogue.findViewById(R.id.hours_checkox));
        arrayCheckBox.add(customNotificationDialogue.findViewById(R.id.days_checkox));

        serviceDate=new Date(serviceDetails.getExpectingServiceDate() + " " + serviceDetails.getExpectingtime().replaceAll("\\s+", ""));

        long diff=0;
        if(serviceDetails.getRemindarDate()!=null && !serviceDetails.getRemindarDate().isEmpty() && serviceDetails.getRemindarTime()!=null && !serviceDetails.getRemindarTime().isEmpty())
        {

            //new NotificationAlarmManager().cancelAlarmManager(serviceDetails.getRequestCode(),context); sach commented and updated as below
            new NotificationAlarmManager().cancelAlarmManager((int) serviceDetails.getRequestUID().getLeastSignificantBits(),context);
            expectingDateandTime=new Date(serviceDetails.getRemindarDate() + " " + serviceDetails.getRemindarTime().replaceAll("\\s+", ""));
            myCalendar1.setTime(expectingDateandTime);
            Log.d("reminderTime:",expectingDateandTime.toString());
            diff=(serviceDate.getTime()-expectingDateandTime.getTime());
            Log.d("diff:",diff+"");



        }
        else {
            //serviceDate = new Date(serviceDetails.getExpectingServiceDate() + " " + serviceDetails.getExpectingtime().replaceAll("\\s+", ""));
            expectingDateandTime=serviceDate;
            myCalendar1.setTime(serviceDate);
            diff = serviceDate.getTime() - new Date().getTime();
        }
        int index=-1;


            if(diff >=(24 * 60 * 60 * 1000) ) {
          //      arrayCheckBox.get(3).setEnabled(false);
                if(serviceDetails.getRemindarDate()==null || serviceDetails.getRemindarTime()==null)
                {
                    digitEditText.setText("1");
                    myCalendar1.add(Calendar.DATE, -1);
                }
                else {
                    digitEditText.setText(""+(diff)/(24 * 60 * 60 * 1000));
                }
                index=2;
                digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", "7")});
            }
            else if(diff>=(60 * 60 * 1000) && diff<= (24*60*60*1000))
            {
                arrayCheckBox.get(2).setEnabled(false);
           //     arrayCheckBox.get(3).setEnabled(false);
                index=1;
                if(serviceDetails.getRemindarDate()==null || serviceDetails.getRemindarTime()==null)
                {
                    digitEditText.setText("1");
                    myCalendar1.add(Calendar.HOUR ,-1);
                }
                else {
                    digitEditText.setText(""+(diff)/( 60 * 60 * 1000));
                }
                digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", "23")});
            }
            else if(diff>=(60*1000) && diff<(60*60*1000)) {
                arrayCheckBox.get(2).setEnabled(false);
                arrayCheckBox.get(1).setEnabled(false);

                index=0;
                if(serviceDetails.getRemindarDate()==null || serviceDetails.getRemindarTime()==null)
                {
                    digitEditText.setText("10");
                    myCalendar1.add(Calendar.MINUTE, 10);
                }
                else {
                    digitEditText.setText(""+(diff)/(60 * 1000));
                }
                digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", "59")});

            }
            else {
                digitEditText.setEnabled(false);
                for(CheckBox ch:arrayCheckBox)
                {
                    if(ch.isChecked())
                        ch.setText(ch.getText().toString().replace("before",""));
                    ch.setChecked(false);
                    ch.setEnabled(false);
                    notificationDateAndTime.setText("Can not set reminder:");
                }
            }
        if(index>=0)
        {
            unCheckedOtherCheckBox(arrayCheckBox,arrayCheckBox.get(index),context);

        }
        for (int i=0;i<arrayCheckBox.size();i++)
        {
            int finalI = i;
            arrayCheckBox.get(i).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked)
                    {
                        unCheckedOtherCheckBox(arrayCheckBox, buttonView,context);
                        if(digitEditText.getText().toString().isEmpty())
                            return;
                        updateTextView(arrayCheckBox,digitEditText,addNotificationDays,notificationDateAndTime,serviceDate);
                    }
                    else
                    {
                        buttonView.setText(buttonView.getText().toString().replace("before",""));
                        buttonView.setTextColor(context.getResources().getColor(R.color.grey_color));
                    }
                }
            });
        }
        digitEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.toString().isEmpty())
                    return;
                updateTextView(arrayCheckBox,digitEditText,addNotificationDays,notificationDateAndTime,serviceDate);
            }
        });
       addReminderCalendartextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewNotificationDialogue(context,serviceDetails, myCalendar1,expectingDateandTime,notificationDateAndTime);
                Log.d("reminderdialogue:",serviceDetails.getRemindarDate()+" t:"+serviceDetails.getRemindarTime());
            }
        });
        notificationDateAndTime.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(!s.toString().isEmpty())
                {
                  //  addNotificationDays.setText(notificationDateAndTime.getText());
                }
            }
        });

        customNotificationDialogue.show();
        if(!digitEditText.getText().toString().isEmpty())
            updateTextView(arrayCheckBox,digitEditText,addNotificationDays,notificationDateAndTime,serviceDate);
        else
            notificationDateAndTime.setText("");
        dialog_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                try {
                    serviceDetails.setRemindarDate(sdf.format(new Date(notificationDateAndTime.getText().toString())));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                String myFormat1 = "HH:mm"; //In which you need put here
                SimpleDateFormat sdf1 = new SimpleDateFormat(myFormat1, Locale.US);
                Log.d("illegaltime:",notificationDateAndTime.getText().toString());
                serviceDetails.setRemindarTime(sdf1.format(new Date(notificationDateAndTime.getText().toString())));

                if(!notificationDateAndTime.getText().toString().isEmpty())
                {
                    addNotificationDays.setText(notificationDateAndTime.getText());
                   // notificationLinear.setVisibility(View.VISIBLE);
                    addNotificationDays.setVisibility(View.VISIBLE);
                    addReminderTextView.setVisibility(View.GONE);
                }


                customNotificationDialogue.dismiss();
            }
        });

    }


    private static void updateTextView(ArrayList<CheckBox> arrayCheckBox, EditText digitEditText, TextView addNotificationDays, TextView notificationDateAndTime, Date serviceDate) {
        int index=-1;
        for(int i=0;i<arrayCheckBox.size();i++)
        {
            if(arrayCheckBox.get(i).isChecked())
            {
                index=i;
            }
        }
        long diff=0;
        long expectingTime=0;
        if(index>=0)
        {
            try {
                switch (index) {
                    case 0:
                        //digitEditText.setText(""+(diff)/(7*24 * 60 * 60 * 1000));

                        diff = (Integer.parseInt(digitEditText.getText().toString())) ;
                        Log.d("difff..:",diff+"");
                        if (Integer.parseInt(digitEditText.getText().toString())>diff)
                            digitEditText.setText(""+diff);
                        diff=diff*60*1000;
                        long tempDiff= serviceDate.getTime()-new Date().getTime();
                        tempDiff=tempDiff/(60*1000);
                        if(tempDiff>59)
                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", "59")});
                        else {
                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", ""+tempDiff)});

                        }
                        break;
                    case 1:
                        diff = (Integer.parseInt(digitEditText.getText().toString()));
                        if (Integer.parseInt(digitEditText.getText().toString())>23)
                            digitEditText.setText("23");
//                        if(diff>23)
//                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", "23")});
//                        else
//                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", ""+diff)});
                        diff=diff* 60 * 60 * 1000;

                        tempDiff= serviceDate.getTime()-new Date().getTime();
                        tempDiff=tempDiff/(60*60*1000);
                        if(tempDiff>23)
                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", "23")});
                        else {
                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", ""+tempDiff)});

                        }
                        break;
                    case 2:
                        diff = (Integer.parseInt(digitEditText.getText().toString())) * 24 * 60 * 60 * 1000;
                        if (Integer.parseInt(digitEditText.getText().toString())>7)
                            digitEditText.setText("7");
//                        if(diff>7)
//                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", "7")});
//                        else
//                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", ""+diff)});

                        tempDiff= serviceDate.getTime()-new Date().getTime();
                        tempDiff=tempDiff/( 24 * 60 * 60 * 1000);

                            digitEditText.setFilters(new InputFilter[]{ new MinMaxFilter("1", ""+tempDiff)});
                            break;

                }
            }catch (Exception e)
            {
                notificationDateAndTime.setText("");
            }
        }
        if(diff>0)
        {
            String myFormat = "MM/dd/yy HH:mm"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date notificationDate=new Date(serviceDate.getTime() - diff);
            if(new Date().compareTo(notificationDate) < 0)
            {
               // addNotificationDays.setText(sdf.format(notificationDate));
                notificationDateAndTime.setText(sdf.format(notificationDate));
                digitEditText.setError(null);
            }
            else {
                long newDiff= notificationDate.getTime()-new Date().getTime();
                setErrorMessage(newDiff,digitEditText,index);
            }
        }
        else
        {
            notificationDateAndTime.setText("");
            digitEditText.setError(null);
        }
    }

    private static void setErrorMessage(long newDiff, EditText digitEditText, int index) {

        try {
            switch (index) {
                case 0:
                    long maxMinutes=newDiff/(60*1000);
                    digitEditText.setError("Minutes from 1 to "+maxMinutes );
                    break;
                case 1:
                    maxMinutes=newDiff/(60*60*1000);
                    digitEditText.setError("hours from 1 to "+maxMinutes );
                    break;
                case 2:
                    maxMinutes=newDiff/(24*60*60*1000);
                    digitEditText.setError("Days from 1 to "+maxMinutes );
                    break;
                case 3:
                    maxMinutes=newDiff/(7*24*60*60*1000);
                    digitEditText.setError("weeks from 1 to "+maxMinutes );
                    break;


            }
        }catch (Exception e)
        {

        }
    }

    private static void unCheckedOtherCheckBox(ArrayList<CheckBox> arrayCheckBox, CompoundButton buttonView,Context context) {
        for (CheckBox ch:arrayCheckBox)
        {
            if(ch.getId() == (buttonView.getId()))
            {
                ch.setText((ch.getText()+" before").trim());
                ch.setTextColor(context.getResources().getColor(R.color.blackText));
                //ch.setTextColor();
                ch.setChecked(true);
            }
            else {
                ch.setText(ch.getText().toString().replace("before",""));
                ch.setTextColor(context.getResources().getColor(R.color.grey_color));

                ch.setChecked(false);
                ///ch.setTextColor()
            }
        }
    }

    public static void updateLabel1(EditText eventDateEditText, Calendar myCalendar1) {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        eventDateEditText.setText(sdf.format(myCalendar1.getTime()));
    }

    public void addNotificationEvent(Context context, ServiceDetails serviceDetails)
    {
        Date expectingDateandTime;
        Calendar myCalendar1 = Calendar.getInstance();

        if(serviceDetails.getRemindarDate()!=null && !serviceDetails.getRemindarDate().isEmpty() && serviceDetails.getRemindarTime()!=null && !serviceDetails.getRemindarTime().isEmpty())
        {
            //new NotificationAlarmManager().cancelAlarmManager(serviceDetails.getRequestCode(),context); sach commented and updated as below
            new NotificationAlarmManager().cancelAlarmManager((int) serviceDetails.getRequestUID().getLeastSignificantBits(),context);
            expectingDateandTime=new Date(serviceDetails.getRemindarDate() + " " + serviceDetails.getRemindarTime().replaceAll("\\s+", ""));
            myCalendar1.setTime(expectingDateandTime);

        }
        else {
            expectingDateandTime = new Date(serviceDetails.getExpectingServiceDate() + " " + serviceDetails.getExpectingtime().replaceAll("\\s+", ""));
            myCalendar1.setTime(expectingDateandTime);
            long diff = expectingDateandTime.getTime() - new Date().getTime();
            if(diff >(24 * 60 * 60 * 1000))
                myCalendar1.add(Calendar.DATE, -1);
        }
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);


    }


    public static void openNewNotificationDialogue(Context context, ServiceDetails serviceDetails, Calendar myCalendar1, Date expectingDateandTime, TextView notificationDateAndTime) {

        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        Dialog dialog1 = new Dialog(context);

        dialog1.setContentView(R.layout.setcalendareventdialogue);
        dialog1.setTitle("Add Event to calendar");
        int width = (int)(context.getResources().getDisplayMetrics().widthPixels*0.90);

        dialog1.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextView event_name_textview = (TextView) dialog1.findViewById(R.id.event_name_textview);
        TextView event_description = (TextView) dialog1.findViewById(R.id.event_description);
        event_name_textview.setText(serviceDetails.getTitle());//sach changed serviceRequestName>title / getServiceRequestName > getTitle() / setServiceRequestName > setTitle()
        //event_description.setText(serviceDetails.getServiceDescription());//sach changed as below
        event_description.setText(serviceDetails.getComments());


        EditText eventDateEditText = (EditText) dialog1.findViewById(R.id.input_date);
        EditText eventTimeEditText = (EditText) dialog1.findViewById(R.id.input_time);


        eventTimeEditText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                TimePickerDialog mTimePicker = CustomDateTimePicker.getCustomTimePickerDialogue(context,eventTimeEditText,myCalendar1.getTime(),new Date(),expectingDateandTime);

            }
        });

        DatePickerDialog.OnDateSetListener notificationEventDateListener = CustomDateTimePicker.getCustomDatePicker(eventDateEditText, expectingDateandTime, myCalendar1);
        eventDateEditText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                DatePickerDialog datePicker=new DatePickerDialog(context, notificationEventDateListener,
                        myCalendar1.get(Calendar.YEAR), myCalendar1.get(Calendar.MONTH),
                        myCalendar1.get(Calendar.DAY_OF_MONTH));
                datePicker.getDatePicker().setMinDate( new Date().getTime());
                datePicker.getDatePicker().setMaxDate(expectingDateandTime.getTime());
                datePicker.setCancelable(false);
                datePicker.show();
            }
        });
        eventTimeEditText.setText(expectingDateandTime.getHours()+" : "+expectingDateandTime.getMinutes());
        eventDateEditText.setText(sdf.format(expectingDateandTime));

        LinearLayout agelinearlayout=(LinearLayout) dialog1.findViewById(R.id.agelinearlayout);
        agelinearlayout.setVisibility(View.GONE);


        updateLabel1(eventDateEditText,myCalendar1);
        Button submit1 = dialog1.findViewById(R.id.dialog_submit);
        dialog1.show();
        submit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceDetails.setRemindarDate(eventDateEditText.getText().toString());
                serviceDetails.setRemindarTime(eventTimeEditText.getText().toString());
                notificationDateAndTime.setText(eventDateEditText.getText()+" "+eventTimeEditText.getText());
                Date expectingDateandTime=new Date(eventDateEditText.getText().toString() + " " + eventTimeEditText.getText().toString().replaceAll("\\s+", ""));
                try {
                    //new NotificationAlarmManager().addAlarmManager(serviceDetails.getRequestCode(),expectingDateandTime , context, serviceDetails.getRequestUID(), context.getString(R.string.ServiceDetailsObject)); //sach changed getServiceID>getRequestUID | sach commented and updated as below
                    new NotificationAlarmManager().addAlarmManager((int) serviceDetails.getRequestUID().getLeastSignificantBits(),expectingDateandTime , context, serviceDetails.getRequestUID(), context.getString(R.string.ServiceDetailsObject)); //sach changed getServiceID>getRequestUID

                } catch (Exception e) {
                    e.printStackTrace();
                }
                dialog1.dismiss();
            }
        });
    }

    public static void setNotificationTime(Context context, ServiceDetails serviceDetails,TextView addNotificationDays)
    {
        if(serviceDetails == null || serviceDetails.getExpectingtime()==null || serviceDetails.getExpectingServiceDate()==null)
            return;
        long diff=0;
        Date expectingDateandTime;

        Date serviceDate=new Date(serviceDetails.getExpectingServiceDate() + " " + serviceDetails.getExpectingtime().replaceAll("\\s+", ""));
        Log.d(" date:",serviceDate.toString());
        //new NotificationAlarmManager().cancelAlarmManager(serviceDetails.getRequestCode(),context); sach commented and updated as below
        new NotificationAlarmManager().cancelAlarmManager((int) serviceDetails.getRequestUID().getLeastSignificantBits(),context);

        Calendar myCalendar1 = Calendar.getInstance();
        if(serviceDetails.getRemindarDate()!=null && !serviceDetails.getRemindarDate().isEmpty() && serviceDetails.getRemindarTime()!=null && !serviceDetails.getRemindarTime().isEmpty())
        {
            Log.d("reminder:","D:"+serviceDetails.getRemindarDate()+ "  T:"+serviceDetails.getRemindarTime());
            expectingDateandTime=new Date(serviceDetails.getRemindarDate() + " " + serviceDetails.getRemindarTime().replaceAll("\\s+", ""));
            myCalendar1.setTime(expectingDateandTime);
            diff=expectingDateandTime.getTime()-serviceDate.getTime();

        }
        else {
            //serviceDate = new Date(serviceDetails.getExpectingServiceDate() + " " + serviceDetails.getExpectingtime().replaceAll("\\s+", ""));
            myCalendar1.setTime(serviceDate);
            diff = serviceDate.getTime() - new Date().getTime();
        }

        int index=-1;
        if(diff >(24 * 60 * 60 * 1000)) {
            index=2;
            Log.d("days:",diff+"");
            myCalendar1.add(Calendar.DATE, -1);
        }
        else if(diff>(60 * 60 * 1000) && diff<= (24*60*60*1000))
        {
            index=1;
            myCalendar1.add(Calendar.HOUR ,-1);
            Log.d("hour:",diff+"");
        }
        else if(diff>(60*1000) && diff<(60*60*1000)) {

            index=0;
            myCalendar1.add(Calendar.MINUTE, -20);
            Log.d("minutes:",diff+"");
        }

        if(diff>0)
        {
            String myFormat = "MM/dd/yy HH:mm"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date notificationDate=myCalendar1.getTime();
            Log.d("notification date:",notificationDate.toString()+"  d:"+sdf.format(notificationDate));
            addNotificationDays.setText(sdf.format(notificationDate).toString());
            Log.d("noti date:",notificationDate.toString()+"  textview:"+addNotificationDays.getText());
            // notification time problem
            //new NotificationAlarmManager().addAlarmManager(serviceDetails.getRequestCode(),notificationDate , context, serviceDetails.getRequestUID(), context.getString(R.string.ServiceDetailsObject));//sach changed getServiceID>getRequestUID | sach commented and updated as below
            new NotificationAlarmManager().addAlarmManager((int) serviceDetails.getRequestUID().getLeastSignificantBits(),notificationDate , context, serviceDetails.getRequestUID(), context.getString(R.string.ServiceDetailsObject));//sach changed getServiceID>getRequestUID

        }
        else
        {
            Log.d("notification date:","null");

        }
    }

}
