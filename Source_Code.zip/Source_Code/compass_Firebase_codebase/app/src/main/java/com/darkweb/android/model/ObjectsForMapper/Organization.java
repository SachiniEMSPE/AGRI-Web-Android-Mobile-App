package com.darkweb.android.model.ObjectsForMapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Organization implements Serializable {
    private Integer id;
    private String name;
    private String description;
    private String keywords;
    private String aliases;
    private String physicalStreetAddress1;
    private String physicalStreetAddress2;
    private String physicalCity;
    private String physicalState;
    private String physicalZipCode;
    private String mailingStreetAddress1;
    private String mailingStreetAddress2;
    private String mailingCity;
    private String mailingState;
    private String mailingZipCode;
    private String phone;
    private String tddPhone;
    private String hotLinePhone;
    private String emergencyPhone;
    private String otherPhone;
    private String fax;
    private String email;
    private String webAddress;
    private String hours;
    private String eligibility;
    private String facilityAdaAccess;
    private String languageSpoken;
    private Double longitude;
    private Double latitude;
    private String mission;
    private String employerIdentificationNumber;
    private String geographicArea;
    private String otherLocations;
    private String password;
    private String type;
    private String aboutUs;
    private List<Program> programs;

    public Organization() {
    }

    public Integer getId() { return id; }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description != null ? description : "N/A";
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getAliases() {
        return aliases;
    }

    public void setAliases(String aliases) {
        this.aliases = aliases;
    }

    public String getPhysicalStreetAddress1() {
        return physicalStreetAddress1 != null ? physicalStreetAddress1 : "N/A";
    }

    public void setPhysicalStreetAddress1(String physicalStreetAddress1) {
        this.physicalStreetAddress1 = physicalStreetAddress1;
    }

    public String getPhysicalStreetAddress2() {
        return physicalStreetAddress2;
    }

    public void setPhysicalStreetAddress2(String physicalStreetAddress2) {
        this.physicalStreetAddress2 = physicalStreetAddress2;
    }

    public String getPhysicalCity() {
        return physicalCity != null ? physicalCity : "N/A";
    }

    public void setPhysicalCity(String physicalCity) {
        this.physicalCity = physicalCity;
    }

    public String getPhysicalState() {
        return physicalState != null ? physicalState : "N/A";
    }

    public void setPhysicalState(String physicalState) {
        this.physicalState = physicalState;
    }

    public String getPhysicalZipCode() {
        return physicalZipCode != null ? physicalZipCode : "N/A";
    }

    public void setPhysicalZipCode(String physicalZipCode) {
        this.physicalZipCode = physicalZipCode;
    }

    public String getMailingStreetAddress1() {
        return mailingStreetAddress1;
    }

    public void setMailingStreetAddress1(String mailingStreetAddress1) {
        this.mailingStreetAddress1 = mailingStreetAddress1;
    }

    public String getMailingStreetAddress2() {
        return mailingStreetAddress2;
    }

    public void setMailingStreetAddress2(String mailingStreetAddress2) {
        this.mailingStreetAddress2 = mailingStreetAddress2;
    }

    public String getMailingCity() {
        return mailingCity;
    }

    public void setMailingCity(String mailingCity) {
        this.mailingCity = mailingCity;
    }

    public String getMailingState() {
        return mailingState;
    }

    public void setMailingState(String mailingState) {
        this.mailingState = mailingState;
    }

    public String getMailingZipCode() {
        return mailingZipCode;
    }

    public void setMailingZipCode(String mailingZipCode) {
        this.mailingZipCode = mailingZipCode;
    }

    public String getPhone() {
        return phone != null ? phone : "N/A";
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTddPhone() {
        return tddPhone;
    }

    public void setTddPhone(String tddPhone) {
        this.tddPhone = tddPhone;
    }

    public String getHotLinePhone() {
        return hotLinePhone;
    }

    public void setHotLinePhone(String hotLinePhone) {
        this.hotLinePhone = hotLinePhone;
    }

    public String getEmergencyPhone() {
        return emergencyPhone;
    }

    public void setEmergencyPhone(String emergencyPhone) {
        this.emergencyPhone = emergencyPhone;
    }

    public String getOtherPhone() {
        return otherPhone;
    }

    public void setOtherPhone(String otherPhone) {
        this.otherPhone = otherPhone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getEmail() {
        return email != null ? email : "N/A";
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebAddress() {
        return webAddress != null ? webAddress : "N/A";
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }

    public String getHours() {
        return hours != null ? hours : "N/A";
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public String getEligibility() {
        return eligibility;
    }

    public void setEligibility(String eligibility) {
        this.eligibility = eligibility;
    }

    public String getFacilityAdaAccess() {
        return facilityAdaAccess;
    }

    public void setFacilityAdaAccess(String facilityAdaAccess) {
        this.facilityAdaAccess = facilityAdaAccess;
    }

    public String getLanguageSpoken() {
        return languageSpoken != null ? languageSpoken : "N/A";
    }

    public void setLanguageSpoken(String languageSpoken) {
        this.languageSpoken = languageSpoken;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getMission() {
        return mission != null ? mission : "N/A";
    }

    public void setMission(String mission) {
        this.mission = mission;
    }

    public String getEmployerIdentificationNumber() {
        return employerIdentificationNumber;
    }

    public void setEmployerIdentificationNumber(String employerIdentificationNumber) {
        this.employerIdentificationNumber = employerIdentificationNumber;
    }

    public String getGeographicArea() {
        return geographicArea;
    }

    public void setGeographicArea(String geographicArea) {
        this.geographicArea = geographicArea;
    }

    public String getOtherLocations() {
        return otherLocations;
    }

    public void setOtherLocations(String otherLocations) {
        this.otherLocations = otherLocations;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAboutUs() {
        return aboutUs;
    }

    public void setAboutUs(String aboutUs) {
        this.aboutUs = aboutUs;
    }

    public List<Program> getPrograms() {
        return programs;
    }

    public void setPrograms(List<Program> programs) {
        this.programs = programs;
    }
}
