package com.darkweb.android.model;

import java.io.Serializable;

/**
 * Created by kotak on 04/07/2018.
 */

public class FeedBackDetails implements Serializable {

    ServiceDetails serviceDetails;
    String ratingValue;
    String Comments;
    User userObj;

    @Override
    public String toString() {
        return "FeedBackDetails{" +
                "serviceDetails=" + serviceDetails +
                ", ratingValue='" + ratingValue + '\'' +
                ", Comments='" + Comments + '\'' +
                ", userObj=" + userObj +
                '}';
    }

    public User getUserObj() {
        return userObj;
    }

    public void setUserObj(User userObj) {
        this.userObj = userObj;
    }

    public ServiceDetails getServiceDetails() {
        return serviceDetails;
    }

    public void setServiceDetails(ServiceDetails serviceDetails) {
        this.serviceDetails = serviceDetails;
    }

    public String getRatingValue() {
        return ratingValue;
    }

    public void setRatingValue(String ratingValue) {
        this.ratingValue = ratingValue;
    }

    public String getComments() {
        return Comments;
    }

    public void setComments(String comments) {
        Comments = comments;
    }
}
