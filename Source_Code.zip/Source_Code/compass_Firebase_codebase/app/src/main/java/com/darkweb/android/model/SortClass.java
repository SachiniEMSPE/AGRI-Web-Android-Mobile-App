package com.darkweb.android.model;

import android.content.Context;
import android.os.Build;

import android.util.Log;

import com.darkweb.android.compass.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import androidx.annotation.RequiresApi;

/**
 * Created by kotak on 16/08/2018.
 */

public class SortClass {
    private static ArrayList<ServiceDetails> serviceDetailsList;
    private static ArrayList<ServiceDetails> completedServices;
    private static ArrayList<ServiceDetails> cancelledServices;
    private static ArrayList<ServiceDetails> allServiceDetails;
    private static HashMap<OrganizationDescription, Integer> servicePriorityMap;
    private static HashMap<OrganizationDescription,Integer> sortedServicePriorityMap;
    private static String url;

    //@RequiresApi(api = Build.VERSION_CODES.N) // sach commnted due to conversion of serviceDetails object to previous version 2020 - 02 - 06
    public static ArrayList<OrganizationDescription> sortByFrequentlyUsed(ArrayList<OrganizationDescription> currentLocationList, Context context) {

        ArrayList<OrganizationDescription> sortedLocationList=new ArrayList<OrganizationDescription>();
        if(allServiceDetails==null || servicePriorityMap==null || sortedServicePriorityMap==null)
        {
            allServiceDetails=new ArrayList<ServiceDetails>();
            servicePriorityMap=new HashMap<OrganizationDescription,Integer>();

            url =  context.getFilesDir().toString();
            File file=new File(url,context.getString(R.string.serviceDetails));
            File completedServicesFile=new File(url,context.getString(R.string.completedServices));
            File cancelledServicesFile=new File(url,context.getString(R.string.cancelledServices));
            FileInputStream fileInputStream ;
            ObjectInputStream objectInputStream ;
            if (file.exists())
            {
                try {
                    fileInputStream = new FileInputStream(file);
                    objectInputStream = new ObjectInputStream(fileInputStream);
                    serviceDetailsList = (ArrayList<ServiceDetails>) objectInputStream.readObject();
                    objectInputStream.close();
                    fileInputStream.close();
                    Log.d("size:", serviceDetailsList + "");
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
            if (completedServicesFile.exists())
            {
                try {
                    fileInputStream=new FileInputStream(completedServicesFile);
                    objectInputStream=new ObjectInputStream(fileInputStream);
                    completedServices=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                    objectInputStream.close();
                    fileInputStream.close();
                    Log.d("size:",serviceDetailsList+"");

                }catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
            Log.d("exist:",(cancelledServicesFile.exists())+"");
            if (cancelledServicesFile.exists())
            {
                try {
                    fileInputStream = new FileInputStream(cancelledServicesFile);
                    objectInputStream = new ObjectInputStream(fileInputStream);
                    cancelledServices = (ArrayList<ServiceDetails>) objectInputStream.readObject();
                    Log.d("cancesize:",cancelledServices.size()+"");
                    objectInputStream.close();
                    fileInputStream.close();
                    Log.d("size:", serviceDetailsList + "");
                }catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
            if(serviceDetailsList!=null && serviceDetailsList.size()>0)
                allServiceDetails.addAll(serviceDetailsList);
            if(cancelledServices!=null && cancelledServices.size()>0)
                allServiceDetails.addAll(cancelledServices);
            if(completedServices!=null && completedServices.size()>0)
                allServiceDetails.addAll(completedServices);

            for(ServiceDetails serviceDetails:allServiceDetails)
            {
                if(!servicePriorityMap.containsKey(serviceDetails.getOrganizationDescription()))//sach added context | context removed to match the preious version
                {
                    Log.d("mapcontains:",serviceDetails.getOrganizationDescription().getOrganizationName()+" ");//sach added context | context removed to match the preious version
                    servicePriorityMap.put(serviceDetails.getOrganizationDescription(),1);//sach added context | context removed to match the preious version
                }
                else
                {
                    int i=servicePriorityMap.get(serviceDetails.getOrganizationDescription());//sach added context| context removed to match the preious version
                    servicePriorityMap.put(serviceDetails.getOrganizationDescription(),i+1);//sach added context| context removed to match the preious version
                }
            }

            sortedServicePriorityMap=sortByValues(servicePriorityMap);
        }
        Log.d("MapSize:",servicePriorityMap.size()+" sorted:"+sortedServicePriorityMap.size());

        for (Map.Entry<OrganizationDescription, Integer> entry : sortedServicePriorityMap.entrySet())
        {
            Log.d("Map:",entry.getKey().getOrganizationName());
            OrganizationDescription key = entry.getKey();
            sortedLocationList.add(key);
            if (currentLocationList.contains(key))
            {
                currentLocationList.remove(key);
                Log.d("removing:",entry.getKey().getOrganizationName());
            }

        }
        sortedLocationList.addAll(currentLocationList);
        return sortedLocationList;
    }

    //descending order sort
    private static HashMap sortByValues(HashMap map) {
        List list = new LinkedList(map.entrySet());
        // Defined Custom Comparator here
        Collections.sort(list, new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((Comparable) ((Map.Entry) (o2)).getValue())
                        .compareTo(((Map.Entry) (o1)).getValue());
            }
        });

        // Here I am copying the sorted list in HashMap
        // using LinkedHashMap to preserve the insertion order
        HashMap sortedHashMap = new LinkedHashMap();
        for (Iterator it = list.iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            sortedHashMap.put(entry.getKey(), entry.getValue());
        }
        return sortedHashMap;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public boolean containsName(final List<OrganizationDescription> list, final String name){
        return list.stream().filter(o -> o.getOrganizationName().equals(name)).findFirst().isPresent();
    }

}
