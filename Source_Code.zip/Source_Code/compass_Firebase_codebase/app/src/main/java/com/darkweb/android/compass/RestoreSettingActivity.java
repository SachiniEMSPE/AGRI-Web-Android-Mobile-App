package com.darkweb.android.compass;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.darkweb.android.service.RestoreSettingService;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;

public class RestoreSettingActivity extends AppCompatActivity {
    private TextView restoreDate;
    private TextView restoreSize;
    private ListView restoreListView;
    private Button restoreButton;
    private CheckBox volunteerServicesCheckBox;
    private CheckBox bookmarkCheckBox;
    private CheckBox servicesCheckBox;
    private CheckBox profileCheckBox;
    private String url;
    long restoreLongSize=0;
    private File userInfoFile;
    private File bookmarkOrganization;
    private File bookmarkCalenderEvents;
    private File servicesDetails;
    private File yourEventListFile;
    private HashMap<File,Long> fileSizeMap = new HashMap<File, Long>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restore_setting);
        RestoreSettingService restoreSettingServiceObject=new RestoreSettingService(RestoreSettingActivity.this);
       // restoreDate=(TextView) findViewById(R.id.restore_date);
//        restoreDate.setVisibility(View.GONE);
        //findViewById(R.id.restore_date_textview).setVisibility(View.GONE);
        restoreSize= ( TextView) findViewById(R.id.restore_size);
        restoreButton=(Button)findViewById(R.id.restore_button);
        url = RestoreSettingActivity.this.getFilesDir().toString();
        profileCheckBox=(CheckBox) findViewById(R.id.profile_restore_checkbox);
        servicesCheckBox=(CheckBox) findViewById(R.id.services_restore_checkbox);
        bookmarkCheckBox=(CheckBox) findViewById(R.id.bookmark_restore_checkbox);
        volunteerServicesCheckBox=(CheckBox) findViewById(R.id.volunteer_services_restore_checkbox);
        findViewById(R.id.restore_size_textview).setVisibility(View.GONE);
        restoreSize.setVisibility(View.GONE);
        profileCheckBox.setChecked(true);
        servicesCheckBox.setChecked(true);
        bookmarkCheckBox.setChecked(true);
        volunteerServicesCheckBox.setChecked(true);

        userInfoFile = new File(url,getString(R.string.UserInfo));
        bookmarkOrganization = new File(url,getString(R.string.bookmarkFile));
        bookmarkCalenderEvents = new File(url,getString(R.string.bookmarkCalendarEvent));
        servicesDetails = new File(url,getString(R.string.serviceDetails));
        yourEventListFile = new File(url, getString(R.string.yourEventListFile));

        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(userInfoFile),restoreLongSize,restoreSize);
        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(bookmarkOrganization),restoreLongSize,restoreSize);
        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(bookmarkCalenderEvents),restoreLongSize,restoreSize);
        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(servicesDetails),restoreLongSize,restoreSize);
        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(yourEventListFile),restoreLongSize,restoreSize);

        for(File f : fileSizeMap.keySet())
        {
            Log.d("sizefile:",""+fileSizeMap.get(f).longValue()+ "  name:"+f.getName());
        }

        profileCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    if(isChecked)
                    {
                        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(userInfoFile),restoreLongSize,restoreSize);
                    }
                    else {
                        restoreSettingServiceObject.subtractRestoreLength(fileSizeMap.get(userInfoFile),restoreLongSize,restoreSize);
                    }
            }
        });

        bookmarkCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    if(isChecked)
                    {
                        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(bookmarkCalenderEvents),restoreLongSize,restoreSize);
                    }
                    else
                    {
                        restoreSettingServiceObject.subtractRestoreLength(fileSizeMap.get(bookmarkCalenderEvents),restoreLongSize,restoreSize);
                    }

                    if(isChecked)
                    {
                        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(bookmarkOrganization),restoreLongSize,restoreSize);
                    }
                    else
                    {
                        restoreSettingServiceObject.subtractRestoreLength(fileSizeMap.get(bookmarkOrganization),restoreLongSize,restoreSize);
                    }

            }
        });

        servicesCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d("serviceExist:",servicesDetails.exists()+""+" "+yourEventListFile.exists());

                    if(isChecked)
                    {
                        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(servicesDetails),restoreLongSize,restoreSize);
                    }
                    else
                        restoreSettingServiceObject.subtractRestoreLength(fileSizeMap.get(servicesDetails),restoreLongSize,restoreSize);

                    if(isChecked)
                        restoreSettingServiceObject.addRestoreLength(fileSizeMap.get(yourEventListFile),restoreLongSize,restoreSize);
                    else
                        restoreSettingServiceObject.subtractRestoreLength(fileSizeMap.get(yourEventListFile),restoreLongSize,restoreSize);

            }
        });



        ArrayList<File> fileArrayList =new ArrayList<File>() ;
        restoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fileArrayList.clear();
                if(profileCheckBox.isChecked())
                {
                    fileArrayList.add(userInfoFile);
                }
                if(bookmarkCheckBox.isChecked())
                {
                    fileArrayList.add(bookmarkOrganization);
                    fileArrayList.add(bookmarkCalenderEvents);
                }
                if(servicesCheckBox.isChecked())
                {
                    fileArrayList.add(servicesDetails);
                    fileArrayList.add(yourEventListFile);
                }
                if(volunteerServicesCheckBox.isChecked())
                {
                    //    File
                }
                if(fileArrayList.size()>0)
                {
                    restoreSettingServiceObject.RestoreFiles(fileArrayList);
                    Toast.makeText(RestoreSettingActivity.this,"Restored Successfully",Toast.LENGTH_LONG).show();

                }

            }
        });
    }
}
