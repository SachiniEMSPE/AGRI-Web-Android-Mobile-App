package com.darkweb.android.compass.fragments;

import androidx.appcompat.app.AppCompatActivity;

public class ViewServicesNew extends AppCompatActivity {

}
