package com.darkweb.android.adapter;

/**
 * Created by kotak on 20/08/2018.
 */

public interface NotifyExpandableListAdapter {
    public void updateExpandableList();
}
