package com.darkweb.android.parser;

import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.json.JSONArray;
import org.json.JSONObject;

import com.darkweb.android.model.Folder;
import com.darkweb.android.model.OrganizationDescription;


/**
 * Created by kotak on 12/06/2018.
 */

public class ObjectToJson {

    public static JSONObject objectToJsonObject(OrganizationDescription locDescObj)
    {
        JSONArray dataJsonArray=new JSONArray();
        JSONObject extendedJson=new JSONObject();

        JSONObject extendedJsonObj=new JSONObject();
    	/*JSONObject dataJson=new JSONObject();
    	JSONObject nameJson=new JSONObject();
    	*/


        try {



            JSONObject jsonObj=new JSONObject();
            jsonObj.put("name", "Contact");
            jsonObj.put("value",""+locDescObj.getContact());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Description");
            jsonObj.put("value",""+locDescObj.getDescription());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Hours");
            jsonObj.put("value",""+locDescObj.getHours());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Email");
            jsonObj.put("value",""+locDescObj.getEmailId());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Longitude");
            jsonObj.put("value",""+locDescObj.getLongitude());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Latitude");
            jsonObj.put("value",""+locDescObj.getLatitude());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Street Address");
            jsonObj.put("value",""+locDescObj.getStreetAddress());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "City");
            jsonObj.put("value",""+locDescObj.getCity());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "State");
            jsonObj.put("value",""+locDescObj.getState());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Zip Code");
            jsonObj.put("value",""+locDescObj.getZipcode());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Website");
            jsonObj.put("value",""+locDescObj.getWebsite());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Category Name");
            jsonObj.put("value",""+locDescObj.getCategory());
            dataJsonArray.put(jsonObj);

            jsonObj=new JSONObject();
            jsonObj.put("name", "Marker Color");
            jsonObj.put("value",""+locDescObj.getMarkerColor());
            dataJsonArray.put(jsonObj);


            //dataJson.put("Data", dataJsonArray);


            //  extendedJsonObj.put("name", locDescObj.getName());
            extendedJsonObj.put("Data",dataJsonArray);

            extendedJson.put("ExtendedData", extendedJsonObj);
            extendedJson.put("name", locDescObj.getOrganizationName());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        //
        return extendedJson;
    }

    public static JSONObject writeObjectToFile(JSONObject extendedJson, File file)
    {
        //File file=new File("src\\"+filename+".json");
        JSONArray placemarkArray=null;
        JSONObject placemark=null;
        JSONArray folderArray=null;
        JSONObject folderObj=null;
        JSONObject docObj=null;
        JSONObject kmlObj=null;
        try {

            if(file.exists())
            {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                StringBuilder sb = new StringBuilder();
                while((line=br.readLine())!= null)
                {
                    sb.append(line.trim());
                }
                String jsonString = sb.toString();
                Log.d("before:",jsonString);
                JSONObject document=new JSONObject(jsonString);
                //JSONArray folderArray=((document.getJSONObject("kml")).getJSONObject("Document")).getJSONArray("Folder");
                kmlObj=document.getJSONObject("kml");
                docObj=kmlObj.getJSONObject("Document");
                folderArray=docObj.getJSONArray("Folder");


                for(int k=0;k<folderArray.length();k++)
                {
                    Folder folder=new Folder();
                    JSONObject folderJson=folderArray.getJSONObject(k);
                    String folderName=folderJson.getString("name");
                    System.out.println("firstname alright");
                    System.out.println("foldername:"+folderName);
                    folder.setName(folderName);
                    placemarkArray=folderJson.getJSONArray("Placemark");
                }
            }
            if(placemarkArray==null)
            {
                placemarkArray=new JSONArray();

            }
            Log.d("placesize:",placemarkArray.length()+"");
            placemarkArray.put(extendedJson);

            if (placemark==null) {
                placemark = new JSONObject();
                placemark.put("Placemark", placemarkArray);
                placemark.put("name","foldername");

            }


            //placemark.put("name", category);
            if(folderArray==null)
            {
                folderArray=new JSONArray();
                folderArray.put(placemark);

            }


            folderObj=new JSONObject();
            folderObj.put("Folder", folderArray);
            docObj=new JSONObject();
            docObj.put("Document", folderObj);
            kmlObj=new JSONObject();
            kmlObj.put("kml", docObj);

            System.out.println(kmlObj);
            Log.d("kml:",kmlObj+"");



            return kmlObj;

            /*FileWriter file1 = new FileWriter("src\\"+filename+".json");
            file1.write(kmlObj.toString());
            file1.flush();
*/


        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static JSONObject removeObjectFromFile(String serviceName, File file)
    {

        JSONArray placemarkArray=null;
        JSONObject placemark=null;
        JSONArray folderArray=null;
        JSONObject folderObj=null;
        JSONObject docObj=null;
        JSONObject kmlObj=null;

        try {

            if (file.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                StringBuilder sb = new StringBuilder();
                while ((line = br.readLine()) != null) {
                    sb.append(line.trim());
                }
                String jsonString = sb.toString();
                Log.d("before:", jsonString);
                JSONObject document = new JSONObject(jsonString);
                //JSONArray folderArray=((document.getJSONObject("kml")).getJSONObject("Document")).getJSONArray("Folder");
                kmlObj = document.getJSONObject("kml");
                docObj = kmlObj.getJSONObject("Document");
                folderArray = docObj.getJSONArray("Folder");

                int foundFlag=0;
                for (int k = 0; k < folderArray.length(); k++) {
                    Folder folder = new Folder();
                    JSONObject folderJson = folderArray.getJSONObject(k);
                    String folderName = folderJson.getString("name");
                    System.out.println("firstname alright");
                    System.out.println("foldername:" + folderName);
                    folder.setName(folderName);
                    placemarkArray = folderJson.getJSONArray("Placemark");

                    int position=0;
                    for(int i=0;i<placemarkArray.length();i++)
                    {
                        String name=placemarkArray.getJSONObject(i).getString("name");
                        if (name.equals(serviceName))
                        {
                            foundFlag=1;
                            position=i;
                            break;
                        }

                    }
                    if (foundFlag==1)
                    {
                        placemarkArray.remove(position);
                        break;
                    }


                }
            }
            if (placemarkArray == null) {
                placemarkArray = new JSONArray();

            }
            Log.d("placesize:", placemarkArray.length() + "");
            if (placemark == null) {
                placemark = new JSONObject();
                placemark.put("Placemark", placemarkArray);
                placemark.put("name", "foldername");

            }


            //placemark.put("name", category);
            if (folderArray == null) {
                folderArray = new JSONArray();
                folderArray.put(placemark);

            }


            folderObj = new JSONObject();
            folderObj.put("Folder", folderArray);
            docObj = new JSONObject();
            docObj.put("Document", folderObj);
            kmlObj = new JSONObject();
            kmlObj.put("kml", docObj);

            System.out.println(kmlObj);
            Log.d("kml:", kmlObj + "");


            return kmlObj;
        }catch (Exception e)
        {
            e.printStackTrace();
        }

        return null;
    }

}
