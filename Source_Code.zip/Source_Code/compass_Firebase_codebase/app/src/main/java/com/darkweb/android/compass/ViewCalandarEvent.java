package com.darkweb.android.compass;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import com.darkweb.android.login.LoginActivity;
import com.darkweb.android.model.Age;
import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.adapter.CustomDateTimePicker;
import com.darkweb.android.model.User;
import com.darkweb.android.parser.JsontoObject;
import com.darkweb.android.adapter.NotificationAlarmManager;
import com.darkweb.android.service.UserService;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.like.IconType;
import com.like.LikeButton;
import com.like.OnLikeListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import at.blogc.android.views.ExpandableTextView;
import io.github.kobakei.materialfabspeeddial.FabSpeedDial;
import io.github.kobakei.materialfabspeeddial.FabSpeedDialMenu;

import static com.darkweb.android.compass.R.drawable.username;
//*sach this activity contains a lot of file read/write \
//this was the initial design. no new additions

public class ViewCalandarEvent extends AppCompatActivity {

    TextView organisation_name,event_Time,button_toggle,event_address,event_name,event_description1;
    ImageView iconImage;
    ExpandableTextView event_description;
    User user;
    FabSpeedDial fab;
    private Toolbar mTopToolbar;
    private ArrayList<CalandarEvent> calendarEventList;
    boolean check1;
    CalandarEvent calEventObj;
    LikeButton like;
    private String isBookmark;
    private File bookmarkFile;
    private String fileurl;
    private ArrayList<CalandarEvent> calendarEventList1;
    static ArrayList<String> array = new ArrayList<String>();
    private Calendar myCalendar1;
    private TextView event_name_textview;
    private TextView dilogue_date;
    private TextView expectingtime;
    private int hours,minutes;
    DatePickerDialog.OnDateSetListener addCalendarEventDateListener;
    private TableLayout tableLayout;
    LinearLayout eventLinearLayout ;
    ArrayList<FabSpeedDialMenu> menuList=new ArrayList<FabSpeedDialMenu>();
    private EditText yourAgeEditText;
    private Button submit1;
    private EditText addEventTimeEditText,addEventDateEditText;
    UserService userService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_calandar_event);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Event");
        setSupportActionBar(toolbar);

        userService = new UserService();
        user = userService.getUserSignedIn(ViewCalandarEvent.this);

        isBookmark = (String) getIntent().getStringExtra("bookmark");
        like = (LikeButton) findViewById(R.id.bookmark);
        organisation_name=(TextView)findViewById(R.id.organisation_name);
        event_Time=(TextView)findViewById(R.id.event_Time);
        event_name=(TextView)findViewById(R.id.event_name);
        button_toggle=(TextView)findViewById(R.id.button_toggle);
        event_address=(TextView)findViewById(R.id.event_address);
        eventLinearLayout=(LinearLayout)findViewById(R.id.event_linear_layout);
        ImageView imageView= findViewById(R.id.image_user_des);
        event_description=findViewById(R.id.event_description);
        fileurl = ViewCalandarEvent.this.getFilesDir().toString();
        bookmarkFile = new File(fileurl, getString(R.string.bookmarkCalendarEvent));
        calEventObj=(CalandarEvent) getIntent().getSerializableExtra(getString(R.string.calandarEventObject));

        String check=calEventObj.getEventDescription();
        if(check== null || check==" " || check==""){
            button_toggle.setText("");
        }else{
            imageView.setImageResource(username);
            if(check.length()<41){
                button_toggle.setText("");
            }else{
                button_toggle.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(final View v)
                    {
                        if (event_description.isExpanded())
                        {
                            event_description.collapse();
                            button_toggle.setText("Read More..");
                        }
                        else
                        {
                            event_description.expand();
                            button_toggle.setText("Read Less..");
                        }
                    }
                });
            }

        }




        if(calEventObj==null)
        {
            UUID uuid=(UUID) getIntent().getSerializableExtra("id");
            if(uuid!=null)
            {
                calEventObj= CalandarEvent.getCalendarEventObject(uuid,ViewCalandarEvent.this);
            }
        }
        organisation_name.setText(calEventObj.getOrganizationDescription().getOrganizationName());
        event_name.setText(calEventObj.getEventName());
        event_description.setText(calEventObj.getEventDescription());
        event_address.setText(calEventObj.getStreetAddress()+", "+calEventObj.getCity()+ ", "+calEventObj.getState()+", "+calEventObj.getZipcode()+ " .");
        organisation_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewCalandarEvent.this, ViewServices.class);
                intent.putExtra("serviceObject", calEventObj.getOrganizationDescription());
                startActivity(intent);
            }
        });
        if(calEventObj.getCriteriaMap()!=null && calEventObj.getCriteriaMap().size()>0)
        {
            for(Map.Entry<String, Object> mapObj:calEventObj.getCriteriaMap().entrySet())
            {
                if(mapObj.getKey().equals(getString(R.string.AgeCriteria)))
                {
                    Age ageObj=(Age)mapObj.getValue();
                    TextView ageTextView = new TextView(this);
                    ageTextView.setText("      Age  "+ageObj.getFromAge()+"  to   "+ageObj.getToAge());
                    ageTextView.setLayoutParams(new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.WRAP_CONTENT));
                    eventLinearLayout.addView(ageTextView);
                }
            }
        }


        if (calEventObj.getEventDateTime().toString().trim().length() > 0)
            event_Time.setText(calEventObj.getEventDateTime().toString());
        else
            event_Time.setText("N/A");

        event_address.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(event_address.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        mTopToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(mTopToolbar);


        fab = (FabSpeedDial) findViewById(R.id.addservicefab);

        if(new Date().compareTo(calEventObj.getEventDateTime()) >0 )
        {
            fab.setVisibility(View.GONE);
        }
        FabSpeedDialMenu menu = new FabSpeedDialMenu(this);
        menu.add("Remove Event from the calendar").setIcon(R.drawable.ic_close_black_24dp);
        menu.add("Edit Event from the calendar").setIcon(R.drawable.edit);
        menuList.add(menu);
        menu = new FabSpeedDialMenu(this);
        menu.add("Add to calendar").setIcon(R.drawable.ic_done_black_24dp);
        menuList.add(menu);

        boolean checkCalendarAdded=checkEventAdded(calEventObj);

        if (checkCalendarAdded)
        {

            fab.setMenu(menuList.get(0));

        }
        else
        {
            fab.setMenu(menuList.get(1));
        }
        this.check1=checkCalendarAdded;
       fab.addOnMenuItemClickListener(new FabSpeedDial.OnMenuItemClickListener() {
            @Override
            public void onMenuItemClick(FloatingActionButton miniFab, @Nullable TextView label, int itemId) {

                if(user==null)
                {
                    AlertDialog.Builder alertDialog=new AlertDialog.Builder(ViewCalandarEvent.this);
                    // Setting Dialog Title
                    alertDialog.setTitle("Sign In");
                    // Setting Dialog Message
                    alertDialog.setMessage("You need to sign In to add service. Would you like to sign in? ");
                    alertDialog.setCancelable(true);
                    // Setting alert dialog icon
                    alertDialog.setIcon(username);
                    alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(fab!=null)
                                fab.closeMenu();

                        }
                    });
                    // Setting OK Button
                    alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(ViewCalandarEvent.this, LoginActivity.class);
                            intent.putExtra(getString(R.string.itemId),itemId);
                            startActivityForResult(intent, 1);

                        }
                    });
                    alertDialog.show();


                }
                else
                {
                    showFabItemID(itemId);
                }


            }
        });

        if(user==null)
        {
            like.setLiked(false);
        }
        else
        {
            if (isBookmark != null) {
                if (isBookmark.equals("true")) {
                    like.setLiked(true);
                } else {
                    like.setLiked(false);
                }

            } else {
                if (JsontoObject.isBookmarkEventExist(calEventObj.getEventId(), bookmarkFile)) {
                    like.setLiked(true);
                } else {
                    like.setLiked(false);
                }
            }

        }


        like.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton)
            {
                if (user==null)
                {
                    Intent intent = new Intent(ViewCalandarEvent.this, LoginActivity.class);
                    startActivityForResult(intent, 2);
                    likeButton.setLiked(false);
                }
                else
                {
                    likeButton.setIcon(IconType.Star);
                    likeButton.setAnimationScaleFactor(8);
                    likeButton.setLiked(true);
                    addBookmarkFile();

                }
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                likeButton.setAnimationScaleFactor(4);
                likeButton.setLiked(false);

                try {
                    if (bookmarkFile.exists()) {
                        FileInputStream fileInputStream = new FileInputStream(bookmarkFile);
                        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                        calendarEventList1 = (ArrayList<CalandarEvent>) objectInputStream.readObject();
                        objectInputStream.close();
                        fileInputStream.close();
                        if (calendarEventList1 != null) {
                            calendarEventList1.remove(calEventObj);
                        }
                    }

                    //*sach file read/write detected
                    FileOutputStream fileOutputStream;
                    ObjectOutputStream objectOutputStream;
                    fileOutputStream = ViewCalandarEvent.this.getBaseContext().openFileOutput(bookmarkFile.getName(), Context.MODE_PRIVATE);
                    Log.d("filename:", bookmarkFile.getName());
                    objectOutputStream = new ObjectOutputStream(fileOutputStream);
                    objectOutputStream.writeObject(calendarEventList1);
                    objectOutputStream.close();

                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private void showFabItemID(int itemId) {
        if (itemId==1)
        {

            if (!check1) {
                Log.d("adding:","yes");

                AlertDialog.Builder alertDialog=new AlertDialog.Builder(ViewCalandarEvent.this);
                // Setting Dialog Title
                alertDialog.setTitle("Add Event");
                // Setting Dialog Message
                alertDialog.setMessage("Do you want to add this event? ");
                alertDialog.setCancelable(true);
                // Setting alert dialog icon
                alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(fab!=null)
                            fab.closeMenu();

                    }
                });
                // Setting OK Button
                alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        addNotificationEventCalendar(calEventObj);
                    }
                });
                alertDialog.show();

            }
            else
            {
                Log.d("Remove:","Remove event");

                AlertDialog.Builder alertDialog=new AlertDialog.Builder(ViewCalandarEvent.this);
                // Setting Dialog Title
                alertDialog.setTitle("Remove Event");
                // Setting Dialog Message
                alertDialog.setMessage("Do you want to remove this event? ");
                alertDialog.setCancelable(true);
                // Setting alert dialog icon
                alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(fab!=null)
                            fab.closeMenu();

                    }
                });
                // Setting OK Button
                alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        removeCalendarEvent(calEventObj);
                        Log.d("menulist:",menuList.get(0).size()+"");
                        fab.setMenu(menuList.get(1));
                        check1=false;

                    }
                });
                alertDialog.show();


            }
        }
        if (itemId==2)
        {
            addNotificationEventCalendar(calEventObj);

        }
    }


    //*sach - file read/write detected
    private boolean checkEventAdded(CalandarEvent calEventObj)
    {
        String url = ViewCalandarEvent.this.getFilesDir().toString();
        final File file = new File(url, getString(R.string.yourEventListFile));

        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                calendarEventList=(ArrayList<CalandarEvent>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (calendarEventList!=null)
                {
                    int i=-1;
                    for (i=0;i<calendarEventList.size();i++)
                    {
                        if (calEventObj.getEventId().equals(calendarEventList.get(i).getEventId()))
                        {
                            return true;
                        }
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    //*sach - file read/write detected
    private void removeCalendarEvent(CalandarEvent calEventObj)
    {
        String url = ViewCalandarEvent.this.getFilesDir().toString();
        final File file = new File(url, getString(R.string.yourEventListFile));
        new NotificationAlarmManager().cancelAlarmManager(calEventObj.getRequestCode(),ViewCalandarEvent.this);

        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                calendarEventList=(ArrayList<CalandarEvent>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (calendarEventList!=null)
                {
                    int i=-1;
                    for (i=0;i<calendarEventList.size();i++)
                    {
                        if (calEventObj.getEventId().equals(calendarEventList.get(i).getEventId()))
                        {
                            calendarEventList.remove(i);
                            break;
                        }
                    }
                    FileOutputStream fileOutputStream;
                    ObjectOutputStream objectOutputStream;
                    fileOutputStream = ViewCalandarEvent.this.getBaseContext().openFileOutput(file.getName(), Context.MODE_PRIVATE);
                    objectOutputStream = new ObjectOutputStream(fileOutputStream);
                    objectOutputStream.writeObject(calendarEventList);
                    objectOutputStream.close();
                    fileOutputStream.flush();
                    fileOutputStream.close();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //*sach - file read/write detected
    private void addCalendarEventToYour(CalandarEvent calEventObj) {
        String url = ViewCalandarEvent.this.getFilesDir().toString();
        final File file = new File(url, getString(R.string.yourEventListFile));
        try {
            Log.d("dateview:", ""+calEventObj.getEventDateTime()+" bool:"+(calEventObj==null));
            calEventObj.setRequestCode((int)calEventObj.getEventId().getLeastSignificantBits());
            new NotificationAlarmManager().addAlarmManager(calEventObj.getRequestCode(), calEventObj.getEventDateTime(),ViewCalandarEvent.this,calEventObj.getEventId(),getString(R.string.calandarEventObject));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                calendarEventList=(ArrayList<CalandarEvent>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (calendarEventList!=null)
                {
                    int i=-1;
                    for (i=0;i<calendarEventList.size();i++)
                    {
                        if (calEventObj.getEventId().equals(calendarEventList.get(i).getEventId()))
                        {
                           calendarEventList.set(i,calEventObj);
                            return;
                        }
                    }
                }
                else
                {
                    calendarEventList=new ArrayList<CalandarEvent>();
                }
                calendarEventList.add(0,calEventObj);
            }
            else
            {
                calendarEventList=new ArrayList<CalandarEvent>();
                calendarEventList.add(0,calEventObj);
            }
            FileOutputStream fileOutputStream;
            ObjectOutputStream objectOutputStream;
            fileOutputStream = ViewCalandarEvent.this.getBaseContext().openFileOutput(file.getName(), Context.MODE_PRIVATE);
            Log.d("filename:",file.getName());
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(calendarEventList);
            objectOutputStream.close();
           fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addNotificationEventCalendar(CalandarEvent calEventObj)
    {
        Date expectingDateandTime=calEventObj.getEventDateTime();
        myCalendar1= Calendar.getInstance();
        myCalendar1.setTime(expectingDateandTime);
        long diff = expectingDateandTime.getTime() - new Date().getTime();
        if(diff >(24 * 60 * 60 * 1000))
            myCalendar1.add(Calendar.DATE, -1);

        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        Dialog dialog1 = new Dialog(ViewCalandarEvent.this);

        dialog1.setContentView(R.layout.setcalendareventdialogue);
        dialog1.setTitle("Add Event to calendar");

        int width = (int)(getResources().getDisplayMetrics().widthPixels*0.90);
        dialog1.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);

        submit1 = dialog1.findViewById(R.id.dialog_submit);
        event_name_textview=(TextView)dialog1.findViewById(R.id.event_name_textview);
        event_description1 = (TextView)dialog1.findViewById(R.id.event_description);

        addEventDateEditText=(EditText) dialog1.findViewById(R.id.input_date);
        addEventTimeEditText=(EditText) dialog1.findViewById(R.id.input_time);

        event_name_textview.setText(calEventObj.getEventName());
        event_description1.setText(calEventObj.getEventDescription());

        yourAgeEditText=(EditText)dialog1.findViewById(R.id.your_age);
        Age ageObj=(Age)calEventObj.getCriteriaMap().get(getString(R.string.AgeCriteria));
        if(ageObj.getYourAge()!= -1)
        {
            yourAgeEditText.setText(ageObj.getYourAge()+"");
        }

        yourAgeEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    int yourAge = Integer.parseInt("" + s);
                    if(yourAge<=ageObj.getToAge() && yourAge>=ageObj.getFromAge())
                    {
                        ageObj.setYourAge(yourAge);
                        if(submit1!=null)
                            submit1.setEnabled(true);
                    }
                    else
                    {
                        yourAgeEditText.setError("Age must be from "+ageObj.getFromAge()+" to "+ageObj.getToAge());
                        submit1.setEnabled(false);
                    }
                }catch (Exception e)
                {

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        addEventTimeEditText.setText(expectingDateandTime.getHours()+" : "+expectingDateandTime.getMinutes());
        addEventDateEditText.setText(sdf.format(expectingDateandTime));

        addEventTimeEditText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                TimePickerDialog mTimePicker = CustomDateTimePicker.getCustomTimePickerDialogue(ViewCalandarEvent.this,addEventTimeEditText,myCalendar1.getTime(),new Date(),expectingDateandTime);

            }
        });
        addCalendarEventDateListener= CustomDateTimePicker.getCustomDatePicker(addEventDateEditText,expectingDateandTime,myCalendar1);

        addEventDateEditText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                DatePickerDialog datePicker=new DatePickerDialog(ViewCalandarEvent.this, addCalendarEventDateListener,
                        myCalendar1.get(Calendar.YEAR), myCalendar1.get(Calendar.MONTH),
                        myCalendar1.get(Calendar.DAY_OF_MONTH));
                datePicker.getDatePicker().setMaxDate(expectingDateandTime.getTime());
                datePicker.getDatePicker().setMinDate(new Date().getTime());
                datePicker.setCancelable(false);
                datePicker.show();
            }
        });

        updateLabel1();
        dialog1.show();
        submit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fab.setMenu(menuList.get(0));
                check1=true;
                Date expectingDateandTime=new Date(addEventDateEditText.getText().toString() + " " + addEventTimeEditText.getText().toString().replaceAll("\\s+", ""));
                calEventObj.setRemindarDateTime(expectingDateandTime);
                addCalendarEventToYour(calEventObj);
                try {
                    new NotificationAlarmManager().addAlarmManager(calEventObj.getRequestCode(),expectingDateandTime , ViewCalandarEvent.this, calEventObj.getEventId(), getString(R.string.calandarEventObject));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                dialog1.dismiss();
                if (dialog1!=null)
                    dialog1.dismiss();

            }
        });
    }
    private void updateLabel1() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        addEventDateEditText.setText(sdf.format(myCalendar1.getTime()));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        user = userService.getUserSignedIn(ViewCalandarEvent.this);

        if (requestCode == 1)
        {
            if (user != null)
            {
                if(data!=null) {
                    showFabItemID(data.getIntExtra(getString(R.string.itemId), 1));
                }
            }
            else
            {
                if(fab!=null)
                    fab.closeMenu();
            }
        }
        else  if(requestCode==2)
        {
            if (user != null)
            {
                Log.d("like:","3");

                like.setLiked(true);
                addBookmarkFile();
            }
            else
            {
                like.setLiked(false);
                if(fab!=null)
                    fab.closeMenu();
            }
        }
    }

    //*sach file read/write detected
    //bookmark functionality
    private void addBookmarkFile() {
        try {
            if (bookmarkFile.exists()) {
                FileInputStream fileInputStream = new FileInputStream(bookmarkFile);
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                calendarEventList1 = (ArrayList<CalandarEvent>) objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (calendarEventList1 != null) {
                    calendarEventList1.add(calEventObj);
                } else {
                    calendarEventList1 = new ArrayList<CalandarEvent>();
                    calendarEventList1.add(calEventObj);
                }
            } else {
                calendarEventList1 = new ArrayList<CalandarEvent>();
                calendarEventList1.add(calEventObj);
            }
            FileOutputStream fileOutputStream;
            ObjectOutputStream objectOutputStream;
            fileOutputStream = ViewCalandarEvent.this.getBaseContext().openFileOutput(bookmarkFile.getName(), Context.MODE_PRIVATE);
            Log.d("filename:", bookmarkFile.getName());
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(calendarEventList1);
            objectOutputStream.close();

            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        array.add(calEventObj.getEventId().toString());
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        ActivityManager mngr = (ActivityManager) getSystemService( ACTIVITY_SERVICE );

        List<ActivityManager.RunningTaskInfo> taskList = mngr.getRunningTasks(10);

        if(taskList.get(0).numActivities == 1 &&
                taskList.get(0).topActivity.getClassName().equals(this.getClass().getName())) {
            Intent intent=new Intent(ViewCalandarEvent.this,HomePage.class);
            startActivity(intent);

        }
        else
        {
            super.onBackPressed();
        }
    }
}
