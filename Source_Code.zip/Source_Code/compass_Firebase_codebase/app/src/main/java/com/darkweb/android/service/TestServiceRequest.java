package com.darkweb.android.service;

//Connor 2020.02.26 - Tow way communication
//sach updated with desired properties in ServiceRequestClient
/*
{
       "requestUID": bd5cde22-3826-4cd2-8177-7ddb2e169830,
        "organizationId": 49219,
        "userID":
        "serviceId": 36092,
        "requestDate":
        "comments": "Comments here"
        "eligibility": "Yet to be developed",
        "attachments" : "Yet to be added"

 }
 */
public class TestServiceRequest {
    private String DescriptiveTitle;
    private Integer OrganizationId;
    private Integer ProgramId;
    private Integer ServiceId;
    private Long UserId;
    private String mobileRequestId;
    private String eligibility;
    private String comments;

    public TestServiceRequest() {
    }

    public TestServiceRequest(String descriptiveTitle, Integer organizationId, Integer programId, Integer serviceId, Long userId, String mobileRequestId, String eligibility, String comments) {
        DescriptiveTitle = descriptiveTitle;
        OrganizationId = organizationId;
        ProgramId = programId;
        ServiceId = serviceId;
        UserId = userId;
        this.mobileRequestId = mobileRequestId;
        this.eligibility = eligibility;
        this.comments = comments;
    }

    public String getDescriptiveTitle() {
        return DescriptiveTitle;
    }

    public void setDescriptiveTitle(String descriptiveTitle) {
        DescriptiveTitle = descriptiveTitle;
    }

    public Integer getOrganizationId() {
        return OrganizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        OrganizationId = organizationId;
    }

    public Integer getProgramId() {
        return ProgramId;
    }

    public void setProgramId(Integer programId) {
        ProgramId = programId;
    }

    public Integer getServiceId() {
        return ServiceId;
    }

    public void setServiceId(Integer serviceId) {
        ServiceId = serviceId;
    }

    public Long getUserId() {
        return UserId;
    }

    public void setUserId(Long userId) {
        UserId = userId;
    }

    public String getMobileRequestId() {
        return mobileRequestId;
    }

    public void setMobileRequestId(String mobileRequestId) {
        this.mobileRequestId = mobileRequestId;
    }

    public String getEligibility() {
        return eligibility;
    }

    public void setEligibility(String eligibility) {
        this.eligibility = eligibility;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
