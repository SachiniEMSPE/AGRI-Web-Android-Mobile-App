package com.darkweb.android.model;

public class SearchAdapterList {

    private String listItem;

    public SearchAdapterList(String listItem) {
        this.listItem = listItem;
    }

    public String getListItem() {
        return listItem;
    }
}
