package com.darkweb.android.adapter;

import android.util.Log;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.darkweb.android.agri.Fragment_F1;
import com.darkweb.android.agri.Fragment_F2;
import com.darkweb.android.agri.Fragment_F3;
import com.darkweb.android.agri.Fragment_F4;
import com.darkweb.android.compass.Fragment1;
import com.darkweb.android.compass.Fragment2;
import com.darkweb.android.compass.Fragment3;
import com.darkweb.android.compass.FragmentBookmark;
import com.darkweb.android.compass.FragmentCalendarView;
import com.darkweb.android.compass.Service_tab;
import com.darkweb.android.compass.fragments.FragmentMyService;

public class Page_adapter_services extends FragmentStatePagerAdapter {

        int mNumOfTabs;
        FragmentCalendarView fragmentCalendarView;

        public Page_adapter_services(FragmentManager fm, int NumOfTabs) {
            super(fm);
            this.mNumOfTabs = NumOfTabs;
        }

    @Override
    public Fragment getItem(int position) {
        FragmentMyService fragmentMyService = new FragmentMyService();
        switch (position) {
            case 0:
                return new Fragment_F1(); //fragmentMyService
            case 1:
                return new Fragment_F2(); //FragmentBookmark();
            case 2:
                return new Fragment_F3();//Service_tab();//;
            case 3:
                return new Fragment_F4();//Service_tab();//;
            default:
                return null;
        }
    }


        public int getCount() {
            return mNumOfTabs;
        }
}
