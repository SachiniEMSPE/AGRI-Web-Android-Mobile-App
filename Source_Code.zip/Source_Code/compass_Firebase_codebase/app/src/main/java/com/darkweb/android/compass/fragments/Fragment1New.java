package com.darkweb.android.compass.fragments;


import android.Manifest;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;

import android.content.Intent;

import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.darkweb.android.compass.R;
import com.darkweb.android.compass.ServiceRequest;
import com.darkweb.android.model.CategoryList;
import com.darkweb.android.model.ObjectsForMapper.Organization;
import com.darkweb.android.service.OrganizationServiceV2;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * I don't know why they called this fragment fragment 1,
 * but that was the name
 */
public class Fragment1New extends Fragment implements
        OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener, DatePickerDialog.OnDateSetListener,
        GoogleMap.OnCameraIdleListener
{

    // maybe could move into local
    private View view;
    private OrganizationServiceV2 organizationService;
    private List<Organization> organizations;
    private CategoryList categoryList = new CategoryList();
    private CategoryList sortingOptions = new CategoryList();
    private ArrayList<String> categories = new ArrayList<>();
    // UIs
    private ImageButton filter;
    private AutoCompleteTextView organizationAutoTextView;
    private ListView servicesListView;
    private FloatingActionButton fab;
    // Google map related
    private GoogleApiClient client;
    private GoogleMap mMap;

    // Preparing the layout
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_1, container, false);
        organizationService = new OrganizationServiceV2(getActivity());
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        filter = view.findViewById(R.id.filterButton);
        filter.setEnabled(false);
        // This is where user can search organization by name in the toolbar at homepage
        organizationAutoTextView = view.findViewById(R.id.Organization_name_searchview);
        organizationAutoTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("TODO: Search function is waiting to be implemented.");
            }
        });

        servicesListView = view.findViewById(R.id.servicelist);

        // Floating Action Button
        fab = view.findViewById(R.id.fab);
        fab.setOnClickListener(view1 -> {
            Intent i = new Intent(Fragment1New.this.getActivity(), ServiceRequest.class);
            startActivity(i);
        });

        // Checking if GPS is allowed
        // If now allowed, ask user to enable GPS accessing
        SupportMapFragment supportMapFragment =
                (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map);
        assert supportMapFragment != null;
        supportMapFragment.getMapAsync((OnMapReadyCallback) this);
        LocationManager lm = (LocationManager)
                Objects.requireNonNull(getContext()).getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (!gps_enabled) {
            new AlertDialog.Builder(getContext())
                    .setMessage("Please enable GPS")
                    .setPositiveButton("Open GPS settings",
                            (dialogInterface, i) -> getContext().startActivity(
                            new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("Cancel", null)
                    .show();
        }
        // rendering organizations markers on the map
        new GetCourseCategoriesMarkerColor().execute();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // double check if location access is allowed
        if (ContextCompat.checkSelfPermission(Objects.requireNonNull(this.getActivity()),
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setZoomControlsEnabled(true);
            mMap.setMyLocationEnabled(true);
        }
        mMap.setOnCameraIdleListener(this);
    }

    // establish connecting with Google Map services
    private synchronized void buildGoogleApiClient() {
        client = new GoogleApiClient.Builder(Objects.requireNonNull(this.getActivity()))
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        client.connect();
    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onCameraIdle() {

    }


    // Organizations list related private methods
    private class GetCourseCategoriesMarkerColor extends AsyncTask<Void, Void, Void> {
        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // displaying loading status when map is loading
            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setMessage("Loading map ...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        // fetching the organization list
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                // fetching the organization list from backend
                organizations = organizationService.getOrganizationsFromBackend();
            } catch (IOException e) {
                e.printStackTrace();
            }
            categoryList.setCategoryName("Categories");
            asynkBackGroundMethod();
            return null;
        }

        // map the organization list to the map
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            try {
                asynkPostExecuteMethod();
                organizationService.renderListToMap(organizations, mMap);
                if (progressDialog.isShowing()) progressDialog.dismiss();
            } catch (Exception e) {
                System.out.println("Exception: " + e);
            }
        }
    }

    private void asynkPostExecuteMethod() {
//        organizationAutoTextView.setAdapter();
    }

    private void asynkBackGroundMethod() {
//        organizationService.pushMarkersToList();
    }
}
