package com.darkweb.android.model;

import android.content.Context;
import android.widget.SeekBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by kotak on 30/07/2018.
 */

public class Seekbar {
    private static List<String> timeStringIntervals;

    public static void setSeekBarProperties(SeekBar seekBar, Date date1, TableLayout tableLayout, Context context)
    {
        int seekBarValue = seekBar.getProgress();
        int maxValue = seekBar.getMax();
        if(date1==null)
            date1=new Date();
        seekBar.setProgress((date1.getHours()*4) +(date1.getMinutes()/15));
        seekBar.setMax(24 * 4); //24 hours and 4 step in one hour.

        TableRow tableRows = new TableRow(context);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        tableRows.setLayoutParams(lp);
        tableRows.setWeightSum(2.0f);
        tableRows.setPadding(5, 5, 5, 5);
        timeStringIntervals=getIntervals();
        for (int i = 0; i < timeStringIntervals.size(); i++) {
            TextView text = new TextView(context);

            text.setLayoutParams(new android.widget.TableRow.LayoutParams(android.widget.TableRow.LayoutParams.WRAP_CONTENT,
                    android.widget.TableRow.LayoutParams.WRAP_CONTENT, 1.0f));
            text.setText(timeStringIntervals.get(i));
            tableRows.addView(text);
        }
        tableLayout.addView(tableRows);



    }

    private static List<String> getIntervals() {
        return new ArrayList<String>() {{
            add("0");
            add("2");
            add("4");
            add("6");
            add("8");
            add("10");
            add("12");
            add("14");
            add("16");
            add("18");
            add("20");
            add("22");
            add("24");

        }};
    }
}
