package com.darkweb.android.compass;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.darkweb.android.adapter.CustomObjectListAdapter;
import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.NewsFeedDateComparator;
import com.darkweb.android.model.NewsFeedNameComparator;
import com.darkweb.android.model.ServiceDetails;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

import androidx.annotation.*;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import at.blogc.android.views.ExpandableTextView;

/**
 * Created by kotak on 26/07/2018.
 */

@SuppressLint("ValidFragment")
public class FragmentNewsFeed extends Fragment {


    private View view;
    private String url;
    private ArrayList<OrganizationDescription> organizationDescriptionArrayList =new ArrayList<OrganizationDescription>();
    private ArrayList<Object> currentNewsFeedList=new ArrayList<Object>();
    private File myEventsFile;
    private ArrayList<CalandarEvent> calendarEventList=new ArrayList<CalandarEvent>();
    ImageButton filter  , search;
    private Dialog mdialog;
    private Button apply_dialogue_button;
    private Button cancel_dialogue_button;
    private Spinner sort;
    private String sortby_dialogue;
    private ListView pendingListView;
    private CustomObjectListAdapter serviceListAdapter;
    private EditText search_service;
    private File myBookmarkEventsFile;
    private ArrayList<CalandarEvent> bookmarkCalendarEventList;
    private LinearLayout viewCheckBox;
    private String[] checkBoxStringArray;
    private ArrayList<CheckBox> checkBoxArray;
    private boolean ischecked;
    private int selectedSort=-1;
    TextView resetAll;
    TextView button_toggle1,button_toggle2,button_toggle3,button_toggle4,button_toggle51,button_toggle52,button_toggle53,button_toggle54,button_toggle6; //sach added to read more buttons
    ExpandableTextView news_description1,news_description2,news_description3,news_description4,news_description51,news_description52,news_description53,news_description54,news_description6;
    TextView news_address1,news_address2,news_address3,news_address4,news_address51,news_address52,news_address53,news_address54,news_address6,
            news_phone4,news_phone51,news_phone52,news_phone53,news_phone54,news_phone6,
            email51,email52,email53,email54,email6,
    web51,web52,web53,web54;
    /* sach 03.14.2021
    fragment_my_services.xml was initially linked with NewsFeed. fragment_news_feed.xml is linked to show news as texts. <current design>
     */
    public FragmentNewsFeed() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        return inflater.inflate(R.layout.fragment_news_feed, container, false);

    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view=view;
        sortby_dialogue =getString(R.string.alphanumeric_sortby_service_request );
        url = getActivity().getFilesDir().toString();
        filter = view.findViewById(R.id.filterservices);

        search_service = (EditText)view.findViewById(R.id.inpt_search_services);

        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mdialog==null)
                {
                    mdialog = new Dialog(getActivity());
                    mdialog.setContentView(R.layout.filter_service_dialog);
                }
                mdialog.setTitle("Filter Box");
                mdialog.setCancelable(false);
                apply_dialogue_button=(Button)mdialog.findViewById(R.id.apply_my_servicefilter);
                cancel_dialogue_button=(Button)mdialog.findViewById(R.id.cancel_my_servicefilter);
                sort =(Spinner) mdialog.findViewById(R.id.sortby_myservice_spinner);
                viewCheckBox=(LinearLayout) mdialog.findViewById(R.id.view_checkbox);
                resetAll=(TextView)mdialog.findViewById(R.id.reset_all);
                checkBoxStringArray=getResources().getStringArray(R.array.newsFeedCheckBox);
                if(checkBoxArray==null )
                {
                    if(checkBoxStringArray.length>0)
                    {
                        checkBoxArray =new ArrayList<CheckBox>();
                    }
                    for(int i=0;i<checkBoxStringArray.length;i++)
                    {
                        CheckBox c=new CheckBox(getActivity());
                        c.setText(checkBoxStringArray[i]);
                        viewCheckBox.addView(c);
                        checkBoxArray.add(c);
                    }
                }
                else
                {
                    if(checkBoxArray.size()>0)
                    {
                        ischecked=checkBoxArray.get(0).isChecked();
                    }
                }
                mdialog.show();
                selectedSort=sort.getSelectedItemPosition();
                sort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        sortby_dialogue=parent.getItemAtPosition(position).toString();
                        Log.d("sort:",sortby_dialogue);
                        sort.setSelection(position);
                     }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                cancel_dialogue_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (checkBoxArray!=null && checkBoxArray.size()>0)
                            checkBoxArray.get(0).setChecked(ischecked);
                        if(selectedSort>=0)
                        {
                            sort.setSelection(selectedSort);
                        }
                        mdialog.dismiss();
                    }
                });
                apply_dialogue_button.setOnClickListener(new View.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public void onClick(View v) {
                        //updateServiceRequest();

                        updateEventList(search_service.getText().toString(),sortby_dialogue, checkBoxArray);

                        mdialog.hide();
                    }
                });
                resetAll.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (checkBoxArray!=null && checkBoxArray.size()>0)
                            checkBoxArray.get(0).setChecked(false);
                        if (sort!=null)
                            sort.setSelection(0);

                    }
                });
            }
        });

        /*
        sach added these read more click events per each news.
         */
        news_description1 =  view.findViewById(R.id.news_description1);
        news_description2 =  view.findViewById(R.id.news_description2);
        news_description3 =  view.findViewById(R.id.news_description3);
        news_description4 =  view.findViewById(R.id.news_description4);
        news_description51 =  view.findViewById(R.id.news_description51);
        news_description52 =  view.findViewById(R.id.news_description52);
        news_description53 =  view.findViewById(R.id.news_description53);
        news_description54 =  view.findViewById(R.id.news_description54);
        news_description6 =  view.findViewById(R.id.news_description6);

        button_toggle1 = view.findViewById(R.id.button_toggle1);  //Button for read more attribute
        button_toggle2 = view.findViewById(R.id.button_toggle2);  //Button for read more attribute
        button_toggle3 = view.findViewById(R.id.button_toggle3);  //Button for read more attribute
        button_toggle4 = view.findViewById(R.id.button_toggle4);  //Button for read more attribute
        button_toggle51 = view.findViewById(R.id.button_toggle51);  //Button for read more attribute
        button_toggle52 = view.findViewById(R.id.button_toggle52);  //Button for read more attribute
        button_toggle53 = view.findViewById(R.id.button_toggle53);  //Button for read more attribute
        button_toggle54 = view.findViewById(R.id.button_toggle54);  //Button for read more attribute
        button_toggle6 = view.findViewById(R.id.button_toggle6);  //Button for read more attribute

        news_address1 = view.findViewById(R.id.news_address);
        news_address2 = view.findViewById(R.id.news_address2);
        news_address3 = view.findViewById(R.id.news_address3);
        news_address4 = view.findViewById(R.id.news_address4);
        news_address51 = view.findViewById(R.id.news_address51);
        news_address52 = view.findViewById(R.id.news_address52);
        news_address53 = view.findViewById(R.id.news_address53);
        news_address54 = view.findViewById(R.id.news_address54);
        news_address6 = view.findViewById(R.id.news_address6);

        news_phone4 = view.findViewById(R.id.news_phone4);
        news_phone51 = view.findViewById(R.id.news_phone51);
        news_phone52 = view.findViewById(R.id.news_phone52);
        news_phone53 = view.findViewById(R.id.news_phone53);
        news_phone54 = view.findViewById(R.id.news_phone54);
        news_phone6 = view.findViewById(R.id.news_address6);

        email51 = view.findViewById(R.id.news_email51);
        email52 = view.findViewById(R.id.news_email52);
        email53 = view.findViewById(R.id.news_email53);
        email54 = view.findViewById(R.id.news_email54);
        email6 = view.findViewById(R.id.news_email6);

        web51 = view.findViewById(R.id.news_web51);
        web52 = view.findViewById(R.id.news_web52);
        web53 = view.findViewById(R.id.news_web53);
        web54 = view.findViewById(R.id.news_web54);


        button_toggle1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description1.isExpanded())
                {
                    news_description1.collapse();
                    button_toggle1.setText("Read More...");
                }
                else
                {
                    news_description1.expand();
                    button_toggle1.setText("Read Less...");
                }
            }
        });

        button_toggle2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description2.isExpanded())
                {
                    news_description2.collapse();
                    button_toggle2.setText("Read More...");
                }
                else
                {
                    news_description2.expand();
                    button_toggle2.setText("Read Less...");
                }
            }
        });

        button_toggle3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description3.isExpanded())
                {
                    news_description3.collapse();
                    button_toggle3.setText("Read More...");
                }
                else
                {
                    news_description3.expand();
                    button_toggle3.setText("Read Less...");
                }
            }
        });

        button_toggle4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description4.isExpanded())
                {
                    news_description4.collapse();
                    button_toggle4.setText("Read More...");
                }
                else
                {
                    news_description4.expand();
                    button_toggle4.setText("Read Less...");
                }
            }
        });

        button_toggle51.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description51.isExpanded())
                {
                    news_description51.collapse();
                    button_toggle51.setText("Read More...");
                }
                else
                {
                    news_description51.expand();
                    button_toggle51.setText("Read Less...");
                }
            }
        });

        button_toggle52.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description52.isExpanded())
                {
                    news_description52.collapse();
                    button_toggle52.setText("Read More...");
                }
                else
                {
                    news_description52.expand();
                    button_toggle52.setText("Read Less...");
                }
            }
        });

        button_toggle53.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description53.isExpanded())
                {
                    news_description53.collapse();
                    button_toggle53.setText("Read More...");
                }
                else
                {
                    news_description53.expand();
                    button_toggle53.setText("Read Less...");
                }
            }
        });

        button_toggle54.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description54.isExpanded())
                {
                    news_description54.collapse();
                    button_toggle54.setText("Read More...");
                }
                else
                {
                    news_description54.expand();
                    button_toggle54.setText("Read Less...");
                }
            }
        });

        button_toggle6.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
                if (news_description6.isExpanded())
                {
                    news_description6.collapse();
                    button_toggle6.setText("Read More...");
                }
                else
                {
                    news_description6.expand();
                    button_toggle6.setText("Read Less...");
                }
            }
        });

        news_address1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address1.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        news_address2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address2.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        news_address3.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address3.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        news_address4.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address4.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        news_address51.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address51.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        news_address52.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address53.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        news_address53.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address54.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        news_address54.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address54.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        news_address6.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(news_address6.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        news_phone4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:" + news_phone4.getText()));
                try {
                    if (Build.VERSION.SDK_INT > 22) {
                        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CALL_PHONE}, 101);

                            return;
                        }

                        startActivity(phoneIntent);

                    } else {
                        startActivity(phoneIntent);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });
        news_phone51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:" + news_phone51.getText()));
                try {
                    if (Build.VERSION.SDK_INT > 22) {
                        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CALL_PHONE}, 101);

                            return;
                        }

                        startActivity(phoneIntent);

                    } else {
                        startActivity(phoneIntent);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });
        news_phone52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:" + news_phone52.getText()));
                try {
                    if (Build.VERSION.SDK_INT > 22) {
                        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CALL_PHONE}, 101);

                            return;
                        }

                        startActivity(phoneIntent);

                    } else {
                        startActivity(phoneIntent);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });
        news_phone53.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:" + news_phone53.getText()));
                try {
                    if (Build.VERSION.SDK_INT > 22) {
                        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CALL_PHONE}, 101);

                            return;
                        }

                        startActivity(phoneIntent);

                    } else {
                        startActivity(phoneIntent);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });
        news_phone54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:" + news_phone54.getText()));
                try {
                    if (Build.VERSION.SDK_INT > 22) {
                        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CALL_PHONE}, 101);

                            return;
                        }

                        startActivity(phoneIntent);

                    } else {
                        startActivity(phoneIntent);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });
        news_phone6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:" + news_phone6.getText()));
                try {
                    if (Build.VERSION.SDK_INT > 22) {
                        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CALL_PHONE}, 101);

                            return;
                        }

                        startActivity(phoneIntent);

                    } else {
                        startActivity(phoneIntent);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });

        email51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mailIntent = new Intent(Intent.ACTION_VIEW);
                Uri data = Uri.parse("mailto:?to=" + email51.getText());
                mailIntent.setData(data);
                startActivity(mailIntent);
            }
        });
        email52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mailIntent = new Intent(Intent.ACTION_VIEW);
                Uri data = Uri.parse("mailto:?to=" + email52.getText());
                mailIntent.setData(data);
                startActivity(mailIntent);
            }
        });
        email53.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mailIntent = new Intent(Intent.ACTION_VIEW);
                Uri data = Uri.parse("mailto:?to=" + email53.getText());
                mailIntent.setData(data);
                startActivity(mailIntent);
            }
        });
        email54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mailIntent = new Intent(Intent.ACTION_VIEW);
                Uri data = Uri.parse("mailto:?to=" + email54.getText());
                mailIntent.setData(data);
                startActivity(mailIntent);
            }
        });
        email6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mailIntent = new Intent(Intent.ACTION_VIEW);
                Uri data = Uri.parse("mailto:?to=" + email6.getText());
                mailIntent.setData(data);
                startActivity(mailIntent);
            }
        });

        web51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(service_website.getText().toString()));
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(web51.getText().toString()));
                startActivity(browserIntent);
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onResume() {
        super.onResume();
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream ;
        myEventsFile=new File(url,getString(R.string.locationDescriptionEventList));
        if (myEventsFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(myEventsFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                organizationDescriptionArrayList = (ArrayList<OrganizationDescription>) objectInputStream.readObject();
                if (calendarEventList==null)
                {
                    calendarEventList=new ArrayList<CalandarEvent>();
                }
                else
                {
                    if(calendarEventList.size()>0) {
                        Log.d("clear:","calendar event list");
                        calendarEventList.clear();
                    }
                }
                for (OrganizationDescription locObj: organizationDescriptionArrayList)
                {
                    calendarEventList.addAll(locObj.getOrganisationEventList());
                }
                objectInputStream.close();
                fileInputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        Log.d("locDescList:", organizationDescriptionArrayList.size()+" "+calendarEventList.size());
        myBookmarkEventsFile=new File(url,getString(R.string.bookmarkCalendarEvent));
        if (myBookmarkEventsFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(myBookmarkEventsFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                bookmarkCalendarEventList = (ArrayList<CalandarEvent>) objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();

            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }

        updateEventList(null,sortby_dialogue, checkBoxArray);
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    public void updateEventList(String searchText, String sortByItem, ArrayList<CheckBox> checkBoxArray)
    {

        currentNewsFeedList.clear();
        if (searchText!=null)
            Log.d("searchText:",searchText);

        if(searchText!=null && !searchText.equals(""))
        {
            if (checkBoxArray!=null && checkBoxArray.size()>0 && checkBoxArray.get(0).isChecked())
            {
                if (bookmarkCalendarEventList!=null)
                {
                    for(CalandarEvent calEventObj: bookmarkCalendarEventList)
                    {
                        if( calEventObj.getEventName().contains(searchText) || calEventObj.getEventDateTime().toString().contains(searchText) || calEventObj.getEventDescription().contains(searchText) || calEventObj.getStreetAddress().contains(searchText) || calEventObj.getCity().contains(searchText) || calEventObj.getState().contains(searchText) ||   calEventObj.getZipcode().contains(searchText))
                        {
                            currentNewsFeedList.add(calEventObj);
                        }
                    }
                }
            }
            else
            {
                Log.d("search:",searchText);
                if(organizationDescriptionArrayList !=null && organizationDescriptionArrayList.size()>0)
                {
                    for(OrganizationDescription locationobj: organizationDescriptionArrayList)
                    {
                        if (locationobj.getOrganizationName().contains(searchText) || locationobj.getCategory().contains(searchText) || locationobj.getContact().contains(searchText) || locationobj.getZipcode().contains(searchText) || locationobj.getState().contains(searchText) || locationobj.getCity().contains(searchText) || locationobj.getDescription().contains(searchText)||locationobj.getEmailId().contains(searchText)||locationobj.getStreetAddress().contains(searchText)||locationobj.getWebsite().contains(searchText))
                        {
                            currentNewsFeedList.addAll(locationobj.getOrganisationEventList());
                        }
                        else
                        {
                            for(CalandarEvent calEventObj:locationobj.getOrganisationEventList())
                            {
                                if( calEventObj.getEventName().contains(searchText) || calEventObj.getEventDateTime().toString().contains(searchText) || calEventObj.getEventDescription().contains(searchText) || calEventObj.getStreetAddress().contains(searchText) || calEventObj.getCity().contains(searchText) || calEventObj.getState().contains(searchText) ||   calEventObj.getZipcode().contains(searchText))
                                {
                                    currentNewsFeedList.add(calEventObj);
                                }
                            }
                        }
                    }
                }
            }
        }
        else
        {
            Log.d("null:",(calendarEventList==null)+"");

            if (checkBoxArray!=null && checkBoxArray.size()>0 && checkBoxArray.get(0).isChecked())
            {
                if (bookmarkCalendarEventList!=null)
                currentNewsFeedList.addAll(bookmarkCalendarEventList);
            }
            else
            {

                currentNewsFeedList.addAll(calendarEventList);
            }

        }

        if(sortByItem!=null && !sortByItem.equals(""))
        {

           // newFeedSort(currentNewsFeedList,sortByItem);
            if(sortByItem.equals(getString(R.string.alphanumeric_sortby_service_request)))
            {
                Collections.sort(currentNewsFeedList,new NewsFeedNameComparator());
               //currentNewsFeedList.sort(Comparator.comparing(NewsFeedNameComparator::));
            }
            else if(sortByItem.equals(getString(R.string.lastupdated_sortby_service_request)))
            {
                Log.d("last:","addeed"+currentNewsFeedList.size());
                Collections.sort(currentNewsFeedList,new NewsFeedDateComparator());
            }
        }

        /* sach commented to add news text
        if(pendingListView==null)
        {
            pendingListView=(ListView)view.findViewById(R.id.my_service_list_view);
        }
         */

        if (serviceListAdapter==null)
        {
            Log.d("size:",calendarEventList.size()+" newsfed:"+currentNewsFeedList.size());

            serviceListAdapter=new CustomObjectListAdapter(getActivity(), currentNewsFeedList);
            /* sach commented to add news text
           if (serviceListAdapter.getCount()>0)
                pendingListView.setAdapter(serviceListAdapter);
            */
        }


        else
        {
            serviceListAdapter.notifyDataSetChanged();
        }

        if (search_service!=null)
        {
            search_service.addTextChangedListener(new TextWatcher() {

                @Override
                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                    // When user changed the Text

                    String text = search_service.getText().toString().toLowerCase(Locale.getDefault());
                    //FragmentMyService.this.serviceListAdapter.getFilter().filter(cs);
                    if (serviceListAdapter!=null)
                        serviceListAdapter.filter(text);
                }

                @Override
                public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                              int arg3) {

                }

                @Override
                public void afterTextChanged(Editable arg0) {

                }
            });
        }

        /* sach commented to add news text
        pendingListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object object=currentNewsFeedList.get(position);
               if(object instanceof CalandarEvent) {
                   Intent i = new Intent(getActivity(),ViewCalandarEvent.class);
                   i.putExtra(getString(R.string.calandarEventObject), (CalandarEvent)object);

                   startActivity(i);
               }
               else if(object instanceof  ServiceDetails)
               {

               }
            }
        });
        */
    }


    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
