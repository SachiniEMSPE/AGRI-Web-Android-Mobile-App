package com.darkweb.android.parser;

import android.os.Build;

import com.darkweb.android.global.MyBackendLinks;
import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.ObjectsForMapper.Organization;
import com.darkweb.android.model.ObjectsForMapper.Program;
import com.darkweb.android.model.ObjectsForMapper.Service;
import com.darkweb.android.model.ObjectsForMapper.Taxonomy;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import androidx.annotation.RequiresApi;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class JsontoObject {

	/**
	 * Code below for sending unsafe http request
	 * @return unsafe Http Client
	 */
	private static OkHttpClient getUnsafeOkHttpClient() {
		try {
			// Create a trust manager that does not validate certificate chains
			final TrustManager[] trustAllCerts = new TrustManager[] {
					new X509TrustManager() {
						@Override
						public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
						}

						@Override
						public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
						}

						@Override
						public java.security.cert.X509Certificate[] getAcceptedIssuers() {
							return new java.security.cert.X509Certificate[]{};
						}
					}
			};

			// Install the all-trusting trust manager
			final SSLContext sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
			// Create an ssl socket factory with our all-trusting manager
			final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

			OkHttpClient.Builder builder = new OkHttpClient.Builder();
			builder.sslSocketFactory(sslSocketFactory, (X509TrustManager)trustAllCerts[0]);
			builder.hostnameVerifier(new HostnameVerifier() {
				@Override
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			});

			OkHttpClient okHttpClient = builder.build();
			return okHttpClient;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@RequiresApi(api = Build.VERSION_CODES.N)
	public static ArrayList<OrganizationDescription> jsonToObjectData(InputStream is) throws IOException {
		ArrayList<OrganizationDescription> organizationDescriptionArray =new ArrayList<OrganizationDescription>();


		/**
		 * Instead of fetching objects from file input,
		 * lets fetch from an URL
		 */
		/**
		 * Step 1: Using OkHttp Client to fetch the json string
		 */
		OkHttpClient client = getUnsafeOkHttpClient();
		String myUrl = new MyBackendLinks().adminEndPoint + "organization10/105";
		Request request = new Request.Builder()
				.url(myUrl)
				.build();
		// Hopefully this request will get response from server
		Response response = client.newCall(request).execute();
		if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
		String responseStr = response.body().string();
		System.out.println("BACKEND Server: " + response.header("Server"));
		System.out.println("BACKEND Date: " + response.header("Date"));
		System.out.println("BACKEND Vary: " + response.headers("Vary"));
		System.out.println("BACKEND HEAD: " + response.headers());
		System.out.println("BACKEND Status: " + response.code());

		// uncomment below for Debugging
		System.out.println("BACKEND-server RESPONSE: " + responseStr);
		/**
		 * Step 2: Mapping JSON string to list of organizations
		 */
		ObjectMapper mapper = new ObjectMapper();


		List<Organization> organizations = mapper.readValue(responseStr, new TypeReference<List<Organization>>() {});
		/**
		 * Step 3: Mapping organizations detail into organizationDescriptionArray
		 * We have no needs to read and parse the String from file any more :)
		 */
		for (Organization organization: organizations) {

			String Website = "" ;
			String WebsiteInitial = organization.getWebAddress();

			if (WebsiteInitial.equals("")){
				WebsiteInitial = "N/A";
			}
			if(WebsiteInitial.contains("http://") || WebsiteInitial.equals("N/A")){
				Website = WebsiteInitial;
			}else {
				Website = "http://" + WebsiteInitial;
			}

			OrganizationDescription organizationDescription =new OrganizationDescription();//sach
			organizationDescription.setOrganizationName(organization.getName());
			organizationDescription.setOrganizationID(organization.getId().toString());//sach added
			organizationDescription.setContact(organization.getPhone());
			organizationDescription.setDescription(organization.getDescription());
			organizationDescription.setHours(organization.getHours());
			organizationDescription.setLanguages(organization.getLanguageSpoken());
			organizationDescription.setEmailId(organization.getEmail());
			organizationDescription.setLongitude(organization.getLongitude().toString());
			organizationDescription.setLatitude(organization.getLatitude().toString());
			organizationDescription.setStreetAddress(organization.getPhysicalStreetAddress1());
			organizationDescription.setCity(organization.getPhysicalCity());
			organizationDescription.setState(organization.getPhysicalState());
			organizationDescription.setZipcode(organization.getPhysicalZipCode());
			organizationDescription.setWebsite(Website);

			//sach many array lists here
			//sach_created program names array - to store names of programmes per org object
			ArrayList <String> programArrayNames= new ArrayList<>();
			ArrayList<ArrayList<String>> serviceArrayNames= new ArrayList<>();
			ArrayList <String> programArrayUIDs= new ArrayList<>();
			ArrayList<ArrayList<String>> serviceArrayUIDs= new ArrayList<>();
			ArrayList<ArrayList<String>> ServiceArrayDescription = new ArrayList<>();
			ArrayList<ArrayList<String>> ServiceArrayEligibility = new ArrayList<>();
			ArrayList<ArrayList<String>> ServiceArraySpecificHours = new ArrayList<>();
			ArrayList<ArrayList<String>> ServiceArrayAdditionalReq = new ArrayList<>();

			ArrayList<String> taxCategoryArrayList = new ArrayList<>();

			String Category = "";

			for (Program program : organization.getPrograms()) {

				String programName = program.getName();
				String programUID = program.getId().toString();
				programArrayNames.add(programName);
				programArrayUIDs.add(programUID);

				ArrayList<String> subServiceArrayNames = new ArrayList<>();
				ArrayList<String> subServiceArrayUIDs = new ArrayList<>();
				ArrayList<String> subServiceArrayDescription = new ArrayList<>();
				ArrayList<String> subServiceArrayEligibility = new ArrayList<>();
				ArrayList<String> subServiceSpecificHours = new ArrayList<>();
				ArrayList<String> subServiceArrayAdditionalReq = new ArrayList<>();

				ArrayList<String> subTaxCategoryArrayList =new ArrayList<>();

				for (Service service : program.getServices()) {

					String serviceName = service.getName();
					subServiceArrayNames.add(serviceName);
					String serviceUID = service.getId().toString();
					subServiceArrayUIDs.add(serviceUID);
					String serviceDescription = service.getDescription();
					if(serviceDescription.isEmpty()){
						subServiceArrayDescription.add("Description : N/A");
					}else{
						subServiceArrayDescription.add(serviceDescription.trim());
					}
					String serviceEligibility = service.getEligibility();
					if(serviceEligibility.isEmpty()){
						subServiceArrayEligibility.add("N/A");
					}else {
						subServiceArrayEligibility.add(serviceEligibility.trim());
					}
					String serviceSpecificHours = service.getSpecificHours();
					if(serviceSpecificHours.isEmpty()){
						subServiceSpecificHours.add("N/A");
					}else {
						subServiceSpecificHours.add(serviceSpecificHours.trim());
					}
					String serviceAdditionalReq = service.getAdditionalRequirements();
					if(serviceAdditionalReq.isEmpty()){
						subServiceArrayAdditionalReq.add("N/A");
					}else{
						subServiceArrayAdditionalReq.add(serviceAdditionalReq.trim());
					}

					String subCategory = "";

					for (Taxonomy taxonomy : service.getTaxonomyList()) {
						String category = taxonomy.getCategory();
						subTaxCategoryArrayList.add(category);
						subCategory = subCategory + category +"\n";
					}

					List<String> subTaxCategoryArrayListCopy = new ArrayList<>(subTaxCategoryArrayList);
					subTaxCategoryArrayListCopy.removeAll(taxCategoryArrayList);
					taxCategoryArrayList.addAll(subTaxCategoryArrayListCopy);
					Category = Category + subCategory ;
				}

				//append string list to "serviceList"
				serviceArrayNames.add(subServiceArrayNames);
				serviceArrayUIDs.add(subServiceArrayUIDs);
				ServiceArrayDescription.add(subServiceArrayDescription);
				ServiceArrayEligibility.add(subServiceArrayEligibility);
				ServiceArraySpecificHours.add(subServiceSpecificHours);
				ServiceArrayAdditionalReq.add(subServiceArrayAdditionalReq);
			}

			organizationDescription.setProgramList(programArrayNames);
			organizationDescription.setProgramUIDList(programArrayUIDs);
			organizationDescription.setServiceList(serviceArrayNames);
			organizationDescription.setServiceUIDList(serviceArrayUIDs);
			organizationDescription.setServiceArrayDescription(ServiceArrayDescription);
			organizationDescription.setServiceArrayEligibility(ServiceArrayEligibility);
			organizationDescription.setServiceArraySpecificHours(ServiceArraySpecificHours);
			organizationDescription.setServiceArrayAdditionalReq(ServiceArrayAdditionalReq);
			organizationDescription.setCategory(Category);
			organizationDescription.setTaxCategoryList(taxCategoryArrayList);
			if(!organizationDescriptionArray.stream().filter(locationDescription1 -> locationDescription1.getOrganizationName().equalsIgnoreCase(organizationDescription.getOrganizationName())).findFirst().isPresent())
			{
				organizationDescriptionArray.add(organizationDescription);
			}

		}
		return organizationDescriptionArray;//sach_added
	}

	//sach : this uses file read/write. bookmark functionality. this was initially here
	public static boolean isBookmarkExist(String serviceName,File file)
	{
		if (!file.exists())
		{
			return false;
		}
		try {
			FileInputStream fileInputStream=new FileInputStream(file);
			ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
			ArrayList<OrganizationDescription> organizationDescriptionsList =(ArrayList<OrganizationDescription>)objectInputStream.readObject();
			objectInputStream.close();
			fileInputStream.close();
			if (organizationDescriptionsList !=null)
			{
				for(OrganizationDescription locDescObj: organizationDescriptionsList)
				{
					if (serviceName.equals(locDescObj.getOrganizationName()))
					{
						return true;
					}
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return false;
	}

	//sach : this uses file read/write. bookmark functionality. this was initially here
	public static boolean isBookmarkEventExist(UUID eventID, File file)
	{
		if (!file.exists())
		{
			return false;
		}
		try {
			FileInputStream fileInputStream=new FileInputStream(file);
			ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
			ArrayList<CalandarEvent> calandarEventArrayList=(ArrayList<CalandarEvent>)objectInputStream.readObject();
			objectInputStream.close();
			fileInputStream.close();
			if (calandarEventArrayList!=null)
			{
				for(CalandarEvent calandarEvent:calandarEventArrayList)
				{
					if (calandarEvent.getEventId().equals( eventID))
					{
						return true;
					}
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return false;
	}

}
