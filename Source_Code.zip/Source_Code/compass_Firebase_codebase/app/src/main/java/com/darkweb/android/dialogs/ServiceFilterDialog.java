package com.darkweb.android.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.ObjectsForMapper.RequestedServiceStatus;

import java.util.ArrayList;
import java.util.List;

public class ServiceFilterDialog extends AppCompatDialogFragment {

    private ServiceFilterDialogListener listener;
    private LinearLayout viewCheckBox;
    private Spinner sortByOption;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        // set layout of the filter dialog
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.services_filter_dialog, null);
        builder.setView(view)
                .setTitle("Filter")
                .setNegativeButton("Cancel", (dialogInterface, i) -> {

                })
                .setPositiveButton("Apply", (dialogInterface, i) -> {
                    // collecting check box results
                    List<RequestedServiceStatus> checkedOptions = getCheckBoxResult();
                    // get sort by result
                    String sortByWhat = sortByOption.getSelectedItem().toString();
                    listener.applyFilter(checkedOptions, sortByWhat);
                });

        // set the checkboxes
        viewCheckBox = view.findViewById(R.id.view_checkbox);
        String[] status = {"Pending", "Completed", "Canceled", "Created"};
        for (String s: status) {
            CheckBox checkBox = new CheckBox(getActivity());
            checkBox.setText(s);
            // all marked by default
            checkBox.setChecked(true);
            viewCheckBox.addView(checkBox);
        }

        // set the dropdown option
        sortByOption = view.findViewById(R.id.services_filter_dropdown_menu);

        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (ServiceFilterDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() +
                    " must implement ServiceFilterDialogListener");
        }
    }

    public interface ServiceFilterDialogListener {
        void applyFilter(List<RequestedServiceStatus> checkedOptions, String sortByWhat);
    }

    // Collecting checked markers
    private List<RequestedServiceStatus> getCheckBoxResult() {
        List<RequestedServiceStatus> checkedOptions = new ArrayList<>();
        for (int i = 0; i < viewCheckBox.getChildCount(); i++) {
            CheckBox checkBox = (CheckBox) viewCheckBox.getChildAt(i);
            checkedOptions.add(new RequestedServiceStatus(
                    checkBox.getText().toString(),
                    checkBox.isChecked()));
        }
        return checkedOptions;
    }
}
