package com.darkweb.android.dao;

public class MessageSendDao {
    private int clientId;
    private int organizationId;
    private boolean sentByClient;
    private String message;

    public MessageSendDao(int clientId, int organizationId, boolean sentByClient, String message) {
        this.clientId = clientId;
        this.organizationId = organizationId;
        this.sentByClient = sentByClient;
        this.message = message;
    }

    public MessageSendDao() {
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(int organizationId) {
        this.organizationId = organizationId;
    }

    public boolean isSentByClient() {
        return sentByClient;
    }

    public void setSentByClient(boolean sentByClient) {
        this.sentByClient = sentByClient;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
