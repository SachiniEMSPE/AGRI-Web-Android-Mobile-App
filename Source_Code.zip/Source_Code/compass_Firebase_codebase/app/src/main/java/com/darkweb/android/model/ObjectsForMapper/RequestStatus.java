package com.darkweb.android.model.ObjectsForMapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestStatus {
    private int id;
    private int request;
    private Status status;
    private List<OrganizationNote> notes;

    public RequestStatus() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRequest() {
        return request;
    }

    public void setRequest(int request) {
        this.request = request;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public List<OrganizationNote> getNotes() {
        return notes;
    }

    public void setNotes(List<OrganizationNote> notes) {
        this.notes = notes;
    }
}
