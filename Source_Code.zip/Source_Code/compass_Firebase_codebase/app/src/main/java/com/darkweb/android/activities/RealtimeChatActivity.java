package com.darkweb.android.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.darkweb.android.adapter.MessagesNewAdapter;
import com.darkweb.android.compass.R;
import com.darkweb.android.dao.MessageSendDao;
import com.darkweb.android.model.MessageMapper.ChatMessage;
import com.darkweb.android.model.MessageMapper.ClientMessage;
import com.darkweb.android.model.MessageMapper.MobileClient;
import com.darkweb.android.service.HttpHandlers.HttpMessageHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import ua.naiksoftware.stomp.Stomp;
import ua.naiksoftware.stomp.StompClient;


public class RealtimeChatActivity extends AppCompatActivity {

    private static final String TAG = "RealtimeChatActivity";
    private StompClient mStompClient;
    private CompositeDisposable compositeDisposable;
    private List<ClientMessage> messages;
    private RecyclerView mMessageRecycler;
    private EditText inputMessageView;
    private MessagesNewAdapter listAdapter;
    private String CHANNEL_URI = "";
    private String LOCAL_MOBILE_USER_NAME = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final String uri = "ws://compass-dev.arcc.albany.edu/CompassApplication-1.0.0/chat/ws/websocket";

        // collecting organization id, client id
        Intent intent = getIntent();
        String organizationId = intent.getStringExtra("organizationId");
        SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);
        String backendClientName = sp.getString("MobileClientName", "");
        if (!backendClientName.equals("")) {
            LOCAL_MOBILE_USER_NAME = backendClientName;
        }
        CHANNEL_URI = "/channel/" + organizationId + "/" + local_user_id;
        // Setup view component
        setContentView(R.layout.chat_activity_layout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        String organizationName = intent.getStringExtra("organizationName");
        Objects.requireNonNull(getSupportActionBar()).setTitle(organizationName);

        // Fetching history messages
        try {
            String msgJson = new HttpMessageHandler().execute(
                    "getmsg", String.valueOf(local_user_id), organizationId
            ).get();

            ObjectMapper mapper = new ObjectMapper();
            messages =
                    mapper.readValue(msgJson, new TypeReference<List<ClientMessage>>() {});

            listAdapter = new MessagesNewAdapter(this, messages);
            mMessageRecycler = findViewById(R.id.reyclerview_message_list);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
            mMessageRecycler.setLayoutManager(mLayoutManager);
            mMessageRecycler.setItemAnimator(new DefaultItemAnimator());
            mMessageRecycler.setAdapter(listAdapter);

            // set view window to the last message
            scrollToBottom();
        } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
            e.printStackTrace();
        }

        // Send button action
        inputMessageView = findViewById(R.id.edittext_chatbox);
        Button sendMessageButton = findViewById(R.id.button_chatbox_send);
        sendMessageButton.setOnClickListener(view -> {
            String text_in_box = inputMessageView.getText().toString();
            if (text_in_box.length() > 0) {
                sendSocketMessage(text_in_box);
                sendHttpMessage(local_user_id, organizationId, text_in_box);
            }
        });

        // Establishing realtime connection with backend
        mStompClient = Stomp.over(Stomp.ConnectionProvider.OKHTTP, uri);
        resetSubscriptions();
        connectStomp();
        notifyOrganization(ChatMessage.MessageType.JOIN);

    }


    private void resetSubscriptions() {
        if (compositeDisposable != null) compositeDisposable.dispose();
        compositeDisposable = new CompositeDisposable();
    }

    public void connectStomp() {
        Disposable dispLifecycle = mStompClient.lifecycle()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(lifecycleEvent -> {
                    switch (lifecycleEvent.getType()) {
                        case OPENED:
                            System.out.println("Stomp connection opened");
                        break;
                        case ERROR:
                            Log.e(TAG, "Stomp connection error", lifecycleEvent.getException());
                        break;
                        case CLOSED:
                            resetSubscriptions();
                            break;
                        case FAILED_SERVER_HEARTBEAT:
                            System.out.println("Stomp failed server heartbeat");
                            break;
                    }
                });
        compositeDisposable.add(dispLifecycle);

        // Receive greetings
        Disposable dispTopic = mStompClient.topic(CHANNEL_URI)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(topicMessage -> {
                    // convert received message to object
                    ObjectMapper mapper = new ObjectMapper();
                    ChatMessage receivedMessage =
                            mapper.readValue(topicMessage.getPayload(), ChatMessage.class);
                    // avoid repeat messages adding
                    if (receivedMessage.getType() == ChatMessage.MessageType.CHAT
                        && !receivedMessage.getSender().equalsIgnoreCase("Bud Light")) {
                        addMessageToList(receivedMessage,false);
                    }
                }, throwable -> {
                    Log.e(TAG, "Error on subscribe topic", throwable);
                });
        compositeDisposable.add(dispTopic);
        mStompClient.connect();
    }

    @Override
    protected void onDestroy() {
        notifyOrganization(ChatMessage.MessageType.LEAVE);
        mStompClient.disconnect();
        if (compositeDisposable != null) compositeDisposable.dispose();
        super.onDestroy();
    }

    /**
     * Sending message to backend through HTTP
     * @param clientId client id
     * @param organizationId organization id
     * @param text_in_box the message within the input box
     */
    private void sendHttpMessage(int clientId, String organizationId, String text_in_box) {
        MessageSendDao msgToSend = new MessageSendDao(
                clientId,
                Integer.parseInt(organizationId),
                true,
                text_in_box
        );
        ObjectMapper mapper = new ObjectMapper();
        try {
            String result =
                    new HttpMessageHandler().execute(mapper.writeValueAsString(msgToSend)).get();
            // clean up the input box
            inputMessageView.setText("");
        } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sending message to organization chat page
     * @param messageContent message within the input box
     */
    private void sendSocketMessage(String messageContent) {
        ChatMessage message = new ChatMessage();
        message.setSender(LOCAL_MOBILE_USER_NAME);
        message.setType(ChatMessage.MessageType.CHAT);
        message.setContent(messageContent);
        ObjectMapper mapper = new ObjectMapper();
        try {
            mStompClient.send(CHANNEL_URI, mapper.writeValueAsString(message)).subscribe();
            addMessageToList(message, true);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    private void scrollToBottom() {
        mMessageRecycler.scrollToPosition(listAdapter.getItemCount() - 1);
    }

    private void addMessageToList(ChatMessage message, boolean client) {
        messages.add(createLocalMessageRecord(message, client));
        listAdapter.notifyDataSetChanged();
        mMessageRecycler.smoothScrollToPosition(listAdapter.getItemCount() - 1);
    }

    private ClientMessage createLocalMessageRecord(ChatMessage message, boolean isClient) {
        ClientMessage clientMessage = new ClientMessage();
        // if this message is sent by client
        MobileClient tempClient = new MobileClient();
        if (isClient) {
            clientMessage.setClientFrom(tempClient);
        }
        clientMessage.setContent(message.getContent());
        return clientMessage;
    }

    /**
     * Sending messages to notify organization that this client is joined or left
     */
    private void notifyOrganization(ChatMessage.MessageType type) {
        ChatMessage message = new ChatMessage();
        message.setSender(LOCAL_MOBILE_USER_NAME);
        message.setType(type);
        ObjectMapper mapper = new ObjectMapper();
        try {
            mStompClient.send(CHANNEL_URI, mapper.writeValueAsString(message)).subscribe();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
