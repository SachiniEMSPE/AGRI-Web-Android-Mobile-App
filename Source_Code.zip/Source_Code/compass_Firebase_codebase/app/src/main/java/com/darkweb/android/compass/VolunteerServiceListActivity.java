package com.darkweb.android.compass;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;

import com.darkweb.android.adapter.CustomServiceListAdapterCalandarEvent;
import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.model.OrganizationDescription;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Locale;

public class VolunteerServiceListActivity extends AppCompatActivity {

    String url;
    EditText search_service;
    ImageButton filter  , search;
    Dialog dialog;
    Spinner sort;
    File eventListFile;
    OrganizationDescription organizationDescriptionObj;
    ArrayList<CalandarEvent> calenderLocationDescriptionList;
    ArrayList<OrganizationDescription> organizationDescriptionArrayList;
    private ListView eventListView;
    private CustomServiceListAdapterCalandarEvent serviceListAdapter;
    LinearLayout defaultLinearLayout,volunteerinfoLinearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.volunteerservicelistactivity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Volunteer Service Activities");
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Volunteer Service Activities");

        defaultLinearLayout = findViewById(R.id.default_Lists_LinearLayout);
        volunteerinfoLinearLayout = findViewById(R.id.volunteer_info_LinearLayout);

        url = VolunteerServiceListActivity.this.getFilesDir().toString();
        organizationDescriptionObj =(OrganizationDescription) getIntent().getSerializableExtra("serviceObject");

        if (organizationDescriptionObj !=null)
            toolbar.setTitle(organizationDescriptionObj.getOrganizationName()+"");

        search_service = findViewById(R.id.inpt_search_services);
        filter = findViewById(R.id.filterservices);
        //search  = findViewById(R.id.get_search_services);

        if (organizationDescriptionObj.getOrganizationName().equals("CHURCH OF THE BLESSED SACRAMENT")){

            //defaultLinearLayout.setEnabled(false);
            defaultLinearLayout.setVisibility(View.GONE);
            volunteerinfoLinearLayout.setVisibility(View.VISIBLE);
            Log.d("sach_church",organizationDescriptionObj.getOrganizationName());

        } else {
            //volunteerinfoLinearLayout.setEnabled(false);
            volunteerinfoLinearLayout.setVisibility(View.GONE);
            defaultLinearLayout.setVisibility(View.VISIBLE);

        }

    }
    @Override
    public void onBackPressed() {
       // Intent intent=new Intent(VolunteerServiceListActivity.this,ViewServices.class);
        //startActivity(intent);
        //finish();
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        eventListFile=new File(url,getString(R.string.locationDescriptionEventList));
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream ;
        if (eventListFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(eventListFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                organizationDescriptionArrayList = (ArrayList<OrganizationDescription>) objectInputStream.readObject();
                for (OrganizationDescription locObj: organizationDescriptionArrayList)
                {
                    if (locObj.getOrganizationName().equals(organizationDescriptionObj.getOrganizationName()))
                    {
                        organizationDescriptionObj =locObj;
                    }
                }
                objectInputStream.close();
                fileInputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        updateEventList();
    }

    private void updateEventList() {
        if(eventListView==null)
        {
            eventListView=(ListView)findViewById(R.id.my_service_list_view);
        }
        if (serviceListAdapter==null)
        {
            serviceListAdapter=new CustomServiceListAdapterCalandarEvent(VolunteerServiceListActivity.this, organizationDescriptionObj.getOrganisationEventList());
            eventListView.setAdapter(serviceListAdapter);
        }
        else
        {
            serviceListAdapter.notifyDataSetChanged();
        }

        if (search_service!=null)
        {
            search_service.addTextChangedListener(new TextWatcher() {

                @Override
                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                    // When user changed the Text

                    String text = search_service.getText().toString().toLowerCase(Locale.getDefault());
                    //FragmentMyService.this.serviceListAdapter.getFilter().filter(cs);
                    if (serviceListAdapter!=null)
                        serviceListAdapter.filter(text);
                }

                @Override
                public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                              int arg3) {

                }

                @Override
                public void afterTextChanged(Editable arg0) {
                }
            });
        }


        eventListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CalandarEvent calEventObj= organizationDescriptionObj.getOrganisationEventList().get(position);
                String item = organizationDescriptionObj.getOrganisationEventList().get(position).getEventDescription();
                Log.e("item",item.toString());
                Intent i = new Intent(VolunteerServiceListActivity.this,ViewCalandarEvent.class);
                i.putExtra(getString(R.string.calandarEventObject), calEventObj);
                // i.putExtra("bookmark","true");
                startActivity(i);
            }
        });


    }

}
