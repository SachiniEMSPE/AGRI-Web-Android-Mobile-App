package com.darkweb.android.compass;


import android.Manifest;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.*;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.darkweb.android.login.LoginActivity;
import com.darkweb.android.model.Age;
import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.adapter.CustomDateTimePicker;
import com.darkweb.android.model.ObjectsForMapper.Bookmark;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.model.User;
import com.darkweb.android.parser.JsontoObject;
import com.darkweb.android.service.HttpHandlers.HttpBookmarkHandler;
import com.darkweb.android.service.HttpHandlers.HttpCheckBookmarkHandler;
import com.darkweb.android.service.LocationDescriptionServices;
import com.darkweb.android.service.OrganizationService;
import com.darkweb.android.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.like.IconType;
import com.like.LikeButton;
import com.like.OnLikeListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import at.blogc.android.views.ExpandableTextView;
import io.github.kobakei.materialfabspeeddial.FabSpeedDial;
import io.github.kobakei.materialfabspeeddial.FabSpeedDialMenu;

import com.darkweb.android.adapter.sachExpandableListAdapter;

import static com.darkweb.android.compass.R.drawable.username;

//*sach this contains file read/write functions
//like related to  bookmarks
public class ViewServices extends AppCompatActivity {

    TextView service_name, operating_time, button_toggle, service_address, service_website, service_category, service_phone,languages; //sach_added langeuages
    FabSpeedDialMenu menu;
    ExpandableTextView service_description;
    User user=null;
    FabSpeedDial fab;
    LikeButton like;
    Spinner serviceDescriptionList, programDescriptionList;
    OrganizationDescription organizationDescriptionObj;
    Dialog dialog;
    String fileurl;
    File bookmarkFile;
    EditText service;
    DatePickerDialog.OnDateSetListener addEventDateListener, addserviceDateListener, notificationEventDateListener;
    static EditText serviceDescription, addServiceNameTextView;
    static Button submit;
    TextView expectingtime, expectingDate;
    String url;
    ArrayList<ServiceDetails> sdList;
    ArrayList<OrganizationDescription> calenderOrganizationDescriptionList;
    ArrayList<OrganizationDescription> organizationDescriptionsList;
    final Calendar myCalendar = Calendar.getInstance();
     Calendar myCalendar1 ;

     TableLayout tableLayout;
//    ArrayList<String> list1 = b.list1;

    private Toolbar mTopToolbar;
    int i=0;
    static ArrayList<String> array = new ArrayList<String>();

    int hours, minutes;
    private TextView event_name_textview, event_description, dialog_time, dilogue_date;
    private EditText fromAge;
    private EditText toAge;
    View background_dimmer;
    private EditText eventDateEditText,eventTimeEditText;
    private EditText addServiceDateEditText, addServiceTimeEditText;
    private EditText addEventDateEditText,addEventTimeEditText;
    private TextView addReminderTextView;
    private  Spinner programSpinner ; //sach_added
    private Spinner serviceSpinner;
    private ExpandableListView listView;//sach_added
    private TextView textView;
    UserService userService;

    private sachExpandableListAdapter listAdapter ;//sach_added - for program list view
    List<String> listDataHeader = null;//sach_added
    HashMap<String, List<String>> listHash = null;//sach_added

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);

        fileurl = ViewServices.this.getFilesDir().toString();
        userService = new UserService();
        bookmarkFile = new File(fileurl, getString(R.string.bookmarkFile));
        service_category = (TextView) findViewById(R.id.category_name_textview);
        service_name = (TextView) findViewById(R.id.service_name);
        operating_time = (TextView) findViewById(R.id.operating_time);
        languages = (TextView) findViewById(R.id.languages);//sach_added
        service_description =  findViewById(R.id.service_description);
        service_address = (TextView) findViewById(R.id.service_address);
        service_website = (TextView) findViewById(R.id.service_website);
        service_phone = (TextView) findViewById(R.id.service_phone);
        like = (LikeButton) findViewById(R.id.bookmark);
        user = userService.getUserSignedIn(ViewServices.this);
        serviceSpinner = (Spinner) findViewById(R.id.service_spinnerview);//sach_added
        //sach_contains organization description object, this retrieve the received object named as "serviceObject" in any place where the organization is clicked.All the information related to object is having here.
        organizationDescriptionObj = (OrganizationDescription) getIntent().getSerializableExtra("serviceObject");
        i++;
        //Log.d("sach_Content of org",i+""+organizationDescriptionObj);
        String isBookmark = (String) getIntent().getStringExtra("bookmark");


        String check=organizationDescriptionObj.getDescription();
        //Log.d("sach_organizationgetDescription",check);
       TextView button_toggle2 = findViewById(R.id.button_toggle);  //Button for read more attribute
        if(check== null || check==" " || check==""){
            button_toggle2.setText("");
        }else{

            if(check.length()<60){
                button_toggle2.setText("");
            }else{
                button_toggle2.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(final View v)
                    {
                        if (service_description.isExpanded())
                        {
                            service_description.collapse();
                            button_toggle2.setText("Read More...");
                        }
                        else
                        {
                            service_description.expand();
                            button_toggle2.setText("Read Less...");
                        }
                    }
                });
            }

        }

        if(organizationDescriptionObj.getContact().isEmpty())
            service_phone.setText("N/A");
        else
            service_phone.setText(organizationDescriptionObj.getContact());

        if(organizationDescriptionObj.getCategory().isEmpty())
            service_category.setText("N/A");
        else
            service_category.setText(organizationDescriptionObj.getCategory());

        if(organizationDescriptionObj.getOrganizationName().isEmpty())
            service_name.setText("N/A");
        else
            service_name.setText(organizationDescriptionObj.getOrganizationName());

        if (organizationDescriptionObj.getHours().trim().length() > 0)
            operating_time.setText(organizationDescriptionObj.getHours());
        else
            operating_time.setText("N/A");

        if(organizationDescriptionObj.getLanguages()==null) //sach_added changed from is empty to null
            languages.setText("N/A");
        else
            languages.setText(organizationDescriptionObj.getLanguages());//sach_added

        if(organizationDescriptionObj.getDescription().isEmpty())
            service_description.setText("N/A");
        else
            service_description.setText(organizationDescriptionObj.getDescription());

        if(organizationDescriptionObj.getWebsite().isEmpty())
            service_website.setText("N/A");
        else {
            String temp=organizationDescriptionObj.getWebsite();
            String line1;
            line1 = temp.substring(0,temp.length()-0);
            service_website.setText(line1);
        }
        if(organizationDescriptionObj.getStreetAddress().isEmpty())
            service_address.setText("N/A");
        else
            service_address.setText(organizationDescriptionObj.getStreetAddress() + ",\n" + organizationDescriptionObj.getCity() + ", " + organizationDescriptionObj.getState() + " " + organizationDescriptionObj.getZipcode());

        url = ViewServices.this.getFilesDir().toString();
        service_address.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(service_address.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        service_website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(service_website.getText().toString()));
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(organizationDescriptionObj.getWebsite()));
                startActivity(browserIntent);
            }
        });

        service_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:" + organizationDescriptionObj.getContact().replaceAll("[^0-9]", "")));
                try {
                    if (Build.VERSION.SDK_INT > 22) {
                        if (ActivityCompat.checkSelfPermission(ViewServices.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(ViewServices.this, new String[]{Manifest.permission.CALL_PHONE}, 101);

                            return;
                        }

                        startActivity(phoneIntent);

                    } else {
                        startActivity(phoneIntent);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });

        if(user==null)
        {
            like.setLiked(false);
        }
        else
        {

            if (isBookmark != null) {
                if (isBookmark.equals("true")) {
            Log.d("like:","1");
                    like.setLiked(true);
                } else {
                    like.setLiked(false);
                }

            } else {
                if (JsontoObject.isBookmarkExist(organizationDescriptionObj.getOrganizationName(), bookmarkFile)) {
                    Log.d("like:","2");
                    like.setLiked(true);
                } else {
                    like.setLiked(false);
                }
            }
        }

        mTopToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(mTopToolbar);

//sach_like button clicked
        like.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
                int local_user_id = sp.getInt("MobileClientID", 0);
                if (local_user_id == 0)
                {
                    Intent intent = new Intent(ViewServices.this, LoginActivity.class);
                    startActivityForResult(intent, 2);
                    likeButton.setLiked(false);
                }
                else {
                    likeButton.setIcon(IconType.Star);
                    likeButton.setAnimationScaleFactor(8);
                    //        AddLocationDescriptiontoFile("bookmark",organizationDescriptionObj);
                    //Log.d("colors:", organizationDescriptionObj.getMarkerColor() + "");

                    addBookmarkFile();
                    addOrganizationToBookMark();
                    Log.d("like:","4");
                    likeButton.setLiked(true);


                }
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                likeButton.setAnimationScaleFactor(4);
                likeButton.setLiked(false);

                removeBookmarkFile();
                addOrganizationToBookMark();
            }
        });

        background_dimmer=(View)findViewById(R.id.background_dimmer);
        fab = (FabSpeedDial) findViewById(R.id.addservicefab);
        menu = new FabSpeedDialMenu(this);

        menu.add("Request").setIcon(R.drawable.outline_create_white_18dp);
        menu.add("Volunteer").setIcon(R.drawable.outline_last_page_white_18dp);
        menu.add("Ask").setIcon(R.drawable.outline_contact_support_white_18dp);

        fab.setMenu(menu);
        background_dimmer.setVisibility(View.GONE);

        //sach_fab menue item click activity
       fab.addOnMenuItemClickListener(new FabSpeedDial.OnMenuItemClickListener() {

            public void onMenuItemClick(FloatingActionButton miniFab, @Nullable TextView label, int itemId) {

                SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
                int local_user_id = sp.getInt("MobileClientID", 0);

                if(local_user_id == 0 && itemId !=6)
                { AlertDialog.Builder alertDialog=new AlertDialog.Builder(ViewServices.this);
                    // Setting Dialog Title
                    alertDialog.setTitle("Sign In");
                    // Setting Dialog Message
                    alertDialog.setMessage("You need to sign In to add service. Would you like to sign in? ");
                    alertDialog.setCancelable(true);
                    // Setting alert dialog icon
                    alertDialog.setIcon(username);
                    alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(fab!=null)
                                fab.closeMenu();

                        }
                    });
                    // Setting OK Button
                    alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(ViewServices.this, LoginActivity.class);
                            intent.putExtra(getString(R.string.itemId),itemId);
                            startActivityForResult(intent, 1);

                        }
                    });
                    alertDialog.show();

                }
                //sach_already signed in on the next interface of fab item clickeds
                else
                {

                    Log.d("sach_fabItemClicked",""+itemId);
                    showFabItemID(itemId);
                }
            }
       });

        //sach_added - to update program expandable list view
        if(organizationDescriptionObj != null ){
            /*
            ExpandableListAdapter listAdapter ;
            List<String> listDataHeader = null;
            HashMap<String, List<String>> listHash = null;
            */
            listView = (ExpandableListView) findViewById(R.id.expandableListView);
            initData();
            listAdapter = new sachExpandableListAdapter(this,listDataHeader,listHash);
            listView.setAdapter(listAdapter);

            //sach_added when program list item clicked move to service info view.
            listView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                @Override
                public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                    String programName = String.valueOf(listAdapter.getChild(groupPosition,childPosition));
                    LocationDescriptionServices.sachAddServiceObj(ViewServices.this,organizationDescriptionObj,null,programName);
                    //Log.d("childPosition_name ", String.valueOf(childPosition) + programName);
                 return false;
                }
            });

        }
        //sach_added to change read more / read less in programs
        listView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                TextView textView = (TextView) findViewById(R.id.button_toggleProgram);
                if(listView.isGroupExpanded(0)){
                    textView.setText("Read More...");
                }else{
                    textView.setText("Read Less...");
                }

                return false;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        System.out.println("-x-x-x-x-x-x | ViewServices.java -> Checking bookmark status ");
        SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);
        if (local_user_id != 0) {
            String organizationId = organizationDescriptionObj.getOrganizationID();
            String backendIsMarked = "";
            try {
                backendIsMarked = new HttpCheckBookmarkHandler().execute(
                        Integer.toString(local_user_id), organizationId
                ).get();
            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
            }
            boolean isMarked = Boolean.parseBoolean(backendIsMarked);
            if (isMarked) {
                like = findViewById(R.id.bookmark);
                like.setLiked(true);
            }

        }


    }

    private void addOrganizationToBookMark() {
        System.out.println("------ | HTTP CALL: Add organization to bookmark");

        SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);

        int currentOrganizationId = Integer.parseInt(organizationDescriptionObj.getOrganizationID());
        Bookmark bookmark = new Bookmark(local_user_id, currentOrganizationId);
        ObjectMapper mapper = new ObjectMapper();

        try {
            String backendResponse = new HttpBookmarkHandler().execute(mapper.writeValueAsString(bookmark), "addnew").get();
            System.out.println("------ | Backend response: " + backendResponse);
        } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    //sach_added to read programs
    private void initData() {

        listDataHeader = new ArrayList<>();
        listHash = new HashMap<>();
        listDataHeader.add("Programs");
        List<String> programs = new ArrayList<>();
        programs = organizationDescriptionObj.getProgramList();
        listHash.put(listDataHeader.get(0),programs);
    }


    //*sach file read/write
    //to remove unlike bookmarks
    private void removeBookmarkFile() {
//        try {
//            if (bookmarkFile.exists()) {
//                FileInputStream fileInputStream = new FileInputStream(bookmarkFile);
//                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
//                organizationDescriptionsList = (ArrayList<OrganizationDescription>) objectInputStream.readObject();
//                objectInputStream.close();
//                fileInputStream.close();
//                if (organizationDescriptionsList != null) {
//                    Log.d("List before removed", ""+organizationDescriptionsList);
//                    int position=0;
//                    for(int i=0;i<organizationDescriptionsList.size();i++){
//                        if(organizationDescriptionsList.get(i).getOrganizationName().equals(organizationDescriptionObj.getOrganizationName())){
//                            position=i;
//                        }
//                    }
//                    organizationDescriptionsList.remove(position);
//                    Log.d("List after removed", ""+organizationDescriptionsList);
//                }
//            }
//
//
//            FileOutputStream fileOutputStream;
//            ObjectOutputStream objectOutputStream;
//            fileOutputStream = ViewServices.this.getBaseContext().openFileOutput(bookmarkFile.getName(), Context.MODE_PRIVATE);
//            Log.d("filename:", bookmarkFile.getName());
//            objectOutputStream = new ObjectOutputStream(fileOutputStream);
//            objectOutputStream.writeObject(organizationDescriptionsList);
//            objectOutputStream.close();
//
//            fileOutputStream.flush();
//            fileOutputStream.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        System.out.println("Remove Bookmark");
    }

    //* sach - file read/write detected
    //bookmark usage
    private void addBookmarkFile() {
        System.out.println("Add Bookmark");
//        try {
//            if (bookmarkFile.exists()) {
//                FileInputStream fileInputStream = new FileInputStream(bookmarkFile);
//                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
//                organizationDescriptionsList = (ArrayList<OrganizationDescription>) objectInputStream.readObject();
//                objectInputStream.close();
//                fileInputStream.close();
//                if (organizationDescriptionsList != null) {
//                    organizationDescriptionsList.add(organizationDescriptionObj);
//                } else {
//                    organizationDescriptionsList = new ArrayList<OrganizationDescription>();
//                    organizationDescriptionsList.add(organizationDescriptionObj);
//                }
//            } else {
//                organizationDescriptionsList = new ArrayList<OrganizationDescription>();
//                organizationDescriptionsList.add(organizationDescriptionObj);
//            }
//
//
//            FileOutputStream fileOutputStream;
//            ObjectOutputStream objectOutputStream;
//            fileOutputStream = ViewServices.this.getBaseContext().openFileOutput(bookmarkFile.getName(), Context.MODE_PRIVATE);
//            Log.d("filename:", bookmarkFile.getName());
//            objectOutputStream = new ObjectOutputStream(fileOutputStream);
//            objectOutputStream.writeObject(organizationDescriptionsList);
//            objectOutputStream.close();
//
//            fileOutputStream.flush();
//            fileOutputStream.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        array.add(organizationDescriptionObj.getOrganizationName());
  }

    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        addServiceDateEditText.setText(sdf.format(myCalendar.getTime()));

    }

    private void updateLabelAddEvent() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        addEventDateEditText.setText(sdf.format(myCalendar.getTime()));

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if (requestCode == 1)
        {
            user = userService.getUserSignedIn(ViewServices.this);
            if (user != null)
            {
                if(data!=null) {
                    showFabItemID(data.getIntExtra(getString(R.string.itemId), 1));
                }
            }
            else
            {
                if(fab!=null)
                    fab.closeMenu();
            }
        }
        else  if(requestCode==2)
        {
            user = userService.getUserSignedIn(ViewServices.this);
            if (user != null)
            {
                Log.d("like:","3");

              like.setLiked(true);
              addBookmarkFile();
              addOrganizationToBookMark();
            }
            else
            {
                like.setLiked(false);
                if(fab!=null)
                    fab.closeMenu();
            }
        }
    }

    //sach fab item clicked 0 - 6 indecies
    private void showFabItemID(int itemId) {
        //sach_Request
        if (itemId == 1) {
            LocationDescriptionServices.addServiceDeatailsObj(ViewServices.this, organizationDescriptionObj,null,"Request Service");
        }
        else if (itemId == 0) {

            Toast.makeText(this, "Requesting new service", Toast.LENGTH_SHORT).show();

            CalandarEvent calandarEvent = new CalandarEvent();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss");
            String currentDateandTime = sdf.format(new Date());
            dialog = new Dialog(ViewServices.this);
            dialog.setContentView(R.layout.add_new_event);
            dialog.setTitle("Add New Event");
            int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
            dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
            addServiceNameTextView = dialog.findViewById(R.id.add_servicename_textview);
            serviceDescription = dialog.findViewById(R.id.dialog_service);
            fromAge=(EditText)dialog.findViewById(R.id.from_age);
            toAge=(EditText) dialog.findViewById(R.id.to_age);
            addEventDateEditText=(EditText) dialog.findViewById(R.id.input_date);
            addEventTimeEditText =(EditText) dialog.findViewById(R.id.input_time);

            Date date1=new Date();
            addEventTimeEditText.setText(date1.getHours()+" : "+date1.getMinutes());
            addEventTimeEditText.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Toast.makeText(ViewServices.this, "Time clicked", Toast.LENGTH_SHORT).show();
                    TimePickerDialog mTimePicker = CustomDateTimePicker.getCustomTimePickerDialogue(ViewServices.this,addEventTimeEditText,date1,new Date(),null);

                }
            });

            addEventDateListener=CustomDateTimePicker.getCustomDatePicker(addEventDateEditText,null,myCalendar);

            addEventDateEditText.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    DatePickerDialog datePicker=new DatePickerDialog(ViewServices.this, addEventDateListener,
                            myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                            myCalendar.get(Calendar.DAY_OF_MONTH));
                    datePicker.getDatePicker().setMinDate(new Date().getTime());
                    datePicker.setCancelable(false);

                    datePicker.show();
                }
            });

            updateLabelAddEvent();


            submit = dialog.findViewById(R.id.dialog_submit);
            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    calandarEvent.setCity(organizationDescriptionObj.getCity());
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy hh:mm", Locale.US);
                        calandarEvent.setEventDateTime(sdf.parse(addEventDateEditText.getText().toString().replaceAll("\\s+", "") + " " + addEventTimeEditText.getText().toString().replaceAll("\\s+", "")));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    Age ageObj=new Age();
                    try{
                        ageObj.setFromAge(Integer.parseInt(fromAge.getText().toString()));
                        ageObj.setToAge(Integer.parseInt(toAge.getText().toString()));

                    }catch(Exception e)
                    {

                    }
                    Map<String,Object> eventMap= new HashMap<String,Object>();
                    eventMap.put(getString(R.string.AgeCriteria),ageObj);
                    calandarEvent.setCriteriaMap(eventMap);
                    calandarEvent.setEventDescription(serviceDescription.getText().toString());
                    calandarEvent.setEventName(addServiceNameTextView.getText().toString());
                    calandarEvent.setEventId(UUID.randomUUID());
                    calandarEvent.setOrganizationDescription(organizationDescriptionObj);
                    calandarEvent.setState(organizationDescriptionObj.getState());
                    calandarEvent.setStreetAddress(organizationDescriptionObj.getStreetAddress());
                    calandarEvent.setZipcode(organizationDescriptionObj.getZipcode());
                    calandarEvent.setEventSubmitDate(new Date());
                    calandarEvent.setRequestCode((int) calandarEvent.getEventId().getLeastSignificantBits());

                    //*sach - file read/write detected
                    //organizationDescriptionObj.getOrganisationEventList().add(calandarEvent);
                    final File file = new File(url, getString(R.string.locationDescriptionEventList));
                    try {
                        if (file.exists()) {
                            FileInputStream fileInputStream = new FileInputStream(file);
                            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                            calenderOrganizationDescriptionList = (ArrayList<OrganizationDescription>) objectInputStream.readObject();
                            objectInputStream.close();
                            fileInputStream.close();
                            if (calenderOrganizationDescriptionList != null) {
                                int flag = 0;
                                for (OrganizationDescription obj : calenderOrganizationDescriptionList) {
                                    if (obj.getOrganizationName().equals(organizationDescriptionObj.getOrganizationName())) {
                                        obj.getOrganisationEventList().add(calandarEvent);
                                        Log.d("size:", obj.getOrganisationEventList().size() + "");
                                        flag = 1;
                                    }
                                }
                                if (flag == 0) {
                                    organizationDescriptionObj.getOrganisationEventList().add(calandarEvent);
                                    calenderOrganizationDescriptionList.add(0, organizationDescriptionObj);
                                }

                            } else {
                                calenderOrganizationDescriptionList = new ArrayList<OrganizationDescription>();
                                organizationDescriptionObj.getOrganisationEventList().add(calandarEvent);
                                calenderOrganizationDescriptionList.add(0, organizationDescriptionObj);
                            }
                        } else {
                            calenderOrganizationDescriptionList = new ArrayList<OrganizationDescription>();
                            organizationDescriptionObj.getOrganisationEventList().add(calandarEvent);
                            calenderOrganizationDescriptionList.add(0, organizationDescriptionObj);
                        }
                        //*sach file read/write detected
                        FileOutputStream fileOutputStream;
                        ObjectOutputStream objectOutputStream;
                        fileOutputStream = ViewServices.this.getBaseContext().openFileOutput(file.getName(), Context.MODE_PRIVATE);
                        Log.d("filename:", file.getName());
                        objectOutputStream = new ObjectOutputStream(fileOutputStream);
                        objectOutputStream.writeObject(calenderOrganizationDescriptionList);
                        objectOutputStream.close();
                        fileOutputStream.flush();
                        fileOutputStream.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    dialog.dismiss();
                }
            });
            dialog.show();
        }
        else if (itemId == 2) {
            Intent intent = new Intent(ViewServices.this, VolunteerServiceListActivity.class);
            if (organizationDescriptionObj == null) {
                organizationDescriptionObj = (OrganizationDescription) getIntent().getSerializableExtra("serviceObject");

            }
            intent.putExtra("serviceObject", organizationDescriptionObj);
            startActivity(intent);
        }
        else if(itemId ==3)
        {
            // Activity below are activated when Ask Button clicked
            if (organizationDescriptionObj != null) {
//                organizationDescriptionObj = (OrganizationDescription) getIntent().getSerializableExtra("serviceObject");
                Intent intent = new Intent(ViewServices.this, ChatActivity.class);
                intent.putExtra("organizationId", organizationDescriptionObj.getOrganizationID());
                intent.putExtra("organizationName", organizationDescriptionObj.getOrganizationName());
                startActivity(intent);
            }
        }
        else  if(itemId == 5)
        {
            Intent intent = new Intent(ViewServices.this, OrganisationChatActivity.class);
            if (organizationDescriptionObj == null) {
                organizationDescriptionObj = (OrganizationDescription) getIntent().getSerializableExtra("serviceObject");

            }
            intent.putExtra("serviceObject", organizationDescriptionObj);
            startActivity(intent);
        }
        else if(itemId == 6)
        { }
    }


}
