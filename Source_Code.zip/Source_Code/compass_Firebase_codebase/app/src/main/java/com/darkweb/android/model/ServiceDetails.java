package com.darkweb.android.model;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.darkweb.android.compass.R;
import com.darkweb.android.parser.JsontoObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.UUID;

/**
 * Created by kotak on 13/06/2018.
 */

public class ServiceDetails implements Serializable {

    String title;//sach changed serviceRequestName>title / getServiceRequestName > getTitle() / setServiceRequestName > setTitle()
    String comments;//sach changed serviceDescription>comments / getserviceDescription()>getComments() / setserviceDescription()>setComments()
    String submissionDate; //sach changed requestingServiceDate > submissionDate / getRequestingServiceDate() > getSubmissionDate() / setRequestingServiceDate() > setSubmissionDate()
    String eligibility; //sach added
    ArrayList<String> statusArray;
    String[]  requestDate = {"null","null"}; //sach added
    String[]  reminders = {"null","null"}; //sach added
    UUID requestUID;//sach changed serviceID > requestUID / getServiceID() > getRequestUID() / setServiceID() > setRequestUID()

    private String additionalRequirement;

    OrganizationDescription organizationDescription;
    String programName; //Sach changed serviceCategory > Programname
    String serviceName; //serviceProgram > servicename
    String programID;//sach added
    String serviceID;//sach added



    public ServiceDetails() {
    }

    @Override
    public String toString() {
        //sach changed serviceRequestName>title / getServiceRequestName > getTitle() / setServiceRequestName > setTitle()
        return "ServiceDetails{" +
                " title='" + title + '\'' +
                ", submissionDate='" + submissionDate + '\'' +
                ", comments='" + comments + '\'' +
                ", statusArray=" + statusArray +
                ", requestDate=" + requestDate +'\'' +
                ", reminders=" + reminders +'\'' +
                ", eligibility='" + eligibility + '\'' +
                ", requestUID=" + requestUID +
                ", programName='" + programName + '\'' +
                ", serviceName='" + serviceName + '\'' +
                ", programID='" + programID + '\'' +
                ", serviceID='" + serviceID + '\'' +
                '}';
    }

    public String getRemindarDate() {
        return reminders[1];//sach changed
    }
    public void setRemindarDate(String remindarDate) {
        this.reminders[1] = remindarDate;
    }

    public String getRemindarTime() {
        return reminders[0];//sach changed
    }

    public void setRemindarTime(String remindarTime) {
        this.reminders[0] = remindarTime;
    }

    public String getServiceName() {
        return serviceName;
    }
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public ArrayList<String> getStatusArray() {
        return statusArray;
    }

    public void setStatusArray(ArrayList<String> statusArray) {
        this.statusArray = statusArray;
    }


    public String getTitle() {
        return title; //sach changed serviceRequestName>title / getServiceRequestName > getTitle() / setServiceRequestName > setTitle()
    }

    public void setTitle(String title) {
        this.title = title;//sach changed serviceRequestName>title / getServiceRequestName > getTitle() / setServiceRequestName > setTitle()
    }


    public UUID getRequestUID() {
        return requestUID; //sach changed
    }

    public void setRequestUID(UUID requestUID) {
        //this.serviceId = serviceId;//sach changed
        this.requestUID = requestUID;
    }


    public String getExpectingtime() {
        return requestDate[1];
    }//sach changed
    public void setExpectingtime(String expectingtime) {//sach changed
        //this.expectingtime = expectingtime;
        this.requestDate[1]=expectingtime;
    }


    public String getExpectingServiceDate() {
        return requestDate[0];
    }//sach changed
    public void setExpectingServiceDate(String expectingServiceDate) {//sach changed
        //this.expectingServiceDate = expectingServiceDate;
        this.requestDate[0]=expectingServiceDate;
    }


    public String getSubmissionDate() {
        return submissionDate;
    }

    public void setSubmissionDate(String submissionDate) {
        this.submissionDate = submissionDate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }


    public OrganizationDescription getOrganizationDescription() {
        return organizationDescription;
    }


    public void setOrganizationDescription(OrganizationDescription organizationDescription) {
        this.organizationDescription = organizationDescription ; //sach commented and updated as below with organizationUID | sach uncommented to make the version
        //this.organizationUID = organizationDescription.getOrganizationID() ;
    }


    public String getEligibility() {
        return eligibility; //sach added
    }
    public void setEligibility(String eligibility) {
        this.eligibility = eligibility;//sach added
    }

    public String getServiceID() {
        return serviceID;
    } //sach added
    public void setServiceID(String serviceID) {
        this.serviceID = serviceID;
    } //sach added

    public String getProgramID() {
        return programID;
    }//sach added
    public void setProgramID(String programID) {
        this.programID = programID;
    }//sach added

    public static ServiceDetails getServiceDetailsObject(UUID uuid, Context context) {
        String url = context.getFilesDir().toString();
        final File file = new File(url, context.getString(R.string.serviceDetails));
        ArrayList<ServiceDetails> serviceDetailsArrayList;
        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                serviceDetailsArrayList=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (serviceDetailsArrayList!=null)
                {
                    Log.d("sizearray:",serviceDetailsArrayList.size()+"");
                    int i=-1;
                    for (i=0;i<serviceDetailsArrayList.size();i++)
                    {
                        if (uuid.equals(serviceDetailsArrayList.get(i).getRequestUID()))//sach changed getServiceID>getRequestUID

                        {
                            Log.d("uuid:",(uuid.equals(serviceDetailsArrayList.get(i).getRequestUID()))+"");//sach changed getServiceID>getRequestUID

                            Log.d("uuid:",(uuid.equals(serviceDetailsArrayList.get(i).getRequestUID()))+"");//sach changed getServiceID>getRequestUID

                            return serviceDetailsArrayList.get(i);
                        }
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}
