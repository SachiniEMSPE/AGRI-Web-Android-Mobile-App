package com.darkweb.android.compass.fragments;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.darkweb.android.adapter.CustomServiceListAdapter;
import com.darkweb.android.adapter.ServiceRequestsAdapter;
import com.darkweb.android.compass.R;

import com.darkweb.android.global.MyGlobalVars;
import com.darkweb.android.model.ObjectsForMapper.RequestedServiceStatus;
import com.darkweb.android.model.ObjectsForMapper.ServicesFilters;
import com.darkweb.android.model.RequestedService;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.service.HttpHandlers.RequestedServicesHandler;
import com.darkweb.android.service.HttpHandlers.RequestsFilterHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

//List view of all services requested by user

public class FragmentMyService extends Fragment {

    String sortby_dialogue;
    ListView pendingListView;
    ArrayList<ServiceDetails> serviceDetailsList;
    ArrayList<ServiceDetails> completedServices;
    ArrayList<ServiceDetails> cancelledServices;
    ArrayList<ServiceDetails> currentServices=new ArrayList<ServiceDetails>();
    String url;
    CheckBox pending_checkbox,cancelled_checkbox,completed_checkbox;
    Map<String,Boolean> statusMap=new HashMap<>();
    ArrayList<String> statusArrayList;
    Button apply_dialogue_button,cancel_dialogue_button;
    private OnFragmentInteractionListener mListener;
    private View view;
    CustomServiceListAdapter serviceListAdapter;
    EditText search_service;
    ImageButton filter  , search;
    Dialog mdialog;
    Spinner  sort;
    private LinearLayout viewCheckBox;
    private String[] checkBoxStringArray;
    private ArrayList<CheckBox> checkBoxArray;
    private ArrayList<Boolean> ischecked;
    private int selectedSort=-1;
    TextView resetAll;

    public FragmentMyService() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_services, container, false);

    }



    @Override
    public void onStart() {
        super.onStart();
        System.out.println("------ Service Fragment onStart() ------");
        TextView listMsg = view.findViewById(R.id.services_list_msg_view);
        String listMsgInfo = "";
        SharedPreferences sp = Objects.requireNonNull(this.getActivity()).getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);

        // Only fetching requested services when user logged in
        if (local_user_id != 0) {
            String result = "";
            try {
                // sending user id to backend end, and get the JSON data back
                result = new RequestedServicesHandler().execute(Integer.toString(local_user_id), "client").get();
                if (!result.equals("")) {
                    ObjectMapper mapper = new ObjectMapper();
                    List<RequestedService> requestedServices = mapper.readValue(result, new TypeReference<List<RequestedService>>() {});
                    if (requestedServices.size() > 0) {
                        pendingListView = view.findViewById(R.id.my_service_list_view);
                        // setup list rendering adapter
                        ServiceRequestsAdapter serviceRequestsAdapter = new ServiceRequestsAdapter(getActivity(), requestedServices);
                        // Render the list above to view
                        pendingListView.setAdapter(serviceRequestsAdapter);
                        // add click listener
                        pendingListView.setOnItemClickListener((adapterView, view, i, l) -> {
                            int requestedServiceId = requestedServices.get(i).getRequestedServiceId();
                            // Open another activity page, send the request id to that page
                            Intent intent = new Intent(
                                    FragmentMyService.this.getActivity(), ServiceRequested.class
                            );
                            intent.putExtra("requested_id", requestedServiceId);
                            startActivity(intent);
                        });
                    } else {
                        // The list is empty
                        listMsgInfo = "You haven't request any service yet";
                    }
                }
            } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
                e.printStackTrace();
            }
        } else {
            // Usually our user should not see this part, except some weird problem happened
            listMsgInfo = "User info fetched error";
        }
        listMsg.setText(listMsgInfo);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view = view;
        url = getActivity().getFilesDir().toString();
        sortby_dialogue =getString(R.string.alphanumeric_sortby_service_request );


        if (statusArrayList==null)
        {
            statusArrayList=new ArrayList<String>();
        }
        else
        {
            statusArrayList.clear();
        }
        statusArrayList.addAll(Arrays.asList(getResources().getStringArray(R.array.status_type)));

        for (String s:statusArrayList)
        {
            Log.d("qwerty:",s);
            statusMap.put(s,new Boolean(true));
        }

        search_service = view.findViewById(R.id.inpt_search_services);


        filter = view.findViewById(R.id.filterservices);
        filter.setOnClickListener(v -> {
            if (mdialog==null)
            {
                mdialog = new Dialog(getActivity());
                mdialog.setContentView(R.layout.filter_service_dialog);
            }
            mdialog.setTitle("Filter");
            String[] title = {"Pending", "Completed", "Canceled", "Created"};
            viewCheckBox = mdialog.findViewById(R.id.view_checkbox);
            resetAll = mdialog.findViewById(R.id.reset_all);
            checkBoxStringArray=getResources().getStringArray(R.array.status_type);
            if(checkBoxArray==null ) {
                if(checkBoxStringArray.length>0) {
                    checkBoxArray = new ArrayList<>();
                }
                for(int i=0;i<checkBoxStringArray.length;i++) {
                    CheckBox c=new CheckBox(getActivity());
                    c.setText(title[i]);
                    c.setChecked(true);
                    viewCheckBox.addView(c);
                    checkBoxArray.add(c);
                }
            }
            else
            {
                if(checkBoxArray.size()>0)
                {
                    if (ischecked==null)
                        ischecked= new ArrayList<>();
                    else
                        if (ischecked.size()>0)
                            ischecked.clear();
                    for (CheckBox c:checkBoxArray)
                        ischecked.add(c.isChecked());
                }
            }

            apply_dialogue_button = mdialog.findViewById(R.id.apply_my_servicefilter);
            cancel_dialogue_button = mdialog.findViewById(R.id.cancel_my_servicefilter);
            sort = mdialog.findViewById(R.id.sortby_myservice_spinner);
            mdialog.show();

            cancel_dialogue_button.setOnClickListener(v1 -> {
                mdialog.dismiss();
            });

            apply_dialogue_button.setOnClickListener(v12 -> {
                // Getting options from view
                List<RequestedServiceStatus> checkedOptions = getCheckBoxResult();
                String sortByWhat = sort.getSelectedItem().toString();
                // updating view
                try {
                    applyButtonClickedHandler(checkedOptions, sortByWhat);
                } catch (JsonProcessingException | ExecutionException | InterruptedException e) {
                    e.printStackTrace();
                }
                mdialog.hide();
            });
            resetAll.setOnClickListener(v13 -> {
                if (checkBoxArray!=null && checkBoxArray.size()>0)
                {
                    for (CheckBox c:checkBoxArray)
                        c.setChecked(true);
                }
                if (sort!=null)
                    sort.setSelection(0);

            });

        });
    }

    private void applyButtonClickedHandler(List<RequestedServiceStatus> checkedOptions,
                                           String sortByWhat) throws
                                            JsonProcessingException,
                                            ExecutionException,
                                            InterruptedException {

        SharedPreferences sp = Objects.requireNonNull(this.getActivity())
                .getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);

        ObjectMapper mapper = new ObjectMapper();
        ServicesFilters filter = new ServicesFilters(
                local_user_id,
                checkedOptions,
                sortByWhat);
        String filteredResult =
                new RequestsFilterHandler().execute(mapper.writeValueAsString(filter)).get();
        if (!filteredResult.equals("")) {
            List<RequestedService> filteredRequests = mapper.readValue(filteredResult, new TypeReference<List<RequestedService>>() {});
            pendingListView = view.findViewById(R.id.my_service_list_view);
            // setup list rendering adapter
            ServiceRequestsAdapter serviceRequestsAdapter = new ServiceRequestsAdapter(getActivity(), filteredRequests);
            // Render the list above to view
            pendingListView.setAdapter(serviceRequestsAdapter);
            // add click listener
            pendingListView.setOnItemClickListener((adapterView, view, i, l) -> {
                int requestedServiceId = filteredRequests.get(i).getRequestedServiceId();
                // Open another activity page, send the request id to that page
                Intent intent = new Intent(
                        FragmentMyService.this.getActivity(), ServiceRequested.class
                );
                intent.putExtra("requested_id", requestedServiceId);
                startActivity(intent);
            });
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    // Collecting checked markers
    private List<RequestedServiceStatus> getCheckBoxResult() {
        List<RequestedServiceStatus> checkedOptions = new ArrayList<>();
        for (int i = 0; i < viewCheckBox.getChildCount(); i++) {
            CheckBox checkBox = (CheckBox) viewCheckBox.getChildAt(i);
            checkedOptions.add(
                    new RequestedServiceStatus(
                            checkBox.getText().toString(),
                            checkBox.isChecked()));
        }
        return checkedOptions;
    }

    public void removeDuplicates(){
        for(int i=0;i<currentServices.size();i++){
            for(int j=currentServices.size()-1;j>0;j--){
                //if(currentServices.get(i).getServiceRequestName().equals(currentServices.get(j).getServiceRequestName())){ //sach changed
                if(currentServices.get(i).getTitle().equals(currentServices.get(j).getTitle())){

                    //if((currentServices.get(i).getRequestingServiceDate()).compareTo(currentServices.get(j).getRequestingServiceDate())>0){ //sach changed
                    if((currentServices.get(i).getSubmissionDate()).compareTo(currentServices.get(j).getSubmissionDate())>0){
                            currentServices.remove(j);
                    //}else if((currentServices.get(i).getRequestingServiceDate()).compareTo(currentServices.get(j).getRequestingServiceDate())<0){ //sach changed
                    }else if((currentServices.get(i).getSubmissionDate()).compareTo(currentServices.get(j).getSubmissionDate())<0){
                        currentServices.remove(i);
                    }



                }
            }
        }
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
