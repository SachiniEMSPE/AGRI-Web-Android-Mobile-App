package com.darkweb.android.adapter;

import android.content.Context;
import android.database.DataSetObserver;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.darkweb.android.model.CategoryList;
import com.darkweb.android.compass.R;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Created by kotak on 06/06/2018.
 */

public class MyExpandableListAdapter extends BaseExpandableListAdapter {

    private Context context;
    private ArrayList<CategoryList> categoryList;
    private ArrayList<CategoryList> copyCategoryList;
    private EditText searchCategory;
    private TextView heading;
    private LinearLayout linearLayout;
    private TextView deSelectAll;


    public MyExpandableListAdapter(Context context,ArrayList<CategoryList> categoryList)
    {
        this.context=context;
        this.categoryList=categoryList;
        copyCategoryList=new ArrayList<CategoryList>();
        copyCategoryList.addAll(this.categoryList);
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public ArrayList<CategoryList> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(ArrayList<CategoryList> categoryList) {
        this.categoryList = categoryList;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public int getGroupCount() {

        return categoryList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        ArrayList<String> checkBoxList=categoryList.get(groupPosition).getOptions();
        return checkBoxList.size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return categoryList.get(groupPosition);
    }

    @Override
    public Object[] getChild(int groupPosition, int childPosition) {
        ArrayList<String> checkBoxList=categoryList.get(groupPosition).getOptions();
        ArrayList<Boolean> boxCheckedList=categoryList.get(groupPosition).getBoxChecked();
        return new Object[]{checkBoxList.get(childPosition),boxCheckedList.get(childPosition)};
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {


        CategoryList categoryList1=(CategoryList)getGroup(groupPosition);

        if (convertView==null)
        {
            LayoutInflater inf1 = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inf1.inflate(R.layout.filtercategorylist, null);
        }

        heading=(TextView) convertView.findViewById(R.id.categoryText);
        searchCategory=(EditText) convertView.findViewById(R.id.search_category);
        searchCategory.setVisibility(View.GONE);
        deSelectAll=(TextView) convertView.findViewById(R.id.deselect_all);
        deSelectAll.setVisibility(View.GONE);

        linearLayout=(LinearLayout) convertView.findViewById(R.id.linear_layout_expandable_list);
        //searchCategory=(EditText) convertView.findViewById(R.id.search_category);
        //searchCategory.setVisibility(View.GONE);
        ExpandableListView mExpandableListView = (ExpandableListView) parent;

        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if (isExpanded)
                   mExpandableListView.collapseGroup(groupPosition);
               else
                   mExpandableListView.expandGroup(groupPosition);
            }
        });
        if(isExpanded)
        {
            searchCategory.setVisibility(View.VISIBLE);
            deSelectAll.setVisibility(View.VISIBLE);
        }
        else
        {
            searchCategory.setVisibility(View.GONE);
            deSelectAll.setVisibility(View.GONE);
        }
        if(heading!=null)
            heading.setText(categoryList1.getCategoryName());

        deSelectAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deselectAllOptions();
                mExpandableListView.collapseGroup(groupPosition);
                mExpandableListView.expandGroup(groupPosition);
            }
        });
        searchCategory.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = searchCategory.getText().toString().toLowerCase(Locale.getDefault());
                //FragmentMyService.this.serviceListAdapter.getFilter().filter(cs);
                filterData(text);
                    mExpandableListView.collapseGroup(groupPosition);
                    mExpandableListView.expandGroup(groupPosition);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        return convertView;
    }

    @Override
    public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        Object[] a=(Object[])getChild(groupPosition,childPosition);
        String checkbox=(String)a[0];
        if (convertView==null)
        {
            LayoutInflater infalInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.filtercheckboxlist, null);
        }
        CheckBox checkboxView=(CheckBox) convertView.findViewById(R.id.filterCheckBox);
        checkboxView.setText(checkbox);

        checkboxView.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getChild(groupPosition,childPosition);
                categoryList.get(groupPosition).getBoxChecked().set(childPosition,new Boolean(isChecked));
                changeCheckBoxCopyCategory(groupPosition,categoryList.get(groupPosition).getOptions().get(childPosition),isChecked);
                //categoryList.get(groupPosition).getBoxChecked().get(childPosition)= new Boolean(isChecked);
            }
        });

        checkboxView.setTag(childPosition);
        checkboxView.setChecked(categoryList.get(groupPosition).getBoxChecked().get(childPosition));
        return convertView;
    }

    private void changeCheckBoxCopyCategory(int groupPosition, String s, boolean isChecked) {
        for(int i=0;i<copyCategoryList.get(groupPosition).getOptions().size();i++)
        {
            if(s.equals(copyCategoryList.get(groupPosition).getOptions().get(i)))
            {
                copyCategoryList.get(groupPosition).getBoxChecked().set(i,isChecked);
            }
        }
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public void onGroupExpanded(int groupPosition) {

    }

    @Override
    public void onGroupCollapsed(int groupPosition) {

    }


    @Override
    public long getCombinedChildId(long groupId, long childId) {
        return 0;
    }

    @Override
    public long getCombinedGroupId(long groupId) {
        return 0;
    }

    private void deselectAllOptions() {
        for(CategoryList categoryListObject: copyCategoryList)
        {
            for(int i=0;i<categoryListObject.getBoxChecked().size();i++)
            {
                categoryListObject.getBoxChecked().set(i,new Boolean(false));
            }
        }
        notifyDataSetChanged();


    }

    public void filterData(String query){

        Log.d("queryL:",query);
        query = query.toLowerCase();
        categoryList.clear();

        if(query.isEmpty()){
            categoryList.addAll(copyCategoryList);
        }
        else {

            for(CategoryList categoryListObject: copyCategoryList)
            {
                ArrayList<String> newOptions = new ArrayList<String>();
                ArrayList<Boolean> newBoxChecked = new ArrayList<Boolean>();
                ArrayList<String> options = categoryListObject.getOptions();
                ArrayList<Boolean> boxChecked = categoryListObject.getBoxChecked();
                for(int i=0;i<options.size();i++)
                {
                    if(options.get(i).toLowerCase().contains(query) ){
                        Log.d("add:",options.get(i));
                        newOptions.add(options.get(i));
                        newBoxChecked.add(boxChecked.get(i));
                    }
                }
                CategoryList newCategoryListObj=new CategoryList();
                newCategoryListObj.setCategoryName(categoryListObject.getCategoryName());
                newCategoryListObj.setBoxChecked(newBoxChecked);
                newCategoryListObj.setOptions(newOptions);
               categoryList.add(newCategoryListObj);
            }

        }
        Log.d("sizeada:",categoryList.get(0).getOptions().size()+" "+categoryList.get(0).getBoxChecked().size());
        notifyDataSetChanged();


    }

    @Override
    public void notifyDataSetChanged()
    {
        // Refresh List rows
        Log.d("supeer:","calledd");
        super.notifyDataSetChanged();
    }

    @Override
    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
    }
}
