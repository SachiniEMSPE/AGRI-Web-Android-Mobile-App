package com.darkweb.android.dao;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.OrganizationDescription;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;

import androidx.annotation.RequiresApi;

public class OrganizationDao {

    Context mContext;
    public boolean onChildAdded=false;
    public OrganizationDao(Context context){
        mContext=context;
    }


    //sach * there is a usage of writeOrganizationTOFile
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void addOrganizationToFile(Context context, OrganizationDescription organizationDescriptionObject)
    {
        ArrayList<OrganizationDescription> organizationDescriptionArrayList= getOrganizationListFromFile(mContext);
        if (organizationDescriptionArrayList==null)
        {
            organizationDescriptionArrayList=new ArrayList<OrganizationDescription>();
        }
        if(organizationDescriptionArrayList.size()>0)
        {
            OrganizationDescription organizationDescriptionexist=findByOrganizationUID(organizationDescriptionArrayList,organizationDescriptionObject);
            if(organizationDescriptionexist!=null)
                organizationDescriptionArrayList.remove(organizationDescriptionexist);
        }
        organizationDescriptionArrayList.add(organizationDescriptionObject);
        Log.d("sizeLol:",""+organizationDescriptionArrayList.size());
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    public OrganizationDescription findByOrganizationUID(ArrayList<OrganizationDescription> organizationDescriptionArrayList, OrganizationDescription organizationDescriptionObject) {
       Collection<OrganizationDescription> organizationDescriptionCollection=organizationDescriptionArrayList;
       if(organizationDescriptionObject.getOrganizationUID()!=null)
        return organizationDescriptionCollection.stream().filter(organizationDescriptionListObj -> organizationDescriptionObject.getOrganizationUID().equals(organizationDescriptionListObj.getOrganizationUID())).findFirst().orElse(null);
       return null;
    }

    //*sach - file read/write is detected
    public ArrayList<OrganizationDescription> getOrganizationListFromFile(Context context)
    {
        String url = (String) mContext.getFilesDir().toString();
        File userFile = new File(url, mContext.getString(R.string.organizationDetails));
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream;
        ArrayList<OrganizationDescription> organizationDescriptionArrayList=null;
        if (userFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(userFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                organizationDescriptionArrayList = (ArrayList<OrganizationDescription>) objectInputStream.readObject();
                Log.d("sizearray22:",organizationDescriptionArrayList.size()+"");
                return  organizationDescriptionArrayList;
            }catch (Exception e)
            {
                e.printStackTrace();
                return null;
            }
        }
        return null;
    }

}
