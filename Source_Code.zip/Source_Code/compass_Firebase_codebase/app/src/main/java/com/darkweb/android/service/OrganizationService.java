package com.darkweb.android.service;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Switch;

import com.darkweb.android.adapter.CustomListAdapter;
import com.darkweb.android.compass.R;
import com.darkweb.android.compass.ViewServices;
import com.darkweb.android.dao.OrganizationDao;
import com.darkweb.android.model.CategoryList;
import com.darkweb.android.model.ObjectsForMapper.Organization;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.SortClass;
import com.darkweb.android.parser.HttpFetchOrganizationsList;
import com.darkweb.android.parser.JsontoObject;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;

import static android.content.Context.LOCATION_SERVICE;
import static android.content.Context.MODE_PRIVATE;

public class OrganizationService {

    ArrayList<String> programListOrganisation=new ArrayList<String>();
    ArrayList<ArrayList<String>> serviceListOrganisation = new ArrayList<ArrayList<String>>();
    float colorFloat ;
    float maxColorFloat ;
    float totalCategoryIndex ;
    float count ;
    public OrganizationDao organizationDao;
    Context mContext;
    Map map;
    Marker m;

    //sach_programList and serviceList create here - this was the initial setup with old database
    public OrganizationService(Context context){

        mContext=context;
        organizationDao=new OrganizationDao(mContext);

        for (int i=0;i<5;i++)
        {
            programListOrganisation.add("program "+i);
            ArrayList<String> strList=new ArrayList<String>();
            for(int j=0;j<2;j++)
            {
                strList.add("service "+i+" "+j);
            }
            serviceListOrganisation.add(strList);
        }

        colorFloat = 0.0F; // * sach these are for different marker color selection as per the last model
        maxColorFloat = 360.0F;
        totalCategoryIndex = 52.0F; //sach_no.of categories
        count = maxColorFloat / totalCategoryIndex;

        Log.d("sach_count", String.valueOf(count));
    }


    //*sach:initial database is read here.
    //sach_JSON file declaration
    @RequiresApi(api = Build.VERSION_CODES.N)
    public ArrayList<OrganizationDescription> getOrganizationDescriptionList(Context mContext) throws IOException {
        // organizationDao.getOrganizationListFromFireBase(mContext);
       // return  organizationDao.getOrganizationListFromFile(mContext);
        //return JsontoObject.jsonToObjectData(mContext.getResources().openRawResource(R.raw.schenectadycountyresourcemap));
        return JsontoObject.jsonToObjectData(mContext.getResources().openRawResource(R.raw.newdbnewformattaxonomyupdated)); //sach_updated
    }

    public List<Organization> getOrganizationsFromBackend(Context mContext) throws IOException {
        return HttpFetchOrganizationsList.initOrganizationList();
    }

    //*sach : this function is one of the most used functions. this uses 'category' to plot in map with different color markers.
    // this was the initial arrangement.
    //sach updateServiceList defines here
    @SuppressLint("LongLogTag")
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void updateServiceList(Context context, final ArrayList<OrganizationDescription> finalOrganizationDescriptionArrayList, ArrayList<CategoryList> categoryLists1, View bottomsheetview, CategoryList sortingOptions, String searchText, GoogleMap mMap, Marker m, ListView serviceListView) {

        ArrayList<OrganizationDescription> currentLocationList = new ArrayList<OrganizationDescription>();
        if(finalOrganizationDescriptionArrayList!=null)
            Log.d("sach_finalOrg:",finalOrganizationDescriptionArrayList.size()+"");

        if(finalOrganizationDescriptionArrayList==null || finalOrganizationDescriptionArrayList.size()<=0)
            return;
        if(mMap!=null)
        mMap.clear();
        int a2=0;
        for (OrganizationDescription locationobj : finalOrganizationDescriptionArrayList)
        {

            //Log.d("sach_locationObjGetCategory",locationobj.getCategory());
            int flag = 0;

            for (CategoryList categoryobj : categoryLists1) {
                String categoryName = categoryobj.getCategoryName();
                ArrayList<String> categoryOptions = categoryobj.getOptions();
                ArrayList<Boolean> isCheckedList = categoryobj.getBoxChecked();
                //Log.d("sach_categoryListSize", String.valueOf(categoryLists1.size()));

                if (categoryName.equals("Categories")) {
                    //Log.d("sach",categoryName);
                    for (int i = 0; i < categoryOptions.size(); i++) {
                        //Log.d("sach_categoryOptions", String.valueOf(categoryOptions.size())); > gives the total category size
                        //Log.d("sach_categoryOptions[i]", categoryOptions.get(i));
                        if (locationobj.getTaxCategoryList().contains(categoryOptions.get(i)))//sach edited this > locationobj.getCategory().equals(categoryOptions.get(i))
                        {
                            if (isCheckedList.get(i).equals(new Boolean(true)))
                            {
                                if (searchText!=null && !searchText.equals("") )
                                {
                                    if (locationobj.getOrganizationName().contains(searchText) || locationobj.getCategory().contains(searchText) || locationobj.getContact().contains(searchText) || locationobj.getZipcode().contains(searchText) || locationobj.getState().contains(searchText) || locationobj.getCity().contains(searchText) || locationobj.getDescription().contains(searchText)||locationobj.getEmailId().contains(searchText)||locationobj.getStreetAddress().contains(searchText)||locationobj.getWebsite().contains(searchText))
                                    {
                                        //Log.d("sach_searchText",searchText); //no output
                                        //locationobj.setServiceList(serviceListOrganisation); //sach commented due to new programm array list set created in JsontoObject.java
                                        //locationobj.setProgramList(programListOrganisation); //sach commented due to new programm array list set created in JsontoObject.java
                                        currentLocationList.add(locationobj);

                                        // sach commented - working map funtion - to check the filtered mapping mentioned below after sorting
                                        /*********************************************
                                        LatLng latLng = new LatLng(Double.parseDouble(locationobj.getLatitude()), Double.parseDouble(locationobj.getLongitude()));
                                        //sach_To change the icon propertise

                                        if (mMap != null) {
                                            MarkerOptions markerOptions = new MarkerOptions();
                                            markerOptions.position(latLng);
                                            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.circle10));
                                            //markerOptions.icon(BitmapDescriptorFactory.defaultMarker(locationobj.getMarkerColor()));

                                            markerOptions.title(locationobj.getOrganizationName());
                                            markerOptions.snippet(locationobj.getCategory());
                                            //markerOptions.alpha(0.5f);//sach_added
                                            if (m == null) {
                                                m = mMap.addMarker(markerOptions);
                                            } else
                                                mMap.addMarker(markerOptions);
                                            if (a2>= finalOrganizationDescriptionArrayList.size()-3) {
                                            }
                                            if(a2<=3)
                                            {   //sach_map focus zoom level
                                                mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                                                mMap.animateCamera(CameraUpdateFactory.zoomTo(7));//sach_changed this from 10 >7
                                            }
                                        }
                                        ****************/



                                    }
                                }
                                else
                                {
                                    //locationobj.setServiceList(serviceListOrganisation);//sach commented due to new programm array list set created in JsontoObject.java
                                    //locationobj.setProgramList(programListOrganisation);//sach commented due to new programm array list set created in JsontoObject.java
                                    currentLocationList.add(locationobj);

                                    // sach commented - working map funtion - to check the filtered mapping mentioned below after sorting

                                    /***********************************************
                                    LatLng latLng = new LatLng(Double.parseDouble(locationobj.getLatitude()), Double.parseDouble(locationobj.getLongitude()));

                                    if (mMap != null) {
                                        MarkerOptions markerOptions = new MarkerOptions();
                                        markerOptions.position(latLng);
                                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.circle10));
                                        //markerOptions.icon(BitmapDescriptorFactory.defaultMarker(locationobj.getMarkerColor()));
                                        markerOptions.title(locationobj.getOrganizationName());
                                        markerOptions.snippet(locationobj.getCategory());
                                        //markerOptions.alpha(0.5f);//sach_added
                                        if (m == null) {
                                            m = mMap.addMarker(markerOptions);
                                        } else
                                            mMap.addMarker(markerOptions);
                                        if (a2>= finalOrganizationDescriptionArrayList.size()-3) {
                                        }
                                            if(a2<=3)
                                            {   //sach_map focus zoom level
                                                mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                                                mMap.animateCamera(CameraUpdateFactory.zoomTo(7));//sach_changed this from 10 >7
                                            }
                                    }
                                    ****************************************/


                                }

                            }
                            flag = 1;
                            break;
                        }
                    }
                    if (flag==1)
                    {
                        break;
                    }
                }

            }
            //a2++;
        }

        for(int i=0;i<sortingOptions.getBoxChecked().size();i++)
        {
            Log.d("comp:",sortingOptions.getBoxChecked().get(i)+" "+sortingOptions.getOptions().get(i));

        }
        //sort array
        Log.d("before:",currentLocationList.size()+"");
        currentLocationList = sortServiceList(mContext,currentLocationList, sortingOptions);
        Log.d("aftter:",currentLocationList.size()+"");

        ///sach added map function to map after sorting
        for(OrganizationDescription locationobj : currentLocationList) {

            LatLng latLng = new LatLng(Double.parseDouble(locationobj.getLatitude()), Double.parseDouble(locationobj.getLongitude()));
            //sach_To change the icon propertise

            if (mMap != null) {
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.circle10));
                //markerOptions.icon(BitmapDescriptorFactory.defaultMarker(locationobj.getMarkerColor()));

                markerOptions.title(locationobj.getOrganizationName());
                markerOptions.snippet(locationobj.getCategory());
                //markerOptions.alpha(0.5f);//sach_added
                if (m == null) {
                    m = mMap.addMarker(markerOptions);
                } else
                    mMap.addMarker(markerOptions);
                if (a2 >= finalOrganizationDescriptionArrayList.size() - 3) {
                }
                if (a2 <= 3) {   //sach_map focus zoom level
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                    mMap.animateCamera(CameraUpdateFactory.zoomTo(7));//sach_changed this from 10 >7
                }
            }a2++;

        }

        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {

                marker.showInfoWindow();

                Log.d("title:", "" + marker.getTitle() + "  marker" + (marker == null));
                return false;
            }
        });

        //sach_map marker info window  click
        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                Intent intent = new Intent(mContext, ViewServices.class);
                OrganizationDescription locObj = findLocationDescriptionObject(marker.getTitle(), finalOrganizationDescriptionArrayList);
                if(locObj!=null)
                {
                    Log.d("colors:",locObj.getMarkerColor()+"  sd:" +locObj.getServiceList().size());

                    intent.putExtra("serviceObject", locObj);//sach_taking matching(to marker title)object as "serviceObject"(this is just a representation to the next intent (viewServces class).
                    mContext.startActivity(intent);
                }

            }
        });

        CustomListAdapter serviceListAdapter = new CustomListAdapter((Activity) mContext , currentLocationList);
        serviceListView = (ListView) bottomsheetview.findViewById(R.id.servicelist);
        serviceListView.setAdapter(serviceListAdapter);
        ArrayList<OrganizationDescription> finalCurrentLocationList = currentLocationList;
        serviceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                finalCurrentLocationList.get(position);
                OrganizationDescription locObj = finalCurrentLocationList.get(position);
                Intent i = new Intent(mContext, ViewServices.class);
                i.putExtra("serviceObject", locObj);
                mContext.startActivity(i);
            }
        });
    }




    //sach sort process
    @RequiresApi(api = Build.VERSION_CODES.N)
    private ArrayList<OrganizationDescription> sortServiceList(Context context,ArrayList<OrganizationDescription> currentLocationList, CategoryList categoryList) {
        String sortBy = null;
        Log.d("size:",categoryList.getBoxChecked().size()+" "+categoryList.getOptions().size());
        for (int i=0;i<categoryList.getBoxChecked().size();i++)
        {
            Log.d("sortservices",categoryList.getBoxChecked().get(i)+" ");
            if (categoryList.getBoxChecked().get(i)==true) {

                sortBy = categoryList.getOptions().get(i);
                Log.d("sortservices",sortBy+" ");
                break;
            }
        }
        Log.d("sach_currentLoc", String.valueOf(currentLocationList.size()));

        //sach - sorting starts here
        if (sortBy != null) {
            Log.d("sortByInsort",sortBy);

            //sach added
            Log.d("sach_openNowOptionsB", String.valueOf(categoryList.getOpenNowOptions()));
            Log.d("sach_opennowSwitch", String.valueOf(categoryList.getOpenNowSwitch()));

            // sach openswitch ON
            if(categoryList.getOpenNowSwitch()){
                Log.d("sach_open","true");

                currentLocationList.sort(Comparator.comparingDouble(OrganizationDescription::getDistance));
                String selectedDistance = categoryList.getOpenNowOptions().get(2);
                float searchDistance = 0;
                switch (selectedDistance){
                    case "10 miles" :
                        searchDistance = 10;
                        break;
                    case "20 miles" :
                        searchDistance = 20;
                        break;
                    case "30 miles" :
                        searchDistance = 30;
                        break;
                    default:
                        searchDistance = 0;
                        break;
                }
                //sach - loop through currentLocationList List and filter only relevent distance objects
                ArrayList<OrganizationDescription> tempLocationList = new ArrayList<>();
                ArrayList<OrganizationDescription> tempLocationListDistance = new ArrayList<>();

                for(OrganizationDescription locationObject : currentLocationList){

                    if(searchDistance == 0){
                        tempLocationList = currentLocationList;
                    }else if(locationObject.getDistance()<=searchDistance){
                        tempLocationList.add(locationObject);
                    }else
                        break;
                }
                currentLocationList = tempLocationList;

                if (sortBy.equals(mContext.getString(R.string.alphanumeric_sortby_service_request))) {
                    Log.d("df:", "alphanumeric");
                    currentLocationList.sort(Comparator.comparing(OrganizationDescription::getOrganizationName));

                }
                if (sortBy.equals(mContext.getString(R.string.distance)))
                {
                    Log.d("df:", "distance");
                    currentLocationList.sort(Comparator.comparingDouble(OrganizationDescription::getDistance));
                }
                if (sortBy.equals(mContext.getString(R.string.frequentlyUsed)))
                {
                    currentLocationList.sort(Comparator.comparing(OrganizationDescription::getOrganizationName));
                    currentLocationList= SortClass.sortByFrequentlyUsed(currentLocationList,mContext);
                }

            }else
                //sach if open switch OFF
                {
                Log.d("sach_open","false");
                if (sortBy.equals(mContext.getString(R.string.alphanumeric_sortby_service_request))) {
                    Log.d("df:", "alphanumeric");
                    currentLocationList.sort(Comparator.comparing(OrganizationDescription::getOrganizationName));
                }
                if (sortBy.equals(mContext.getString(R.string.distance)))
                {
                    Log.d("df:", "distance");
                    currentLocationList.sort(Comparator.comparingDouble(OrganizationDescription::getDistance));
                }
                if (sortBy.equals(mContext.getString(R.string.frequentlyUsed)))
                {
                    currentLocationList.sort(Comparator.comparing(OrganizationDescription::getOrganizationName));
                    currentLocationList= SortClass.sortByFrequentlyUsed(currentLocationList,mContext);
                }
            }

            //sach commented and used as above
            /*
            if (sortBy.equals(mContext.getString(R.string.alphanumeric_sortby_service_request))) {
                Log.d("df:", "alphanumeric");
                currentLocationList.sort(Comparator.comparing(OrganizationDescription::getOrganizationName));
            }
            if (sortBy.equals(mContext.getString(R.string.distance)))
            {
                Log.d("df:", "distance");
                currentLocationList.sort(Comparator.comparingDouble(OrganizationDescription::getDistance));
            }
            if (sortBy.equals(mContext.getString(R.string.frequentlyUsed)))
            {
                currentLocationList.sort(Comparator.comparing(OrganizationDescription::getOrganizationName));
                currentLocationList= SortClass.sortByFrequentlyUsed(currentLocationList,mContext);
            }
            */

            /*
            if(sortBy.equals(mContext.getString(R.string.Open_now))){
                Log.d("sach_SortFunctionHere","yes");
                Log.d("sach_openNowOptionsOS",categoryList.getOpenNowOptions()+"");
                currentLocationList.sort(Comparator.comparingDouble(OrganizationDescription::getDistance));
                String selectedDistance = categoryList.getOpenNowOptions().get(2);
                float searchDistance = 0;
                switch (selectedDistance){
                    case "1 mile" :
                         searchDistance = 10;
                         break;
                    case "2 miles" :
                        searchDistance = 20;
                        break;
                    case "3 miles" :
                        searchDistance = 30;
                        break;
                    default:
                        searchDistance = 0;
                        break;
                }
                //sach - loop through currentLocationList List and filter only relevent distance objects
                ArrayList<OrganizationDescription> tempLocationList = new ArrayList<>();
                for(OrganizationDescription locationObject : currentLocationList){

                    if(searchDistance == 0){
                        tempLocationList = currentLocationList;
                    }else if(locationObject.getDistance()<=searchDistance){
                        tempLocationList.add(locationObject);
                    }else
                        break;
                }
                currentLocationList = tempLocationList;
            }
           */
        }
        return currentLocationList;
    }

    public void sachUpdateServiceList(Context context, final ArrayList<OrganizationDescription> currentLocationList,  CategoryList sortingOptions, GoogleMap mMap, Marker m){

        for(OrganizationDescription locationObj : currentLocationList){
            LatLng latLng = new LatLng(Double.parseDouble(locationObj.getLatitude()),Double.parseDouble(locationObj.getLongitude()));
            if(mMap!=null){
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.icon(BitmapDescriptorFactory.defaultMarker(locationObj.getMarkerColor()));
                markerOptions.title(locationObj.getOrganizationName());
                markerOptions.snippet(locationObj.getCategory());
                if(m==null){
                    m = mMap.addMarker(markerOptions);
                }else{
                    mMap.addMarker(markerOptions);
                }
            }
        }


    }

    //sach_this is where when searched direct to relevant organization details page
    public OrganizationDescription findLocationDescriptionObject(String title, ArrayList<OrganizationDescription> organizationDescriptionArrayList) {
        for (OrganizationDescription locObj :organizationDescriptionArrayList) {
            if ((locObj.getDescription().equals(title)) || (locObj.getOrganizationName().equals(title))){
                //sach_changed getName to getDescription.
                //sach_then modified to filter both by name and description
                return locObj;


            }

        }
        return null;
    }


    //*sach this function uses the whole big arraylist of organization objects

    public void setMarkerToList(Context context, ArrayList<OrganizationDescription> finalOrganizationDescriptionArrayList, ArrayList<String> categories, ArrayList<String> serviceAutoListOrganisation,ArrayList<String> descriptionOrgArrayList,ArrayList<String> combinedNameDescriptionArrayList, Map<String, Float> categoryListColor, Location lastlocation) {
        String color = "";
        if(finalOrganizationDescriptionArrayList==null)
            return;
        for (OrganizationDescription locationDes : finalOrganizationDescriptionArrayList) {
//sach_fill org name
            serviceAutoListOrganisation.add(locationDes.getOrganizationName());
//sach_fill description
            descriptionOrgArrayList.add(locationDes.getDescription());//sach_added new arraylist
//sach_ get lat long
            LatLng latLng = new LatLng(Double.parseDouble(locationDes.getLatitude()), Double.parseDouble(locationDes.getLongitude()));//sach_get lon lat
//sach_fill category color * this category color is no longer in use , since we changed them to dots
            if (!categoryListColor.containsKey(locationDes.getCategory())) {
                if(locationDes.getMarkerColor()==0.0F){
                    categoryListColor.put(locationDes.getCategory(), this.colorFloat);
                    locationDes.setMarkerColor(this.colorFloat);
                }
                else {
                    categoryListColor.put(locationDes.getCategory(), locationDes.getMarkerColor());
                }
                /*sach_always "if" function needs not to be alone. Otherwise dissapointable error (like no points in map) occurs. To avoid either put Log.d or comment "if" function as well if it is not required !!!
                //Log.d("sach_getProgList1", String.valueOf(locationDes.getProgramList()));
                //Log.d("sach_getServiceList2", String.valueOf(locationDes.getServiceList()));
                //if(locationDes.getProgramList()==null)
                    //Log.d("sach_getProgList", String.valueOf(locationDes.getProgramList()));
                  //  locationDes.setProgramList(programListOrganisation);//sach commented due to new programm array list set created in JsontoObject.java
                //if(locationDes.getServiceList()==null)
                    //Log.d("sach_getServiceList", String.valueOf(locationDes.getServiceList()));
                  //  locationDes.setServiceList(serviceListOrganisation);//sach commented due to new programm array list set created in JsontoObject.java
                 */

                //sach added to update filter category list with taxonomy categories by removing duplicates.
                ArrayList<String> categoryInitial = locationDes.getTaxCategoryList();
                //Log.d("sach_catInitialSize", String.valueOf(categoryInitial.size()));

                List <String> categoryInitialCopy = new ArrayList<>(categoryInitial);
                categoryInitialCopy.removeAll(categories);
                categories.addAll(categoryInitialCopy);
                categories.remove(""); //sach _ to remove empty category item

                //sach commented to edit catogories content
                /*
                if (!categories.contains(locationDes.getCategory())) //sach_changed from category to city
                    categories.add(locationDes.getCategory());
                    //categories.add(locationDes.getCity()); //sach_added
                    //Log.d("sach_locagetCategory",locationDes.getCategory());
                */
                this.colorFloat = this.colorFloat + this.count;
            } else {
                locationDes.setMarkerColor(categoryListColor.get(locationDes.getCategory()));
            }
            //Log.d("sach","categoryListColor"+categoryListColor);

            if (lastlocation==null)
            {
                SharedPreferences sharedPreferences = mContext.getSharedPreferences("currentlocation", MODE_PRIVATE);
                // Get saved string data in it.
                String userInfoListJsonString = sharedPreferences.getString("currentlocation", "");
                // Create Gson object and translate the json string to related java object array.
                Gson gson = new Gson();
                lastlocation = gson.fromJson(userInfoListJsonString, Location.class);
            }
            Location locaDescLocation=new Location("LocationDesc Location");
            locaDescLocation.setLatitude(Double.parseDouble(locationDes.getLatitude()));
            locaDescLocation.setLongitude(Double.parseDouble(locationDes.getLongitude()));
//            Log.d("null location:",(lastlocation==null)+"  s:"+(locaDescLocation==null));
            LocationManager locationManager = (LocationManager) mContext.getSystemService(LOCATION_SERVICE);
            if(lastlocation==null)
            {
                if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                }
                else
                {
                    lastlocation = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                   // Log.d("location_cal:","This : "+lastlocation.toString()); //sach commented
                }
            }
            //sach_visualizing distance calculation
            if(lastlocation!=null && locaDescLocation!=null)
            {
                lastlocation = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                //For Demo Purpouse
                Location selected_location=new Location("Ualbany");
                selected_location.setLatitude(42.6850);
                selected_location.setLongitude(73.8248);
//                Log.d("Last_loc",""+lastlocation);
                if(lastlocation==null){
                    lastlocation=selected_location;
                }
                locationDes.setDistance(lastlocation.distanceTo(locaDescLocation)*0.621f/1000);
                 //locationDes.setDistance(selected_location.distanceTo(locaDescLocation)*0.621f/1000);
            }
        }
        combinedNameDescriptionArrayList.addAll(serviceAutoListOrganisation);
        combinedNameDescriptionArrayList.addAll(descriptionOrgArrayList);//sach_add combined name and description arraylist
    }



//sach updateCategorySortList
    public CategoryList updateCategorySortList(String sortByItem, CategoryList clTemp) {
        int i = 0;
        for (String s : clTemp.getOptions()) {
            if (s.equals(sortByItem)) {
                clTemp.getBoxChecked().set(i, new Boolean(true));
            } else {
                clTemp.getBoxChecked().set(i, new Boolean(false));
            }
            Log.d("sortbyArray:", clTemp.getBoxChecked().get(i) + "");
            i++;
        }
        return clTemp;
    }

    //*sach  file write process is going on inside this function
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void addOrganizationToFile(Context context, OrganizationDescription organizationDescriptionObject){
        organizationDao.addOrganizationToFile(mContext,organizationDescriptionObject);
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public OrganizationDescription findByOrganizationUID(ArrayList<OrganizationDescription> organizationDescriptionArrayList, OrganizationDescription organizationDescriptionObject) {
        return organizationDao.findByOrganizationUID(organizationDescriptionArrayList,organizationDescriptionObject);
    }
}