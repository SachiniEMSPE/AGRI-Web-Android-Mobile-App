package com.darkweb.android.dao;

public class NearByRequestDao {
    private double currentLat;
    private double currentLong;
    private int limitedDistance;
    private int limitedOrganizations;

    public NearByRequestDao(double currentLat, double currentLong, int limitedDistance, int limitedOrganizations) {
        this.currentLat = currentLat;
        this.currentLong = currentLong;
        this.limitedDistance = limitedDistance;
        this.limitedOrganizations = limitedOrganizations;
    }

    public NearByRequestDao() {
    }

    public double getCurrentLat() {
        return currentLat;
    }

    public void setCurrentLat(double currentLat) {
        this.currentLat = currentLat;
    }

    public double getCurrentLong() {
        return currentLong;
    }

    public void setCurrentLong(double currentLong) {
        this.currentLong = currentLong;
    }

    public int getLimitedDistance() {
        return limitedDistance;
    }

    public void setLimitedDistance(int limitedDistance) {
        this.limitedDistance = limitedDistance;
    }

    public int getLimitedOrganizations() {
        return limitedOrganizations;
    }

    public void setLimitedOrganizations(int limitedOrganizations) {
        this.limitedOrganizations = limitedOrganizations;
    }
}
