package com.darkweb.android.activities;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.darkweb.android.compass.R;
import com.darkweb.android.global.SimpleApiResponse;
import com.darkweb.android.model.ObjectsForMapper.UpdateStatusPayload;
import com.darkweb.android.service.FileUtil;
import com.darkweb.android.service.HttpHandlers.HttpFileUploadHandler;
import com.darkweb.android.service.HttpHandlers.HttpRequestUpdateHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

import java.util.concurrent.ExecutionException;


public class FileUploadActivity extends AppCompatActivity {

    private final int REQUEST_CODE_FILE_PICKER = 100;
    private ImageView fileUploadIconView;
    private File file = null;
    private ProgressBar progressBar;

    private String requestedId;
    private int local_user_id;
    private int organization_id;
    private int service_id;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fileupload);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            local_user_id = extras.getInt("clientId");
            organization_id = extras.getInt("organizationId");
            service_id = extras.getInt("serviceId");
            requestedId = extras.getString("requestedId");
        }

        fileUploadIconView = findViewById(R.id.image_file_upload);
        fileUploadIconView.setOnClickListener(view -> openFileOnLocal());

        progressBar = findViewById(R.id.upload_progress_bar);
        progressBar.setProgress(0);

        Button uploadButton = findViewById(R.id.button_upload);
        uploadButton.setOnClickListener(view -> {
            if (file != null) {
                try {
                    String result = new HttpFileUploadHandler(
                            file, local_user_id, service_id, organization_id).execute("").get();
                    ObjectMapper mapper = new ObjectMapper();
                    SimpleApiResponse response = mapper.readValue(result, SimpleApiResponse.class);
                    if (response.isSuccess()) {
                        progressBar.setProgress(100);
                        Toast.makeText(getApplicationContext(),
                                "File uploaded.", Toast.LENGTH_SHORT).show();
                        if (updateRequestStatus()) {
                            finish();
                        }
                    }
                } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private boolean updateRequestStatus() {
        UpdateStatusPayload statusPayload = new UpdateStatusPayload(
                Integer.parseInt(requestedId), local_user_id, "pending");
        ObjectMapper mapper = new ObjectMapper();
        String resultJSON = null;
        try {
            resultJSON = new HttpRequestUpdateHandler()
                    .execute(mapper.writeValueAsString(statusPayload)).get();
            JSONObject result = new JSONObject(resultJSON);
            boolean updated = result.getBoolean("success");
            if (updated) {
                return true;
            }
        } catch (ExecutionException | InterruptedException | JsonProcessingException | JSONException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void openFileOnLocal() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, REQUEST_CODE_FILE_PICKER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_FILE_PICKER &&
                resultCode == Activity.RESULT_OK && data != null) {
            Uri selectedFile = data.getData();
            fileUploadIconView.setImageURI(selectedFile);
            try {
                file = FileUtil.from(this, data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
