package com.darkweb.android.compass;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;

import com.darkweb.android.adapter.CustomListAdapter;
import com.darkweb.android.adapter.MyExpandableListAdapter;
import com.darkweb.android.adapter.sachExpandableListAdapter;

import com.darkweb.android.global.MyGlobalVars;
import com.darkweb.android.model.CategoryList;
import com.darkweb.android.model.ObjectsForMapper.Organization;
import com.darkweb.android.model.ObjectsForMapper.Program;
import com.darkweb.android.model.ObjectsForMapper.Service;
import com.darkweb.android.model.ObjectsForMapper.Taxonomy;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.SortClass;
import com.darkweb.android.service.HttpHandlers.HttpBookmarkHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import static android.app.Activity.RESULT_OK;
import static android.content.Context.LOCATION_SERVICE;
import static android.content.Context.MODE_PRIVATE;

//Bookmarked organization
public class FragmentBookmark extends Fragment implements
        OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener,UpdateBookmarkFragment {
    ArrayList<String> programListOrganisation=new ArrayList<String>();
    ArrayList<ArrayList<String>> serviceListOrganisation = new ArrayList<ArrayList<String>>();
    ArrayList<String> serviceAutoListOrganisation=new ArrayList<String>();
    int flagResult=0;
    ImageButton listmapbutton;
    ImageButton maplistbutton;
    Marker m;
    String sortByItem;
    private GoogleMap mMap;
    private GoogleApiClient client;
    private LocationRequest locationRequest;
    private Location lastlocation;
    private Marker currentLocationmMarker;
    public static final int REQUEST_LOCATION_CODE = 99;
    int PROXIMITY_RADIUS = 10000;
    double latitude, longitude;
    ImageButton filter;
    float maxColorFloat = 360.0F;
    float totalCategoryIndex = 52.0F;
    float count = maxColorFloat / totalCategoryIndex;
    private ExpandableListView categoryListview;
    private MyExpandableListAdapter myExpandableListAdapter;
    ArrayList<CategoryList> categoryLists1 = new ArrayList<CategoryList>();
    ArrayList<OrganizationDescription> organizationDescriptionList;
    View bottomsheetview;
    Spinner spinnerSortBy;
    BottomSheetBehavior bottomSheetBehavior;
    Button listmapBottomButton;
    ListView serviceListView;
    CategoryList cl1 = new CategoryList();
    CategoryList sortingOptions = new CategoryList();
    Button filterApplybutton, filtercancelbutton;
    FloatingActionButton fab;
    ArrayList<HashMap<String, String>> contactList;
    StringBuilder googlePlaceUrl;
    String url;
    private LatLng currentLatLang;
    AutoCompleteTextView organizationAutoTextView ;
    private String searchText;
    private int selectedSort=-1;
    private TextView resetAllTextView;
    private HashMap<String, Boolean> checkBoxBooleanList;
    private View view;
    private boolean firstTime=true;


    @Override
    public void onStart() {
        super.onStart();
        System.out.println("-x-x-x-x-x- Bookmark Fragment onStart() ------");
        SharedPreferences sp = Objects.requireNonNull(FragmentBookmark.this.getActivity())
                .getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);

        // Only fetching requested services when user logged in
        if (local_user_id != 0) {
            organizationDescriptionList = new ArrayList<>();
            try {
                String bookmarkedOrganizationsJSON =
                        new HttpBookmarkHandler().execute(Integer.toString(local_user_id), "getbookmarks").get();
                // Extract list of organizations this user saved, put to the list
                ObjectMapper mapper = new ObjectMapper();
                List<Organization> organizations =
                        mapper.readValue(bookmarkedOrganizationsJSON,
                        new TypeReference<List<Organization>>() {});

                for (Organization organization : organizations) {
                    // just another copy of inefficient loop from Json2Object
                    OrganizationDescription org_desc = new OrganizationDescription();
                    org_desc.setOrganizationName(organization.getName());
                    org_desc.setOrganizationID(organization.getId().toString());
                    org_desc.setContact(organization.getPhone());
                    org_desc.setDescription(organization.getDescription());
                    org_desc.setHours(organization.getHours());
                    org_desc.setLanguages(organization.getLanguageSpoken());
                    org_desc.setEmailId(organization.getEmail());
                    org_desc.setLongitude(organization.getLongitude().toString());
                    org_desc.setLatitude(organization.getLatitude().toString());
                    org_desc.setStreetAddress(organization.getPhysicalStreetAddress1());
                    org_desc.setCity(organization.getPhysicalCity());
                    org_desc.setState(organization.getPhysicalState());
                    org_desc.setZipcode(organization.getPhysicalZipCode());
                    org_desc.setWebsite(organization.getWebAddress());
                    ArrayList <String> programArrayNames= new ArrayList<>();
                    ArrayList<ArrayList<String>> serviceArrayNames= new ArrayList<>();
                    ArrayList <String> programArrayUIDs= new ArrayList<>();
                    ArrayList<ArrayList<String>> serviceArrayUIDs= new ArrayList<>();
                    ArrayList<ArrayList<String>> ServiceArrayDescription = new ArrayList<>();
                    ArrayList<ArrayList<String>> ServiceArrayEligibility = new ArrayList<>();
                    ArrayList<ArrayList<String>> ServiceArraySpecificHours = new ArrayList<>();
                    ArrayList<ArrayList<String>> ServiceArrayAdditionalReq = new ArrayList<>();
                    ArrayList<String> taxCategoryArrayList = new ArrayList<>();
                    String Category = "";
                    for (Program program : organization.getPrograms()) {
                        String programName = program.getName();
                        String programUID = program.getId().toString();
                        programArrayNames.add(programName);
                        programArrayUIDs.add(programUID);
                        ArrayList<String> subServiceArrayNames = new ArrayList<>();
                        ArrayList<String> subServiceArrayUIDs = new ArrayList<>();
                        ArrayList<String> subServiceArrayDescription = new ArrayList<>();
                        ArrayList<String> subServiceArrayEligibility = new ArrayList<>();
                        ArrayList<String> subServiceSpecificHours = new ArrayList<>();
                        ArrayList<String> subServiceArrayAdditionalReq = new ArrayList<>();
                        ArrayList<String> subTaxCategoryArrayList =new ArrayList<>();
                        for (Service service : program.getServices()) {
                            String serviceName = service.getName();
                            subServiceArrayNames.add(serviceName);
                            String serviceUID = service.getId().toString();
                            subServiceArrayUIDs.add(serviceUID);
                            String serviceDescription = service.getDescription();
                            if(serviceDescription.isEmpty()){
                                subServiceArrayDescription.add("Description : N/A");
                            }else{
                                subServiceArrayDescription.add(serviceDescription.trim());
                            }
                            String serviceEligibility = service.getEligibility();
                            if(serviceEligibility.isEmpty()){
                                subServiceArrayEligibility.add("N/A");
                            }else {
                                subServiceArrayEligibility.add(serviceEligibility.trim());
                            }
                            String serviceSpecificHours = service.getSpecificHours();
                            if(serviceSpecificHours.isEmpty()){
                                subServiceSpecificHours.add("N/A");
                            }else {
                                subServiceSpecificHours.add(serviceSpecificHours.trim());
                            }
                            String serviceAdditionalReq = service.getAdditionalRequirements();
                            if(serviceAdditionalReq.isEmpty()){
                                subServiceArrayAdditionalReq.add("N/A");
                            }else{
                                subServiceArrayAdditionalReq.add(serviceAdditionalReq.trim());
                            }
                            String subCategory = "";
                            for (Taxonomy taxonomy : service.getTaxonomyList()) {
                                String category = taxonomy.getCategory();
                                subTaxCategoryArrayList.add(category);
                                subCategory = subCategory + category +"\n";
                            }
                            List<String> subTaxCategoryArrayListCopy = new ArrayList<>(subTaxCategoryArrayList);
                            subTaxCategoryArrayListCopy.removeAll(taxCategoryArrayList);
                            taxCategoryArrayList.addAll(subTaxCategoryArrayListCopy);
                            Category = Category + subCategory ;
                        }
                        serviceArrayNames.add(subServiceArrayNames);
                        serviceArrayUIDs.add(subServiceArrayUIDs);
                        ServiceArrayDescription.add(subServiceArrayDescription);
                        ServiceArrayEligibility.add(subServiceArrayEligibility);
                        ServiceArraySpecificHours.add(subServiceSpecificHours);
                        ServiceArrayAdditionalReq.add(subServiceArrayAdditionalReq);
                    }
                    org_desc.setProgramList(programArrayNames);
                    org_desc.setProgramUIDList(programArrayUIDs);
                    org_desc.setServiceList(serviceArrayNames);
                    org_desc.setServiceUIDList(serviceArrayUIDs);
                    org_desc.setServiceArrayDescription(ServiceArrayDescription);
                    org_desc.setServiceArrayEligibility(ServiceArrayEligibility);
                    org_desc.setServiceArraySpecificHours(ServiceArraySpecificHours);
                    org_desc.setServiceArrayAdditionalReq(ServiceArrayAdditionalReq);
                    org_desc.setCategory(Category);
                    org_desc.setTaxCategoryList(taxCategoryArrayList);
                    organizationDescriptionList.add(org_desc);
                }
                System.out.println("This processing is running after user logged in");


            } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_1, container, false);
        return view;

    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        url = getActivity().getFilesDir().toString();
        filter = (ImageButton) view.findViewById(R.id.filterButton);
        organizationAutoTextView = view.findViewById(R.id.Organization_name_searchview);
        organizationAutoTextView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    if(event.getRawX() >= (organizationAutoTextView.getRight() - organizationAutoTextView.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

                        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                            startActivityForResult(intent, 10);
                        }
                        return true;
                    }
                }
                if(event.getRawX() <= organizationAutoTextView.getTotalPaddingLeft()) {
                    // your action for drawable click event
                    String searchText = organizationAutoTextView.getText().toString();
                    if (!searchText.equals(""))
                    {
                        updateServiceList(organizationDescriptionList, categoryLists1, bottomsheetview, sortingOptions,searchText);
                    }
                    return true;
                }
                return false;
            }
        });

        filter.setEnabled(false);
        serviceListView = (ListView) view.findViewById(R.id.servicelist);
        for (int i=0;i<3;i++)
        {
            programListOrganisation.add("program "+i);
            ArrayList<String> strList=new ArrayList<String>();
            for(int j=0;j<2;j++)
            {
                strList.add("service "+i+" "+j);
            }
            serviceListOrganisation.add(strList);
        }

        fab = view.findViewById(R.id.fab);
        fab.hide();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(FragmentBookmark.this.getActivity(), ServiceRequest.class);
                startActivity(i);
            }
        });


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkLocationPermission();

        }
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.


        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }



    private void setMarkerToList(ArrayList<OrganizationDescription> organizationDescriptionList, ArrayList<String> categories) {
        for (OrganizationDescription locationDes : organizationDescriptionList) {
            serviceAutoListOrganisation.add(locationDes.getOrganizationName());
            LatLng latLng = new LatLng(Double.parseDouble(locationDes.getLatitude()), Double.parseDouble(locationDes.getLongitude()));
            if (!categories.contains(locationDes.getCategory()))
                 categories.add(locationDes.getCategory());
            Log.d("sach_catogories", String.valueOf(categories));
            if (lastlocation==null)
            {
                Context ctx = getActivity();
                SharedPreferences sharedPreferences = ctx.getSharedPreferences("currentlocation", MODE_PRIVATE);

                // Get saved string data in it.
                String userInfoListJsonString = sharedPreferences.getString("currentlocation", "");

                // Create Gson object and translate the json string to related java object array.
                Gson gson = new Gson();
                lastlocation = gson.fromJson(userInfoListJsonString, Location.class);
            }
            Location locaDescLocation=new Location("LocationDesc Location");
            locaDescLocation.setLatitude(Double.parseDouble(locationDes.getLatitude()));
            locaDescLocation.setLongitude(Double.parseDouble(locationDes.getLongitude()));
            Log.v("The location is",""+locaDescLocation);
            if(lastlocation==null)
            {
                Log.v("The distance is","The distance is calculated"+lastlocation);
                LocationManager locationManager = (LocationManager) getActivity().getSystemService(LOCATION_SERVICE);
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                }else
                {
                    lastlocation = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                }

            }
            if(lastlocation!=null && locaDescLocation!=null)
            {

                FragmentBookmark.this.getActivity().runOnUiThread(new Runnable(){
                    public void run(){
                 mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(lastlocation.getLatitude(), lastlocation.getLongitude())));
                 mMap.animateCamera(CameraUpdateFactory.zoomBy(3));

                  locationDes.setDistance(lastlocation.distanceTo(locaDescLocation)/1000);
                  Log.v("The distance is","The distance is calculated"+lastlocation.distanceTo(locaDescLocation)/1000);
                    }
                });
            }
              
        }
    }

    public OrganizationDescription findLocationDescriptionObject(String title, ArrayList<OrganizationDescription> organizationDescriptionList) {

            for (OrganizationDescription locObj : organizationDescriptionList) {
                if (locObj.getOrganizationName().equals(title)) {
                    return locObj;
                }

            }

        return null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_LOCATION_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED) {
                        if (client == null) {
                            bulidGoogleApiClient();
                        }
                        mMap.setMyLocationEnabled(true);
                    }
                } else {
                }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if(requestCode==2)
        {
            flagResult=1;
            new GetCourseCategoriesMarkerColor().execute();
        }
        if(requestCode==10)
        {
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    organizationAutoTextView.setText(result.get(0));
                }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            bulidGoogleApiClient();
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setZoomControlsEnabled(true);
        }


//Options
        sortingOptions.setCategoryName("Sort By:");
        ArrayList<String> sortingBy = new ArrayList<String>();
        ArrayList<Boolean> isSortBoxCheckedList = new ArrayList<Boolean>();
        sortingBy.add("Alphabetically");
        sortingBy.add("Distance");
        sortingBy.add("Frequently Used");
        isSortBoxCheckedList.add(new Boolean(true));
        isSortBoxCheckedList.add(new Boolean(false));
        isSortBoxCheckedList.add(new Boolean(false));
        sortingOptions.setOptions(sortingBy);
        sortingOptions.setBoxChecked(isSortBoxCheckedList);
        //  categoryLists1.add(sortingOptions);
        updateFragment();
    }


    private CategoryList updateCategorySortList(String sortByItem, CategoryList clTemp) {

        int i = 0;
        for (String s : clTemp.getOptions()) {
            if (s.equals(sortByItem)) {
                clTemp.getBoxChecked().set(i, new Boolean(true));
            } else {
                clTemp.getBoxChecked().set(i, new Boolean(false));
            }
            i++;
        }

        return clTemp;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!firstTime)
            updateFragment();
    }

    @TargetApi(Build.VERSION_CODES.N)
    private void updateServiceList(final ArrayList<OrganizationDescription> organizationDescriptionList, ArrayList<CategoryList> categoryLists1, View bottomsheetview, CategoryList sortingOptions, String searchText) {

        ArrayList<OrganizationDescription> currentLocationList = new ArrayList<OrganizationDescription>();
        mMap.clear();
            for (OrganizationDescription locationobj : organizationDescriptionList) {
                int flag = 0;
                for (CategoryList categoryobj : categoryLists1) {
                    String categoryName = categoryobj.getCategoryName();
                    ArrayList<String> categoryOptions = categoryobj.getOptions();
                    ArrayList<Boolean> isCheckedList = categoryobj.getBoxChecked();
                    if (categoryName.equals("Categories")) {
                        for (int i = 0; i < categoryOptions.size(); i++) {
                            if (locationobj.getCategory().equals(categoryOptions.get(i)))
                            {
                                if (isCheckedList.get(i).equals(new Boolean(true)))
                                {
                                    if (searchText!=null && !searchText.equals("") )
                                    {
                                        if (locationobj.getOrganizationName().contains(searchText) || locationobj.getCategory().contains(searchText) || locationobj.getContact().contains(searchText) || locationobj.getZipcode().contains(searchText) || locationobj.getState().contains(searchText) || locationobj.getCity().contains(searchText) || locationobj.getDescription().contains(searchText)||locationobj.getEmailId().contains(searchText)||locationobj.getStreetAddress().contains(searchText)||locationobj.getWebsite().contains(searchText))
                                        {
                                            //locationobj.setServiceList(serviceListOrganisation); //sach_commented
                                            //locationobj.setProgramList(programListOrganisation); //Sach_commented
                                            currentLocationList.add(locationobj);
                                            LatLng latLng = new LatLng(Double.parseDouble(locationobj.getLatitude()), Double.parseDouble(locationobj.getLongitude()));

                                            if (mMap != null) {
                                                MarkerOptions markerOptions = new MarkerOptions();
                                                markerOptions.position(latLng);
                                                markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.circle10)); //sach_added
                                                //markerOptions.icon(BitmapDescriptorFactory.defaultMarker(locationobj.getMarkerColor()));
                                                markerOptions.title(locationobj.getOrganizationName());
                                                markerOptions.snippet(locationobj.getCategory());
                                                if (m == null) {
                                                    m = mMap.addMarker(markerOptions);
                                                } else
                                                    mMap.addMarker(markerOptions);
                               //                 mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                                 //               mMap.animateCamera(CameraUpdateFactory.zoomTo(10));
                                            }
                                        }
                                    }
                                    else
                                    {
                                        //locationobj.setServiceList(serviceListOrganisation); //sach_commented
                                        //locationobj.setProgramList(programListOrganisation); //sach_commented
                                        currentLocationList.add(locationobj);
                                        LatLng latLng = new LatLng(Double.parseDouble(locationobj.getLatitude()), Double.parseDouble(locationobj.getLongitude()));
                                        if (mMap != null) {
                                            MarkerOptions markerOptions = new MarkerOptions();
                                            markerOptions.position(latLng);
                                            markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.circle10));//sach_added
                                            //markerOptions.icon(BitmapDescriptorFactory.defaultMarker(locationobj.getMarkerColor()));
                                            markerOptions.title(locationobj.getOrganizationName());
                                            markerOptions.snippet(locationobj.getCategory());
                                            if (m == null) {
                                                m = mMap.addMarker(markerOptions);
                                            } else
                                                mMap.addMarker(markerOptions);
                                            // mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                                            // mMap.animateCamera(CameraUpdateFactory.zoomTo(10));
                                        }
                                    }
                                }
                                flag = 1;
                                break;
                            }
                        }
                        if (flag==1)
                        {
                            break;
                        }
                    }
                }
            }

       currentLocationList = sortServiceList(currentLocationList, sortingOptions);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                marker.showInfoWindow();
                return false;
            }
        });

        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                Intent intent = new Intent(getActivity(), ViewServices.class);
                OrganizationDescription locObj = findLocationDescriptionObject(marker.getTitle(), organizationDescriptionList);
                intent.putExtra("serviceObject", locObj);
                intent.putExtra("bookmark","true");
                startActivityForResult(intent,2);
                //startActivity(intent);
            }
        });
        CustomListAdapter serviceListAdapter = null;
        if (flagResult==0) {
             serviceListAdapter= new CustomListAdapter(getActivity(), currentLocationList);
            serviceListView = (ListView) bottomsheetview.findViewById(R.id.servicelist);
            serviceListView.setAdapter(serviceListAdapter);
        }
        else {
            if(serviceListAdapter!=null)
                serviceListAdapter.notifyDataSetChanged();
            else {
                serviceListAdapter= new CustomListAdapter(getActivity(), currentLocationList);
                serviceListView = (ListView) bottomsheetview.findViewById(R.id.servicelist);
                serviceListView.setAdapter(serviceListAdapter);
            }
        }
        ArrayList<OrganizationDescription> finalCurrentLocationList = currentLocationList;
        serviceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                finalCurrentLocationList.get(position);
                OrganizationDescription locObj = finalCurrentLocationList.get(position);
                Intent i = new Intent(FragmentBookmark.this.getActivity(), ViewServices.class);
                i.putExtra("serviceObject", locObj);
                i.putExtra("bookmark","true");
                startActivityForResult(i,2);
            }
        });
    }

    @TargetApi(Build.VERSION_CODES.N)
    private ArrayList<OrganizationDescription> sortServiceList(ArrayList<OrganizationDescription> currentLocationList, CategoryList categoryList) {
        String sortBy = null;
        for (int i=0;i<categoryList.getBoxChecked().size();i++)
        {
            if (categoryList.getBoxChecked().get(i)==true) {

                sortBy = categoryList.getOptions().get(i);
                break;
            }
        }

        if (sortBy != null) {
            if (sortBy.equals(getString(R.string.alphanumeric_sortby_service_request))) {
                currentLocationList.sort(Comparator.comparing(OrganizationDescription::getOrganizationName));
            }
            if (sortBy.equals(getString(R.string.distance)))
            {
                currentLocationList.sort(Comparator.comparingDouble(OrganizationDescription::getDistance));
            }
            if(sortBy.equals(getString(R.string.frequentlyUsed)))
            {
                currentLocationList.sort(Comparator.comparing(OrganizationDescription::getOrganizationName));
                currentLocationList= SortClass.sortByFrequentlyUsed(currentLocationList,getActivity());
            }
        }
        return currentLocationList;
    }

    protected synchronized void bulidGoogleApiClient() {
        client = new GoogleApiClient.Builder(this.getActivity()).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
        client.connect();

    }

    @Override
    public void onLocationChanged(Location location) {


        latitude = location.getLatitude();
        longitude = location.getLongitude();
        lastlocation = location;
        LatLng myloc = new LatLng(location.getLatitude(),location.getLongitude());
        mMap.moveCamera(CameraUpdateFactory.newLatLng(myloc));
        if (currentLocationmMarker != null) {

            currentLocationmMarker.remove();

        }

        Gson gson = new Gson();
        String locationString = gson.toJson(lastlocation);
        Context ctx = getActivity();
        SharedPreferences sharedPreferences = ctx.getSharedPreferences("currentlocation", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("currentlocation", locationString);
        editor.commit();
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        this.currentLatLang=latLng;
      /*  MarkerOptions markerOptions = new MarkerOptions();
       // markerOptions.position(latLng);
       // markerOptions.title("Current Location");
        //markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));
        if (currentLocationmMarker==null)
        {
            currentLocationmMarker = mMap.addMarker(markerOptions);
            currentLocationmMarker.showInfoWindow();
        }
        else{
            mMap.addMarker(markerOptions);
        }
        mMap.getUiSettings().setZoomControlsEnabled(true);*/
        // mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        // mMap.animateCamera(CameraUpdateFactory.zoomBy(10));
        if (client != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(client, this);
        }
    }

    private String getUrl(double latitude, double longitude) {

        googlePlaceUrl = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        googlePlaceUrl.append("location=" + latitude + "," + longitude);
        googlePlaceUrl.append("&radius=" + PROXIMITY_RADIUS);
        googlePlaceUrl.append("&sensor=true");
        googlePlaceUrl.append("&key=" + "AIzaSyAIsAfOMWMA1d38hwS_lj_SFjTPN0eRsCY");
        return googlePlaceUrl.toString();
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onConnected(@Nullable Bundle bundle) {

        locationRequest = new LocationRequest();
        locationRequest.setInterval(100);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);


        if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(client, locationRequest, this);
        }
    }


    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this.getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            } else {
                ActivityCompat.requestPermissions(this.getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            }
            return false;

        } else
            return true;
    }


    @Override
    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    public void updateFragment() {
        new GetCourseCategoriesMarkerColor().execute();


        bottomsheetview = view.findViewById(R.id.bottom_sheet);

        bottomSheetBehavior = BottomSheetBehavior.from(bottomsheetview);

       /* listmapBottomButton = (Button) bottomsheetview.findViewById(R.id.listmapviewbutton);

        listmapBottomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bottomSheetBehavior.getState() == bottomSheetBehavior.STATE_EXPANDED) {
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_COLLAPSED);
                } else {
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_EXPANDED);
                }
            }
        });*/

     /*   listmapbutton =  bottomsheetview.findViewById(R.id.listmapButton);
        listmapbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bottomSheetBehavior.getState() == bottomSheetBehavior.STATE_EXPANDED) {
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_COLLAPSED);
                } else {
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_EXPANDED);
                }
            }
        });*/

        maplistbutton = view.findViewById(R.id.maplistButton);
        maplistbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (bottomSheetBehavior.getState() == bottomSheetBehavior.STATE_EXPANDED) {
                    maplistbutton.setImageResource(R.drawable.round_list_white_18);
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_COLLAPSED);
                } else {
                    maplistbutton.setImageResource(R.drawable.maps);

                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_EXPANDED);
                }
            }
        });






        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {


                switch (newState) {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED: {
                     }
                    break;
                    case BottomSheetBehavior.STATE_COLLAPSED: {
                     }
                    break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        bottomSheetBehavior.setState(bottomSheetBehavior.STATE_EXPANDED);
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                //       fab.animate().scaleX(1 - slideOffset).scaleY(1 - slideOffset).setDuration(0).start();
            }
        });

try {
    filter.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            final Dialog filterDialogue = new Dialog(getActivity());
            filterDialogue.setContentView(R.layout.filterlistdialogue);

            resetAllTextView = (TextView) filterDialogue.findViewById(R.id.reset_all);
            filterApplybutton = (Button) filterDialogue.findViewById(R.id.applybutton);
            filtercancelbutton = (Button) filterDialogue.findViewById(R.id.cancelbutton);
            categoryListview = (ExpandableListView) filterDialogue.findViewById(R.id.checkboxlistexpamdable);

            myExpandableListAdapter = new MyExpandableListAdapter(getActivity(), categoryLists1);
//            Log.d("Null:", "Adapter:" + (categoryListview.isShown()) + "  view:" + (categoryListview == null) + " size:" + categoryLists1.get(0).getOptions().size());

            categoryListview.setAdapter(myExpandableListAdapter);
            // categoryListview.addHeaderView(myExpandableListAdapter.getGroupView(0,true,null,null));
      //      Log.d("Null:", "Adapter:" + (categoryListview.isShown()) + "  view:" + (categoryListview == null) + " size:" + categoryLists1.get(0).getOptions().size());


            spinnerSortBy = (Spinner) filterDialogue.findViewById(R.id.spinner_sortby);
            spinnerSortBy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    sortByItem = parent.getItemAtPosition(position).toString();
                    //updateCategorySortList(sortByItem);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            ArrayAdapter sortAdapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, sortingOptions.getOptions());
            sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerSortBy.setAdapter(sortAdapter);
            if (sortByItem != null)
                spinnerSortBy.setSelection(sortingOptions.getOptions().indexOf(sortByItem));

            ArrayList<CategoryList> cancelCategoryAdapterList = myExpandableListAdapter.getCategoryList();

            checkBoxBooleanList = new HashMap<String, Boolean>();
            if (cancelCategoryAdapterList != null) {
                for (int i = 0; i < cancelCategoryAdapterList.size(); i++) {
                    for (int j = 0; j < cancelCategoryAdapterList.get(i).getBoxChecked().size(); j++) {
                        if (!checkBoxBooleanList.containsKey(cancelCategoryAdapterList.get(i).getOptions().get(j))) {
                            checkBoxBooleanList.put(cancelCategoryAdapterList.get(i).getOptions().get(j), cancelCategoryAdapterList.get(i).getBoxChecked().get(j));
                        }
                    }
                }
            }
            if (spinnerSortBy != null)
                selectedSort = spinnerSortBy.getSelectedItemPosition();
            resetAllTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                    if (clTemp != null) {
                        for (int i = 0; i < clTemp.size(); i++) {
                            for (int j = 0; j < clTemp.get(i).getBoxChecked().size(); j++) {
                                myExpandableListAdapter.getCategoryList().get(i).getBoxChecked().set(j, new Boolean(true));
                                ((BaseAdapter) categoryListview.getAdapter()).notifyDataSetChanged();
                            }
                        }
                    }
                    if (spinnerSortBy != null)
                        spinnerSortBy.setSelection(0);
                }
            });

            filtercancelbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                    if (clTemp != null) {
                        for (int i = 0; i < clTemp.size(); i++) {
                            for (int j = 0; j < clTemp.get(i).getBoxChecked().size(); j++) {
                                myExpandableListAdapter.getCategoryList().get(i).getBoxChecked().set(j, checkBoxBooleanList.get(myExpandableListAdapter.getCategoryList().get(i).getOptions().get(j)));
                                ((BaseAdapter) categoryListview.getAdapter()).notifyDataSetChanged();
                            }
                        }
                    }
                    if (selectedSort >= 0) {
                        spinnerSortBy.setSelection(selectedSort);
                    }
                    filterDialogue.dismiss();

                }

            });
            filterApplybutton.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onClick(View v) {

                    ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                    sortingOptions = updateCategorySortList(sortByItem, sortingOptions);
                    updateServiceList(organizationDescriptionList, clTemp, bottomsheetview, sortingOptions, searchText);
                    filterDialogue.dismiss();
                }
            });

            categoryListview.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                @Override
                public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                    CategoryList categoryGroup = categoryLists1.get(groupPosition);
                    String checkboxItem = categoryGroup.getOptions().get(childPosition);
                    return false;
                }
            });

            categoryListview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
                @Override
                public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                    CategoryList categoryGroup = categoryLists1.get(groupPosition);

                    return false;
                }
            });


            filterDialogue.show();
        }
    });
}catch (Exception e){
    Toast.makeText(getContext(), "No bookmarks to filter", Toast.LENGTH_SHORT).show();
    e.printStackTrace();
}




        this.firstTime=false;

    }


    private class GetCourseCategoriesMarkerColor extends AsyncTask<Void, Void, Void> {

        //ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress loading dialog
         /*   progressDialog = new ProgressDialog(getActivity());
            progressDialog.setMessage("Loading...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        */
        }

        @Override
        protected Void doInBackground(Void... voids) {
            File bookmarkFile=new File(url,"bookmark");
            cl1.setCategoryName("Categories");
            ArrayList<String> categories = new ArrayList<String>();
            ArrayList<Boolean> isBoxCheckedList = new ArrayList<Boolean>();


//            if (bookmarkFile.exists())
//            {
//                try {
//                    FileInputStream fileInputStream = new FileInputStream(bookmarkFile);
//                    ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
//                    organizationDescriptionList = (ArrayList<OrganizationDescription>) objectInputStream.readObject();
//                    fileInputStream.close();
//                    objectInputStream.close();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                setMarkerToList(organizationDescriptionList, categories);
//                Collections.sort(categories);
//                for (int i = 0; i < categories.size(); i++) {
//                    isBoxCheckedList.add(new Boolean(true));
//                }
//                cl1.setBoxChecked(isBoxCheckedList);
//                cl1.setOptions(categories);
//                if (categoryLists1.size()>0)
//                    categoryLists1.clear();
//                categoryLists1.add(cl1);
//            }

            if (organizationDescriptionList != null && !organizationDescriptionList.isEmpty()) {
                setMarkerToList(organizationDescriptionList, categories);
                Collections.sort(categories);
                for (int i = 0; i < categories.size(); i++) {
                    isBoxCheckedList.add(Boolean.TRUE);
                }
                cl1.setBoxChecked(isBoxCheckedList);
                cl1.setOptions(categories);
                if (categoryLists1.size()>0)
                    categoryLists1.clear();
                categoryLists1.add(cl1);
            }


            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            try {
                if (serviceAutoListOrganisation!=null )
                {
                    if (organizationAutoTextView==null)
                    {
                        organizationAutoTextView= view.findViewById(R.id.Organization_name_searchview);
                    }
                    ArrayAdapter<String> organizationAutoAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.select_dialog_item, serviceAutoListOrganisation);
                    organizationAutoTextView.setAdapter(organizationAutoAdapter);
                    organizationAutoTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            String selectedItemText = parent.getItemAtPosition(position).toString();
                            OrganizationDescription organizationDescriptionObj =findLocationDescriptionObject(selectedItemText, organizationDescriptionList);
                            if (organizationDescriptionObj !=null)
                            {
                                Intent intent = new Intent(getActivity(), ViewServices.class);
                                intent.putExtra("serviceObject", organizationDescriptionObj);
                                startActivity(intent);
                            }

                        }
                    });
                }
                filter.setEnabled(true);
                updateServiceList(organizationDescriptionList, categoryLists1, bottomsheetview, sortingOptions, searchText);

            } catch (Exception e) {
            }
        }
    }
}