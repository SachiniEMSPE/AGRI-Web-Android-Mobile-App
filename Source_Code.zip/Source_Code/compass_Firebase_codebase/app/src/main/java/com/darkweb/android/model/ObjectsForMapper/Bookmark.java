package com.darkweb.android.model.ObjectsForMapper;

public class Bookmark {
    private int clientId;
    private int organizationId;

    public Bookmark() {
    }

    public Bookmark(int clientId, int organizationId) {
        this.clientId = clientId;
        this.organizationId = organizationId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(int organizationId) {
        this.organizationId = organizationId;
    }
}
