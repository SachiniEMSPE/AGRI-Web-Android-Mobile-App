package com.darkweb.android.model;

import android.content.Context;
//import android.support.annotation.NonNull;

import com.darkweb.android.compass.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import androidx.annotation.*;
/**
 * Created by kotak on 11/07/2018.
 */

public class CalandarEvent implements Serializable,Comparable<CalandarEvent> {

    String eventName;
    UUID eventId;
    Date eventDateTime;
    OrganizationDescription organizationDescription;
    String eventDescription;
    String streetAddress;
    String city;
    String state;
    String zipcode;
    Date eventSubmitDate;
    int requestCode;
    Date remindarDateTime;
    User userObj;
    Map<String,Object> criteriaMap;

    @Override
    public String toString() {
        return "CalandarEvent{" +
                "eventName='" + eventName + '\'' +
                ", eventId=" + eventId +
                ", eventDateTime=" + eventDateTime +
                ", organizationDescription=" + organizationDescription +
                ", eventDescription='" + eventDescription + '\'' +
                ", streetAddress='" + streetAddress + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zipcode='" + zipcode + '\'' +
                ", eventSubmitDate=" + eventSubmitDate +
                ", requestCode=" + requestCode +
                ", remindarDateTime=" + remindarDateTime +
                ", userObj=" + userObj +
                ", criteriaMap=" + criteriaMap +
                '}';
    }

    public Map<String, Object> getCriteriaMap() {
        return criteriaMap;
    }

    public void setCriteriaMap(Map<String, Object> criteriaMap) {
        this.criteriaMap = criteriaMap;
    }

    public OrganizationDescription getOrganizationDescription() {
        return organizationDescription;
    }

    public void setOrganizationDescription(OrganizationDescription organizationDescription) {
        this.organizationDescription = organizationDescription;
    }

    public User getUserObj() {
        return userObj;
    }

    public void setUserObj(User userObj) {
        this.userObj = userObj;
    }

    public Date getRemindarDateTime() {
        return remindarDateTime;
    }

    public void setRemindarDateTime(Date remindarDateTime) {
        this.remindarDateTime = remindarDateTime;
    }

    public int getRequestCode() {
        return requestCode;
    }

    public void setRequestCode(int requestCode) {
        this.requestCode = requestCode;
    }

    public Date getEventSubmitDate() {
        return eventSubmitDate;
    }

    public void setEventSubmitDate(Date eventSubmitDate) {
        this.eventSubmitDate = eventSubmitDate;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public UUID getEventId() {
        return eventId;
    }

    public void setEventId(UUID eventId) {
        this.eventId = eventId;
    }

    public Date getEventDateTime() {
        return eventDateTime;
    }

    public void setEventDateTime(Date eventDateTime) {
        this.eventDateTime = eventDateTime;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public static CalandarEvent getCalendarEventObject(UUID uuid, Context context) {

        String url = context.getFilesDir().toString();
        final File file = new File(url, context.getString(R.string.yourEventListFile));
        ArrayList<CalandarEvent> calendarEventList;
        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                calendarEventList=(ArrayList<CalandarEvent>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (calendarEventList!=null)
                {
                    int i=-1;
                    for (i=0;i<calendarEventList.size();i++)
                    {
                        if (uuid.equals(calendarEventList.get(i).getEventId()))
                        {
                            return calendarEventList.get(i);
                        }
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int compareTo(@NonNull CalandarEvent o) {
        return 0;
    }
}
