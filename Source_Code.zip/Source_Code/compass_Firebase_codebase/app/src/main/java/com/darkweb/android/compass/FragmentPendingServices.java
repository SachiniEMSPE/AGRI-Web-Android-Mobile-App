package com.darkweb.android.compass;

import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.annotation.*;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.darkweb.android.adapter.CustomServiceListAdapter;
import com.darkweb.android.model.ServiceDetails;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;


public class FragmentPendingServices extends Fragment {

    ListView pendingListView;
    ArrayList<ServiceDetails> serviceDetailsList;
    ArrayList<ServiceDetails> completedServices;
    ArrayList<ServiceDetails> cancelledServices;
    ArrayList<ServiceDetails> currentServices;
    String url ;

    private OnFragmentInteractionListener mListener;
    private View view;

    public FragmentPendingServices() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragment_pending_services, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view=view;
        url = getActivity().getFilesDir().toString();

    }

    @Override
    public void onResume() {
        super.onResume();
        File file=new File(url,"serviceDetails");
        File completedServicesFile=new File("completedServices");
        File cancelledServicesFile=new File("cancelledServices");
        //pendingListView=(ListView)view.findViewById(R.id.pending_list_view);
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream ;

        if (file.exists())
        {
            try {
                fileInputStream = new FileInputStream(file);
                objectInputStream = new ObjectInputStream(fileInputStream);
                serviceDetailsList = (ArrayList<ServiceDetails>) objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                Log.d("size:", serviceDetailsList + "");
            } catch (Exception e) {
                    e.printStackTrace();
                }


        }
        if (completedServicesFile.exists())
        {
            try {
                fileInputStream=new FileInputStream(completedServicesFile);
                objectInputStream=new ObjectInputStream(fileInputStream);
                completedServices=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                Log.d("size:",serviceDetailsList+"");

            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        if (cancelledServicesFile.exists()) {
         try {
             fileInputStream = new FileInputStream(cancelledServicesFile);
             objectInputStream = new ObjectInputStream(fileInputStream);
             cancelledServices = (ArrayList<ServiceDetails>) objectInputStream.readObject();
             objectInputStream.close();
             fileInputStream.close();
             Log.d("size:", serviceDetailsList + "");
         }catch (Exception e)
         {
             e.printStackTrace();
         }
        }
            if(serviceDetailsList.size()>0)
            {
                currentServices.addAll(serviceDetailsList);
            }
            if (completedServices.size()>0)
            {
                currentServices.addAll(completedServices);
            }
            if (cancelledServices.size()>0)
            {
                currentServices.addAll(cancelledServices);
            }

            CustomServiceListAdapter serviceListAdapter=new CustomServiceListAdapter(getActivity(),currentServices);

            if(pendingListView==null)
            {
                pendingListView=(ListView)view.findViewById(R.id.pending_list_view);
            }
            pendingListView.setAdapter(serviceListAdapter);
            pendingListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    serviceDetailsList.get(position);
                    ServiceDetails serviceObj=serviceDetailsList.get(position);
                    //String item = serviceDetailsList.get(position).getServiceDescription();//sach changed as below
                    String item = serviceDetailsList.get(position).getComments();
                    Log.e("item",item.toString());
//                Toast.makeText(Fragment1.this.getActivity(), currentLocationList.get(position).getStreetAddress().toString(), Toast.LENGTH_SHORT).show();
/*
                        Intent i = new Intent(FragmentPendingServices.this.getActivity(),ViewServices.class);
                        i.putExtra("serviceObject", serviceObj);
                        i.putExtra("bookmark","true");
                        startActivity(i);*/
                }
            });



    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
