package com.darkweb.android.login;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.darkweb.android.global.MyGlobalVars;
import com.darkweb.android.model.ObjectsForMapper.BackendClient;
import com.darkweb.android.model.User;
import com.darkweb.android.compass.R;
import com.darkweb.android.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONObject;

import java.io.File;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.Response;

public class RegisterActivity extends AppCompatActivity {

    TextInputEditText fname,lname,username,pass,cnfpass,email,phone;
    EditText dob;
    Button register;
    UserService userService;
    private RadioGroup radioSexGroup;
    Calendar myCalendar;
    private String url;
    private File registerFile;
    private ArrayList<User> registerUserList;

    private RadioButton maleRadioButton;
    private RadioButton femaleRadioButton;
    private RadioButton otherRadioButton;
    private int itemId;
    int test=0;

    String result;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userService=new UserService();
        fname = findViewById(R.id.first_name);
        lname = findViewById(R.id.last_name);
        username = findViewById(R.id.user_name);
        pass = findViewById(R.id.password);
        cnfpass = findViewById(R.id.confirm_password);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone_number);
        dob = findViewById(R.id.date_of_birth);
        dob.setInputType(InputType.TYPE_NULL);
        itemId=getIntent().getIntExtra(getString(R.string.itemId),0);
        myCalendar = Calendar.getInstance();

        register = findViewById(R.id.register);
        register.setText("Register");

        final DatePickerDialog.OnDateSetListener date = (view, year, monthOfYear, dayOfMonth) -> {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        };

        dob.setOnClickListener(v -> {
            DatePickerDialog datePickerDialogue= new DatePickerDialog(RegisterActivity.this, date, myCalendar
                    .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                    myCalendar.get(Calendar.DAY_OF_MONTH));
            datePickerDialogue.getDatePicker().setMaxDate(new Date().getTime());
            datePickerDialogue.setCancelable(false);
            datePickerDialogue.show();

        });

        maleRadioButton = (RadioButton) findViewById(R.id.radioMale);
        femaleRadioButton=(RadioButton)findViewById(R.id.radioFemale);
        otherRadioButton = (RadioButton) findViewById(R.id.radioOther);
        maleRadioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                femaleRadioButton.setChecked(false);
                otherRadioButton.setChecked(false);
            }
        });
        femaleRadioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                maleRadioButton.setChecked(false);
                otherRadioButton.setChecked(false);
            }
        });
        otherRadioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                maleRadioButton.setChecked(false);
                femaleRadioButton.setChecked(false);
            }
        });


        register.setOnClickListener(v -> {

            boolean userAdding=true;

            if(pass.getText().toString().isEmpty())
            {   pass.setError("Enter Password");
                userAdding=false;
            }
            if(cnfpass.getText().toString().isEmpty())
            {
                cnfpass.setError("Enter Confirm Password");
                userAdding=false;

            }

            if(!pass.getText().toString().isEmpty() && !cnfpass.getText().toString().isEmpty())
            {
                if(!pass.getText().toString().equals(cnfpass.getText().toString()))
                {
                    pass.setError("Password not Matched");
                    cnfpass.setError("Confirm Password not Matched");
                    userAdding=false;

                }
            }

            if(username.getText().toString().isEmpty())
            {
                username.setError("Enter Username");

            }

            if(email.getText().toString().isEmpty())
            {
                email.setError("Provide an email address");

            }

            else {
                try {
                    User userObj=new User();
                    userObj.setFirstName(fname.getText().toString());
                    userObj.setLastName(lname.getText().toString());
                    userObj.setUserName(username.getText().toString());
                    userObj.setPassword(pass.getText().toString());
                    /*
                    if(!email.getText().toString().isEmpty())
                        userObj.setEmailId(email.getText().toString());
                    if(!phone.getText().toString().isEmpty())
                        userObj.setPhoneNumber(phone.getText().toString());
                     */
                    userObj.setEmailId(email.getText().toString());
                    userObj.setPhoneNumber(phone.getText().toString());

                    if(maleRadioButton.isChecked())
                        userObj.setGender(maleRadioButton.getText().toString());
                    if (femaleRadioButton.isChecked())
                        userObj.setGender(femaleRadioButton.getText().toString());
                    if (otherRadioButton.isChecked())
                        userObj.setGender(otherRadioButton.getText().toString());
                    if(!dob.getText().toString().isEmpty())
//                        userObj.setDateOfBirth(new Date(dob.getText().toString()));
                        userObj.setDateOfBirth(dob.getText().toString());

                    if(userAdding)
                    {
                        /**
                         * Sending request to backend for registering
                         */
                        ObjectMapper objectMapper = new ObjectMapper();
                        String userDataToBackend = objectMapper.writeValueAsString(userObj);
                        System.out.println("json for register: " + userDataToBackend);
                        result = new HttpSignupLogin().execute(userDataToBackend, "signup").get();
                        /**
                         * Assigning returned ID to the registered user
                         */
                        JSONObject serverResult = new JSONObject(result);
                        boolean signedUp = serverResult.getBoolean("success");
                        System.out.println("sach_server results: " + result);

                        if (signedUp) {
                            String userInfoJSON = serverResult.getString("message");
                            ObjectMapper mapper = new ObjectMapper();
                            BackendClient client =
                                    mapper.readValue(userInfoJSON, BackendClient.class);
                            SharedPreferences sp = this.getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sp.edit();
                            editor.putInt("MobileClientID", client.getId());
                            editor.putString("MobileClientName", client.getName());
                            editor.apply();

                            Intent intent=new Intent();
                            intent.putExtra(getString(R.string.userObject), userObj);
                            setResult(2,intent);
                            Toast.makeText(RegisterActivity.this, "Signed up!", Toast.LENGTH_SHORT).show();
                            test=1;
                            finish();
                        }

//                        if(userService.addUserInList(RegisterActivity.this,userObj) && signedUp)
//                        {
//                            userService.signInUser(RegisterActivity.this,userObj,itemId,null);
//                            Intent intent=new Intent();
//                            intent.putExtra(getString(R.string.userObject), userObj);
//                            setResult(2,intent);
//                            Toast.makeText(RegisterActivity.this, "Signing in", Toast.LENGTH_SHORT).show();
//                            test=1;
//                            finish();
//                        }
                    }


                    if(test!=1) {
                        if (result.contains("Username is already taken!") && !(username.getText().toString().isEmpty())){
                            username.setError("That username is taken. Try another");
                        } else if (result.contains("Username is already taken!") && (username.getText().toString().isEmpty())){
                            username.setError("Enter Username");
                        }
                        if (result.contains("Email already in use!")){
                            email.setError("That email is taken. Try another");
                        }
                        //Toast.makeText(RegisterActivity.this, "User Already Exist", Toast.LENGTH_SHORT).show();
                    }

                }
                catch (Exception e)
                {
                    e.printStackTrace();
            }
            }
        });

    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        dob.setText(sdf.format(myCalendar.getTime()));
    }
}
