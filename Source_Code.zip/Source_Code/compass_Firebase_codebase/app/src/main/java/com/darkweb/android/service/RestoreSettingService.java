package com.darkweb.android.service;

import android.content.Context;
import android.util.Log;
import android.widget.TextView;

import com.darkweb.android.dao.RestoreSettingDao;
import com.darkweb.android.dao.UserDao;
import com.darkweb.android.model.User;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class RestoreSettingService {

    Context context;
    UserDao userDao;
    User user;
    RestoreSettingDao restoreSettingDao;

    public RestoreSettingService(Context context){
        this.context=context;
        userDao = new UserDao();
        user=userDao.getUserSignedIn(context);
        restoreSettingDao=new RestoreSettingDao();
    }

    public long addRestoreLength(Long fileSize , long RestoreLongSize, TextView RestoreSize) {


        if(fileSize==null)
            return RestoreLongSize;
        RestoreLongSize+= fileSize.longValue();
        Log.d("add:",RestoreLongSize+"");

        updateRestoreSize(RestoreLongSize,RestoreSize);
        return RestoreLongSize;
    }

    private void updateRestoreSize(long RestoreLongSize,TextView RestoreSize)
    {

        if(RestoreLongSize>= (1024*1024))
        {
            double size=(double) RestoreLongSize/ (1024.0*1024.0);
            RestoreSize.setText(String.format("%.2f", size)+" MB");
        }
        else if(RestoreLongSize>=1024)
        {
            double size=(double) RestoreLongSize/ (1024.0);
            RestoreSize.setText(String.format("%.2f", size)+" KB");
        }
        else if( RestoreLongSize<1024)
        {
            double size=(double) RestoreLongSize;
            RestoreSize.setText(String.format("%.2f", size)+" Bytes");
        }
    }
    public long subtractRestoreLength(Long fileSize,long RestoreLongSize,TextView RestoreSize) {

        if(fileSize==null)
            return RestoreLongSize;
        RestoreLongSize-=fileSize.longValue();
        Log.d("subtra:",RestoreLongSize+"");
        updateRestoreSize(RestoreLongSize,RestoreSize);
        return  RestoreLongSize;
    }


    public void RestoreFiles(ArrayList<File> fileArrayList) {
        restoreSettingDao.RestoreFiles(fileArrayList,user,context);
    }
    public void RestoreFiles(ArrayList<File> fileArrayList,User user1) {
        restoreSettingDao.RestoreFiles(fileArrayList,user1,context);
    }

    public void restoreLoginFile(File userInfoFile, User tempUser, Context context,int itemId, TextView errorTextView) {
        restoreSettingDao.restoreLoginFile(userInfoFile,tempUser,context,itemId,errorTextView);
    }
}
