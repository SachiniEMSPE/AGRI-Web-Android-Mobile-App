package com.darkweb.android.agri;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.darkweb.android.compass.R;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;

public class Fragment_F1 extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener, DatePickerDialog.OnDateSetListener {


    Spinner f1_sp_edu, f1_sp_member, f1_sp_credit,f1_sp_register;
    String [] ans_f1_sp_edu, ans_f1_sp_member, ans_f1_sp_credit, ans_f1_sp_register;
    TextInputLayout  f1_tLayout_FBO,f1_tLayout_receive,f1_tLayout_tax;
    EditText f1_FBO;
    Button f1_bday_btn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d("Fragment ","2");
        View f1View = inflater.inflate(R.layout.ag_fragment_f1, container, false); //tab_fragment_2
        f1_sp_edu  = f1View.findViewById(R.id.f1_sp_edu);
        f1_sp_member  = f1View.findViewById(R.id.f1_sp_member);
        f1_sp_credit = f1View.findViewById(R.id.f1_sp_credit);
        f1_sp_register = f1View.findViewById(R.id.f1_sp_register);
        //f1_sp_edu.setPrompt("Select");

        f1_bday_btn = f1View.findViewById(R.id.f1_bday_btn);

        f1_tLayout_FBO = f1View.findViewById(R.id.f1_tLayout_FBO);
        f1_tLayout_receive =f1View.findViewById(R.id.f1_tLayout_receive);
        f1_tLayout_tax  =   f1View.findViewById(R.id.f1_tLayout_tax);
        //f1_FBO = f1View.findViewById(R.id.f1_FBO);
        f1Spedu();
        f1Spmember();
        f1Spcredit();
        f1Spregister();
        f1_sp_edu.setOnItemSelectedListener(this);
        f1_sp_member.setOnItemSelectedListener(this);
        f1_sp_credit.setOnItemSelectedListener(this);
        f1_sp_register.setOnItemSelectedListener(this);

        f1_bday_btn.setOnClickListener(this);

        return f1View;
    }

    private void f1Spedu() {
        ans_f1_sp_edu = new String[]{
                "Primary","Senior High","Tertiary","Other",
        };
        ArrayAdapter<String> eduAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f1_sp_edu);
        eduAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f1_sp_edu.setAdapter(eduAdapter);
    }

    private void f1Spmember() {
        ans_f1_sp_member = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f1_sp_member);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f1_sp_member.setAdapter(memAdapter);
    }

    private void f1Spcredit() {
        ans_f1_sp_credit = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f1_sp_credit);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f1_sp_credit.setAdapter(memAdapter);
    }

    private void f1Spregister() {
        ans_f1_sp_register = new String[]{
                 "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f1_sp_register);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f1_sp_register.setAdapter(memAdapter);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

   }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId() == R.id.f1_sp_edu){
            String selected = parent.getSelectedItem().toString();
            //Toast.makeText(getActivity(),"Selected " + selected, Toast.LENGTH_SHORT).show();
           /* if(selected == "Select"){
                Toast.makeText(getActivity()," Please select an answer!", Toast.LENGTH_SHORT).show();
            }*/
        } else if (parent.getId() == R.id.f1_sp_member){
            String selected = parent.getSelectedItem().toString();
    /*        if(selected == "Select"){
                Toast.makeText(getActivity()," Please select an answer!", Toast.LENGTH_SHORT).show();
            }*/
            if (selected == "Yes"){
                //f1_FBO.setVisibility(View.VISIBLE);
                f1_tLayout_FBO.setVisibility(View.VISIBLE);
            } else{
                //f1_FBO.setVisibility(View.GONE);
                f1_tLayout_FBO.setVisibility(View.GONE);
            }
            //Toast.makeText(getActivity(),"Selected " + selected, Toast.LENGTH_SHORT).show();
        } else if (parent.getId() == R.id.f1_sp_credit) {
            String selected = parent.getSelectedItem().toString();
          /*  if(selected == "Select"){
                Toast.makeText(getActivity()," Please select an answer!", Toast.LENGTH_SHORT).show();
            }*/
            if (selected == "Yes") {
                f1_tLayout_receive.setVisibility(View.VISIBLE);
            } else {
                f1_tLayout_receive.setVisibility(View.GONE);
            }
        }else if (parent.getId() == R.id.f1_sp_register) {
            String selected = parent.getSelectedItem().toString();
            /*if(selected == "Select"){
                Toast.makeText(getActivity()," Please select an answer!", Toast.LENGTH_SHORT).show();
            }*/
            if (selected == "Yes") {
                f1_tLayout_tax.setVisibility(View.VISIBLE);
            } else {
                f1_tLayout_tax.setVisibility(View.GONE);
            }
        }
        else{
            Toast.makeText(getActivity(),"Other", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        showDatePickerDialog();
    }

    private void showDatePickerDialog(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                getActivity(), this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        );
        datePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String date = dayOfMonth +"/"+month+"/"+year;
        f1_bday_btn.setText(date);
    }
}
