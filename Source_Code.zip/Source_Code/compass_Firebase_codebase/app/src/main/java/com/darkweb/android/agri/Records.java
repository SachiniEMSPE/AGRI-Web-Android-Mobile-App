package com.darkweb.android.agri;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.darkweb.android.compass.R;
import com.darkweb.android.login.LoginActivity;
import com.darkweb.android.model.User;
import com.darkweb.android.service.UserService;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Records.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Records#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Records extends Fragment {
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    UserService userService;
    private OnFragmentInteractionListener mListener;
    private ListView settingListView;
    int newSelectedIntent=-1;

    public Records() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SettingFragment.
     */
    public static Records newInstance(String param1, String param2) {
        Records fragment = new Records();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.ag_records, container, false);//fragment_setting
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    /* sach commented temporarily
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        userService = new UserService();
        settingListView=(ListView) view.findViewById(R.id.setting_listview);
        ArrayList<String> settingArrayList=new ArrayList<String>();
        settingArrayList.add(getString(R.string.backup_setting));
        settingArrayList.add(getString(R.string.restore_setting));
       // settingArrayList.add(getString(R.string.incremental_backup));
        ArrayAdapter<String> settingArrayAdapter = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_list_item_1,
                settingArrayList );
        settingListView.setAdapter(settingArrayAdapter);
        settingListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String settingString=settingArrayList.get(position);
                if(settingString.equals(getString(R.string.backup_setting)))
                {
                    User user=userService.getUserSignedIn(getActivity());
                    newSelectedIntent=0;
                    if(user==null)
                    {
                        goToLoginIntent();
                    }
                    else
                        goToSelectedActivity(newSelectedIntent);

                }
                else  if(settingString.equals(getString(R.string.restore_setting)))
                {
                    User user=userService.getUserSignedIn(getActivity());
                    newSelectedIntent=1;
                    if(user==null)
                    {
                        goToLoginIntent();
                    }
                    else
                        goToSelectedActivity(newSelectedIntent);

                }
//                else if(settingString.equals(getString(R.string.incremental_backup)))
//                {
//
//                }
            }
        });
    }

     */

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1)
        {
            Log.d("activity frag:",""+requestCode+" setting");
            User user=userService.getUserSignedIn(getActivity());
            if(user!=null)
            {
                goToSelectedActivity(newSelectedIntent);
            }
        }
    }

    private void goToSelectedActivity(int newSelectedIntent) {
        /**
         * TODO: There is nothing to do with backup
         */
//        Intent i=null;
//        switch (newSelectedIntent){
//            case 0:
//                 i= new Intent(getActivity(), BackupSettingActivity.class);
//                break;
//            case 1:
//                i = new Intent(getActivity(), RestoreSettingActivity.class);
//                break;
//            case 2:
//                i = new Intent(getActivity(), RestoreSettingActivity.class);
//                break;
//        }
//        if(i!=null)
//        {
//            startActivity(i);// Activity is started with requestCode 2
//        }
    }

    public void goToLoginIntent()
    {
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("selectedIntent:",newSelectedIntent+"");
    }
}
