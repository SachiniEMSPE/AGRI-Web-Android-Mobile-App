package com.darkweb.android.model;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import android.view.View;

import androidx.annotation.NonNull;

/**
 * Created by kotak on 20/08/2018.
 */

public class MyBottomSheetCallback extends BottomSheetBehavior {

    public void onStateChanged(@NonNull View bottomSheet, int newState) {
        if (newState == BottomSheetBehavior.STATE_EXPANDED) {

        }
    }


    public void onSlide(@NonNull View bottomSheet, float slideOffset) {

    }
}
