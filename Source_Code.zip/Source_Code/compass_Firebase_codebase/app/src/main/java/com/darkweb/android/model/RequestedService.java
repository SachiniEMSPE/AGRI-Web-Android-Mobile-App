package com.darkweb.android.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RequestedService {

    @JsonProperty("RequestedServiceId")
    private int requestedServiceId;
    @JsonProperty("OrganizationName")
    private String organizationName;
    @JsonProperty("LastUpdatedDate")
    private String lastUpdatedDate;
    @JsonProperty("RequestedComment")
    private String requestedComment;
    @JsonProperty("Status")
    private String status;

    public RequestedService() {
    }

    public RequestedService(String organizationName, String lastUpdatedDate, String requestedComment, String status) {
        this.organizationName = organizationName;
        this.lastUpdatedDate = lastUpdatedDate;
        this.requestedComment = requestedComment;
        this.status = status;
    }

    public RequestedService(int requestedServiceId, String organizationName, String lastUpdatedDate, String requestedComment, String status) {
        this.requestedServiceId = requestedServiceId;
        this.organizationName = organizationName;
        this.lastUpdatedDate = lastUpdatedDate;
        this.requestedComment = requestedComment;
        this.status = status;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getRequestedComment() {
        return requestedComment;
    }

    public void setRequestedComment(String requestedComment) {
        this.requestedComment = requestedComment;
    }

    public int getRequestedServiceId() {
        return requestedServiceId;
    }

    public void setRequestedServiceId(int requestedServiceId) {
        this.requestedServiceId = requestedServiceId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
