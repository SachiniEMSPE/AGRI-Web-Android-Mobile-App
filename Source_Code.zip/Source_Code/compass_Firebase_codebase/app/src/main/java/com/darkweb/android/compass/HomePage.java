package com.darkweb.android.compass;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;


import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.darkweb.android.activities.HistoryMessagesActivity;
import com.darkweb.android.activities.RealtimeChatActivity;
import com.darkweb.android.activities.RequestedServicesActivity;
import com.darkweb.android.adapter.PagerAdapterNav;
import com.darkweb.android.global.MyGlobalVars;
import com.darkweb.android.login.LoginActivity;
import com.darkweb.android.model.User;
import com.darkweb.android.service.HttpHandlers.MobileClientProfileHandler;
import com.darkweb.android.service.UserService;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

public class HomePage extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    Toolbar toolbar;
    TextView userNameFl,userName,signIn;
    ImageView imageView;
    private User user;
    Fragment fragment = null;
    Fragment tempFragment=null;
    Integer tempFragmentPosition=0;
    NavigationView navigationView;
    FragmentHome fragmentHome=null;
    private FragmentTransaction ft;
    private ViewPager viewPager;
    private PagerAdapterNav adapter;
    private LinearLayout userProfileLinearLayout;
    UserService userService;
    protected DrawerLayout drawer;
    public static boolean start=true;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    //sach- activities when app creates will be here.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        toolbar= (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        userService = new UserService();

        viewPager = (ViewPager) findViewById(R.id.viewpagerhome);

        adapter = new PagerAdapterNav(HomePage.this.getSupportFragmentManager(), 3,this,toolbar);
        viewPager.setAdapter(adapter);

        viewPager.setOffscreenPageLimit(3);
        viewPager.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (viewPager.getCurrentItem() == tempFragmentPosition) {
                    viewPager.setCurrentItem(tempFragmentPosition-1, false);
                    viewPager.setCurrentItem(tempFragmentPosition, false);
                    //Log.d("Fragment position"," Value In if loop:"+tempFragmentPosition);
                    return  true;
                }
                //Log.d("Fragment position"," Value In if loop:"+tempFragmentPosition);
                return false;

            }
        });


        if(start) {
            userService.signOutUser(HomePage.this);

            user = null;
            if (tempFragmentPosition == 1 || tempFragmentPosition == 2 || tempFragmentPosition == 5 || tempFragmentPosition == 6 || tempFragmentPosition == 7 || tempFragmentPosition == 0) {
                viewPager.setCurrentItem(0);
                tempFragmentPosition = 0;
                toolbar.setTitle("Home");
                Intent i = new Intent(HomePage.this, EmptyActivity.class);
                startActivity(i);
            }
            start=false;
        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        View headerView=navigationView.getHeaderView(0);
        //userNameFl=(TextView)headerView.findViewById(R.id.user_name_fl);
        //userName=(TextView)headerView.findViewById(R.id.user_name);
        userProfileLinearLayout=(LinearLayout) headerView.findViewById(R.id.user_profile_lenear_layout); //sach-this is to SignIn function

        SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);

        //sach [signIn]- temporarily commented for AGRI web app. Remember to uncomment all signIn lines to add signIn option in the AGRI web app.
//        userProfileLinearLayout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                try {
//                    InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
//                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
//                } catch (Exception e) {
//                }
//
//                if(local_user_id == 0) {
//                    Intent intent = new Intent(HomePage.this, LoginActivity.class);
//                    startActivityForResult(intent, 1);
//                    tempFragmentPosition=6;
//                }
//                else {
//                    toolbar.setTitle("My Profile");
//                    viewPager.setCurrentItem(6);
//                    tempFragmentPosition=6;
//                }
//
//                drawer.closeDrawer(GravityCompat.START);
//            }
//        });

        //sach- define variables
        //sach [signIn]- temporarily commented for AGRI web app. Remember to uncomment all signIn lines to add signIn option in the AGRI web app.
        ///signIn=(TextView)headerView.findViewById(R.id.sign_in);
        //imageView=(ImageView)headerView.findViewById(R.id.user_image);
        navigationView.getMenu().getItem(0).setChecked(true);
        navigationView.setNavigationItemSelectedListener(this);
        displaySelectedScreen(R.id.home_page);
        //sach [signIn]- temporarily commented for AGRI web app. Remember to uncomment all signIn lines to add signIn option in the AGRI web app.
/*        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomePage.this.getApplicationContext(),LoginActivity.class);
                startActivityForResult(intent, 2);// Activity is started with requestCode 2
            }
        });*/
    }
    //sach [signIn]- temporarily commented for AGRI web app. Remember to uncomment all signIn lines to add signIn option in the AGRI web app.
//    @Override
//    protected void onResume() {
//        super.onResume();
//        try {
//            InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
//            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
//        } catch (Exception e) {
//        }
//
//        user=userService.getUserSignedIn(HomePage.this);
//        SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
//        int local_user_id = sp.getInt("MobileClientID", 0);
//
//        if(local_user_id != 0) {
//            String userFullName = "";
//            String email = "";
//            try {
//                String user_profile_json =
//                        new MobileClientProfileHandler()
//                                .execute(Integer.toString(local_user_id)).get();
//                JSONObject userProfile = new JSONObject(user_profile_json);
//                userFullName = userProfile.getString("name");
//                email = userProfile.getString("email");
//            } catch (ExecutionException | InterruptedException | JSONException e) {
//                e.printStackTrace();
//            }
//
//            showItem(R.id.signout);
//            //showItem(R.id.profile); sach temporarily disabled
//            //showItem(R.id.history_messages);
//            ////signIn.setVisibility(View.GONE);
//            imageView.setVisibility(View.VISIBLE);
//            userNameFl.setVisibility(View.VISIBLE);
//            userName.setVisibility(View.VISIBLE);
//            userNameFl.setText(userFullName);
//            userName.setText(email);
//        }
//        else {
//            hideItem(R.id.signout);
//            //hideItem(R.id.profile); sach temporarily disabled
//            //hideItem(R.id.history_messages);
//            imageView.setVisibility(View.GONE);
//            userNameFl.setVisibility(View.GONE);
//            userName.setVisibility(View.GONE);
//            ///signIn.setVisibility(View.VISIBLE);
//        }
//
//
//    }

    //sach [signIn]- temporarily commented for AGRI web app. Remember to uncomment all signIn lines to add signIn option in the AGRI web app.
//    @RequiresApi(api = Build.VERSION_CODES.N)
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data)
//    {
//        super.onActivityResult(requestCode, resultCode, data);
//        try {
//            InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
//            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
//        } catch (Exception e) {
//        }
//        Log.d("req:",requestCode+"");
//        if(requestCode==2)
//        {
//            user=userService.getUserSignedIn(HomePage.this);
//            if(user!=null)
//            {
//                showItem(R.id.signout);
//                ////signIn.setVisibility(View.GONE);
//                imageView.setVisibility(View.VISIBLE);
//                userNameFl.setVisibility(View.VISIBLE);
//                userName.setVisibility(View.VISIBLE);
//                userNameFl.setText(user.getFirstName()+" "+user.getLastName());
//                userName.setText(user.getUserName());
//            }
//            else
//            {
//                hideItem(R.id.signout);
//                imageView.setVisibility(View.GONE);
//                userNameFl.setVisibility(View.GONE);
//                userName.setVisibility(View.GONE);
//                ////signIn.setVisibility(View.VISIBLE);
//            }
//        }
//        if(requestCode==1)
//        {
//            user=userService.getUserSignedIn(HomePage.this);
//            if(user!=null)
//            {
//                showItem(R.id.signout);
//                ////.setVisibility(View.GONE);
//                imageView.setVisibility(View.VISIBLE);
//                userNameFl.setVisibility(View.VISIBLE);
//                userName.setVisibility(View.VISIBLE);
//                userNameFl.setText(user.getFirstName()+" "+user.getLastName());
//                userName.setText(user.getUserName());
//                viewPager.setCurrentItem(tempFragmentPosition);
//
//                //fragment=tempFragment;
//            }
//            else
//            {
//                toolbar.setTitle("Home");
//                Log.d("fragmentHOme:","yes");
//                viewPager.setCurrentItem(0);
//
//                //fragment=new FragmentHome();
//                hideItem(R.id.signout);
//                navigationView.getMenu().getItem(0).setChecked(true);
//                displaySelectedScreen(R.id.home_page);
//                imageView.setVisibility(View.GONE);
//                userNameFl.setVisibility(View.GONE);
//                userName.setVisibility(View.GONE);
//                ////signIn.setVisibility(View.VISIBLE);
//            }
//            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//            drawer.closeDrawer(GravityCompat.START);
//        }
//        else {
//
//        }
//    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        else if(toolbar.getTitle().equals("Home")||toolbar.getTitle().equals("COMPASS")) {
            AlertDialog.Builder alertDialog=new AlertDialog.Builder(HomePage.this);
            // Setting Dialog Title
            alertDialog.setTitle("Exit Application");
            // Setting Dialog Message
            alertDialog.setMessage("Do you want to exit application ? ");
            alertDialog.setCancelable(false);
            // Setting alert dialog icon
            alertDialog.setIcon(R.drawable.ic_exit_to_app_black_24dp);
            alertDialog.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.N)
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    userService.signOutUser(HomePage.this);
                    user=null;
                    ////signIn.setVisibility(View.VISIBLE);
                    ////imageView.setVisibility(View.GONE);
                    ////userNameFl.setVisibility(View.GONE);
                    userName.setVisibility(View.GONE);
                    hideItem(R.id.signout);
                    if(tempFragmentPosition==1 || tempFragmentPosition==2 || tempFragmentPosition==5 || tempFragmentPosition==6 ||tempFragmentPosition==7  || tempFragmentPosition==0)
                    {
                        viewPager.setCurrentItem(0);
                        tempFragmentPosition=0;
                        toolbar.setTitle("Home");
                        Intent i = new Intent(HomePage.this,EmptyActivity.class);
                        startActivity(i);
                    }

                    HomePage.this.moveTaskToBack(true);
                    android.os.Process.killProcess(android.os.Process.myPid());
                    System.exit(1);
                }
            });
            // Setting OK Button
            alertDialog.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            alertDialog.show();

        }else {
            toolbar.setTitle("Home");
            Log.d("fragmentHOme:","yes");
            viewPager.setCurrentItem(0);
            tempFragmentPosition=0;

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_page, menu);
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressWarnings("StatementWithEmptyBody")
    @Override

    //sach- drawer Navigation item
    public boolean onNavigationItemSelected(MenuItem item) {
        displaySelectedScreen(item.getItemId());
        return true;
    }
    // sach - HOME page > drawer > access drawer item and this directs to relevent intents HOME / VOLUNTEER / SERVICES / PROFILE/ SETTINGS/SIGNOUT
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void displaySelectedScreen(int itemId) {
        try {
            InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {
        }
        switch (itemId) {
            //sach-HOME
            case R.id.home_page:
                toolbar.setTitle("Home");
                Log.d("sach_fragmentHOme:", "yes");
                viewPager.setCurrentItem(0);
                tempFragmentPosition = 0;
                break;
             //sach-VOLUNTEER
            /* sach temporarily disabled
            case R.id.volunteer_oppurtunity:
               {
                if (user == null) {
                    Intent intent = new Intent(HomePage.this, LoginActivity.class);
                    //Log.d("Sach_Directed_to_LogIn","Yes");
                    startActivityForResult(intent, 1);
                    tempFragmentPosition = 2;
                    //Log.d("sach_Volunteer:","yes");
                } else {
                 //   Intent intent = new Intent(HomePage.this, Volunteering.class);
                 //   startActivity(intent);
                    viewPager.setCurrentItem(2);
                    tempFragmentPosition = 2;
                    //Log.d("sach_VolunteerElse:","yes");
                }
                   toolbar.setTitle("Volunteer");
                break;
            }
            */
            //sach-SERVICES
            case R.id.newsfeed_services:
            {
            /*    SharedPreferences sp = this.getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
                int local_user_id = sp.getInt("MobileClientID", 0);

                if (local_user_id == 0) {
                    Intent intent = new Intent(HomePage.this, LoginActivity.class);
                    startActivityForResult(intent, 1);
                } else {
                    viewPager.setCurrentItem(1);
                }
                // Doesn't matter logged in or not, set tempFragmentPosition to 1
                tempFragmentPosition = 1;
                toolbar.setTitle("Records");*/

                viewPager.setCurrentItem(1);
                tempFragmentPosition = 1;
                toolbar.setTitle("Records");

                break;
            }
            //sach-SETTING
            case R.id.setting:
                /*
                if (user==null)
                {
                    Intent intent = new Intent(HomePage.this, LoginActivity.class);
                    startActivityForResult(intent, 1);
                    tempFragmentPosition=7;
                }
                else
                {
                    viewPager.setCurrentItem(7);
                    tempFragmentPosition=7;
                }
                toolbar.setTitle("Settings");
                */
                viewPager.setCurrentItem(3);
                tempFragmentPosition=3;
                toolbar.setTitle("Learn More");

                break;
/*            case R.id.volunteer_my_service:
                if(user==null)
                {
                    Intent intent = new Intent(HomePage.this, LoginActivity.class);
                    startActivityForResult(intent, 1);
                    tempFragmentPosition=2;
                }
                else
                {
                    viewPager.setCurrentItem(2);
                    tempFragmentPosition=2;
                }
                toolbar.setTitle(getString(R.string.My_Volunteer_services));
                break;
       //sach [signIn]- temporarily commented for AGRI web app. Remember to uncomment all signIn lines to add signIn option in the AGRI web app.
*/     //sach-SIGNOUT
//            case R.id.signout:
//                userService.signOutUser(HomePage.this);
//                user=null;
//                /////signIn.setVisibility(View.VISIBLE);
//                imageView.setVisibility(View.GONE);
//                userNameFl.setVisibility(View.GONE);
//                userName.setVisibility(View.GONE);
//                hideItem(R.id.signout);
//                //sach-set position to default home page layout
//                if(tempFragmentPosition==1 || tempFragmentPosition==2 || tempFragmentPosition==5 || tempFragmentPosition==6 ||tempFragmentPosition==7  || tempFragmentPosition==0)
//                {
//                    viewPager.setCurrentItem(0);
//                    tempFragmentPosition=0;
//                    toolbar.setTitle("Home");
//                    Intent i = new Intent(HomePage.this,EmptyActivity.class);
//                    startActivity(i);
//                }
//                break;
        }
        //sach-close drawer after any touch
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    private void hideItem(int id)
    {
        Menu nav_Menu = navigationView.getMenu();
        nav_Menu.findItem(id).setVisible(false);

    }
    private void showItem(int id)
    {
        Menu nav_Menu = navigationView.getMenu();
        nav_Menu.findItem(id).setVisible(true);
    }
}


