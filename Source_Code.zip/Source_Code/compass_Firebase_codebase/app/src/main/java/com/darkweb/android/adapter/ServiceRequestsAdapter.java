package com.darkweb.android.adapter;

import android.app.Activity;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.RequestedService;

import java.util.ArrayList;
import java.util.List;

public class ServiceRequestsAdapter extends ArrayAdapter<RequestedService> {

    private final Activity context;
    private final List<RequestedService> requestsList;
    private List<RequestedService> tempList;

    public ServiceRequestsAdapter(Activity context, List<RequestedService> requestsList) {
        super(context, R.layout.servicelistview, requestsList);
        this.context = context;
        this.requestsList = requestsList;
        this.tempList = new ArrayList<>();
        this.tempList.addAll(requestsList);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        RequestedService requestedService = requestsList.get(position);
        LayoutInflater inflater=context.getLayoutInflater();
        View view = inflater.inflate(R.layout.custom_service_list_adapter_view, null,true);
        // binding views
        TextView organizationName = view.findViewById(R.id.servicename_textview);
        TextView comment = view.findViewById(R.id.service_description_textView);
        ImageView statusIcon = view.findViewById(R.id.service_image_icon);
        TextView lastUpdated = view.findViewById(R.id.last_updateddate);

        // mapping data to views
        organizationName.setText(requestedService.getOrganizationName());
        organizationName.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
        comment.setText(requestedService.getRequestedComment());
        lastUpdated.setText(requestedService.getLastUpdatedDate());
        statusIcon.setImageDrawable(context.getResources().getDrawable(R.drawable.progress_led_icron));
        return view;
    }
}
