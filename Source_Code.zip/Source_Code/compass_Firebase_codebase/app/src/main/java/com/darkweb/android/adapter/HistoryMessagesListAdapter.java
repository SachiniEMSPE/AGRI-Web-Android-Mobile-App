package com.darkweb.android.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.MessageMapper.HistoryMessage;

import java.util.List;

public class HistoryMessagesListAdapter extends ArrayAdapter<HistoryMessage> {
    private Context mContext;
    private int mResource;

    public HistoryMessagesListAdapter(@NonNull Context context, int resource, List<HistoryMessage> messages) {
        super(context, resource, messages);
        this.mContext = context;
        this.mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String organizationName = getItem(position).getOrganizationName();
        String lastUpdate = getItem(position).getLastUpdate();
        String lastMessage = getItem(position).getLastMessage();

        HistoryMessage message = new HistoryMessage();
        message.setOrganizationName(organizationName);
        message.setLastMessage(lastMessage);
        message.setLastUpdate(lastUpdate);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView tvName = convertView.findViewById(R.id.history_message_organization_name);
        TextView tvUpdateTime = convertView.findViewById(R.id.history_message_last_update);
        TextView tvLastMessage = convertView.findViewById(R.id.history_message_lastMessage);

        tvName.setText(organizationName);
        tvUpdateTime.setText(lastUpdate);
        tvLastMessage.setText(lastMessage);

        return convertView;
    }
}
