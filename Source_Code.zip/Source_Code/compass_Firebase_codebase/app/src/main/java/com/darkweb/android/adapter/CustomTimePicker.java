package com.darkweb.android.adapter;

import android.app.TimePickerDialog;
import android.content.Context;
import android.util.Log;
import android.widget.TimePicker;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by kotak on 04/09/2018.
 */

public class CustomTimePicker extends TimePickerDialog {

    private static int minHour = -1;
    private static int minMinute = -1;

    private static int maxHour = 25;
    private static int maxMinute = 25;

    private static int currentHour = 0;
    private static int currentMinute = 0;


    private Calendar calendar = Calendar.getInstance();
    private DateFormat dateFormat;


    public CustomTimePicker(Context context, OnTimeSetListener callBack, int hourOfDay, int minute, boolean is24HourView) {
        super(context, callBack, hourOfDay, minute, is24HourView);
        currentHour = hourOfDay;
        currentMinute = minute;
        dateFormat = DateFormat.getTimeInstance(DateFormat.SHORT);

        try {
            Class<?> superclass = getClass().getSuperclass();
            Field mTimePickerField = superclass.getDeclaredField("mTimePicker");
            mTimePickerField.setAccessible(true);
            TimePicker mTimePicker = (TimePicker) mTimePickerField.get(this);
            mTimePicker.setOnTimeChangedListener(this);
            updateTime(currentHour, currentMinute);
        } catch (Exception e) {
        }
    }

    public void setMindateTime(Date minDate) {
        if( minDate==null)
            return;
        minHour=minDate.getHours();
        minMinute=minDate.getMinutes();
    }

    public void setMaxdateTime(Date maxDate) {
        if(maxDate==null)
            return;

        maxHour=maxDate.getHours();
        maxMinute=maxDate.getMinutes();
        Log.d("max"," hour:"+maxHour+" min:"+maxMinute);
    }

    public void setCurrentTime(Date currentTime)
    {
        if(currentTime==null)
            currentTime=new Date();
        currentHour=currentTime.getHours();
        currentMinute=currentTime.getMinutes();
    }


    @Override
    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {

        Log.d("minhour",minHour+" "+minMinute);
        boolean validTime = true;
        if (hourOfDay < minHour || (hourOfDay == minHour && minute < minMinute)){
            validTime = false;
        }

        if (hourOfDay  > maxHour || (hourOfDay == maxHour && minute > maxMinute)){
            validTime = false;
        }
        Log.d("minhour",minHour+" "+minMinute+" "+validTime);
        if (validTime) {
            currentHour = hourOfDay;
            currentMinute = minute;
        }
        else
        {
            setCurrentTime(new Date());
        }

        updateTime(currentHour, currentMinute);
        updateDialogTitle(view, currentHour, currentMinute);
    }

    private void updateDialogTitle(TimePicker timePicker, int hourOfDay, int minute) {
        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
        calendar.set(Calendar.MINUTE, minute);
        String title = dateFormat.format(calendar.getTime());
        setTitle(title);
    }
}



