package com.darkweb.android.dao;


import android.content.Context;


import android.util.Log;
import android.widget.TextView;


import com.darkweb.android.model.User;
import com.darkweb.android.service.CryptoUtilServices;


import java.io.File;
import java.util.ArrayList;

public class RestoreSettingDao {
    public Long fileSize = new Long(0);


    public void RestoreFiles(ArrayList<File> fileArrayList, User user, Context context) {

        if(user.getUserUID()==null)
            return;;
        CryptoUtilServices cryptoUtilServices = new CryptoUtilServices();
        String key=user.getUserUID();

        for( File f :fileArrayList)
        {
            String url = context.getFilesDir().toString();
            File encryptedFile = new File(url,f.getName()+".enc");

        }
    }


    public void restoreLoginFile(File userInfoFile, User tempUser, Context context,int itemId, TextView errorTextView) {

        if(tempUser.getUserUID()==null)
            return;;
        CryptoUtilServices cryptoUtilServices = new CryptoUtilServices();
        String key=tempUser.getUserUID();
        String url = context.getFilesDir().toString();
        File encryptedFile = new File(url,userInfoFile.getName()+".enc");

        Log.d("temp:",tempUser.getUserUID()+" filename:"+userInfoFile.getName());
    }
}
