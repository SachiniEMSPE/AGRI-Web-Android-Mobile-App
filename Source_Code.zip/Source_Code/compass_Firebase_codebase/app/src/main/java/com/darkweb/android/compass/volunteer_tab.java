package com.darkweb.android.compass;

import com.darkweb.android.adapter.Page_adapter_volunteer;
import com.darkweb.android.model.User;
import com.darkweb.android.service.UserService;
import com.google.android.material.tabs.TabLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class volunteer_tab extends Fragment {
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private User user;
    private View view;
    UserService userService;

    private FragmentCalendarView fragmentCalendarView;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_volunteer_tab,container,false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        TabLayout tabLayout = (TabLayout) view.findViewById(R.id.tabs_vol);
        tabLayout.addTab(tabLayout.newTab().setText("OPPORTUNITIES"));
        tabLayout.addTab(tabLayout.newTab().setText("HISTORY"));
        viewPager = (ViewPager)view.findViewById(R.id.viewpager_vol);
        final Page_adapter_volunteer adapter = new Page_adapter_volunteer
                (getChildFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        viewPager.setCurrentItem(0);
        viewPager.setOffscreenPageLimit(2);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                switch (tab.getPosition()){
                    case 2:
                        Log.d("Position of service tab", ""+tab.getPosition());
                        viewPager.setCurrentItem(1);

                    default:
                        Log.d("Position of service tab", ""+tab.getPosition());
                        viewPager.setCurrentItem(tab.getPosition());

                       }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });




    }

                    //return new Fragment3();

}

