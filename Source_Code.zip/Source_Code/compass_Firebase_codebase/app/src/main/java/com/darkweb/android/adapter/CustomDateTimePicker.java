package com.darkweb.android.adapter;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by kotak on 28/08/2018.
 */

public class CustomDateTimePicker {

    private static int currentHour = 0;
    private static int currentMinute = 0;

    private static TimePicker timePickerView;
    private static Calendar calendar = Calendar.getInstance();
    public static DatePickerDialog.OnDateSetListener getCustomDatePicker( EditText eventDateEditText,Date expectingDateandTime,Calendar myCalendar) {

        return  new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                view.setMinDate(new Date().getTime());
                if(expectingDateandTime!=null)
                view.setMaxDate(expectingDateandTime.getTime());
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(eventDateEditText,myCalendar);
            }

        };
    }


    public static TimePickerDialog getCustomTimePickerDialogue(Context context, EditText addServiceTimeEditText,Date currentdate, Date minDate, Date maxDate)
    {

        TimePickerDialog.OnTimeSetListener mTimePickerListener = new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                Calendar datetime = Calendar.getInstance();
                Calendar c = Calendar.getInstance();
                datetime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                datetime.set(Calendar.MINUTE, minute);

                if(datetime.getTimeInMillis() >= c.getTimeInMillis()) {
                    addServiceTimeEditText.setText(hourOfDay + ":" + minute);

                }else {
                    Toast.makeText(context, "Invalid time", Toast.LENGTH_SHORT).show();
                }
            }
        };

        setCurrentTime(currentdate);
        CustomTimePicker dialog = new CustomTimePicker(context,mTimePickerListener, currentHour, currentMinute, true);
        //if(currentdate!=null && minDate!=null && currentdate.getTime()-minDate.getTime() <= (3600*24) )

        if(currentdate!=null && minDate!=null  )
            dialog.setMindateTime(minDate);

      //  if(currentdate!=null && maxDate!=null && maxDate.getTime()-   currentdate.getTime() <= (3600*24) )
        if(currentdate!=null && maxDate!=null  )
            dialog.setMaxdateTime(maxDate);
        dialog.setCurrentTime(currentdate);
        dialog.setCancelable(false);
        dialog.show();

        return dialog;
    }

    public static void setCurrentTime(Date currentTime)
    {
        if(currentTime==null)
            currentTime=new Date();
        currentHour=currentTime.getHours();
        currentMinute=currentTime.getMinutes();
    }

    private static void updateLabel(EditText eventDateEditText,Calendar myCalendar) {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        eventDateEditText.setText(sdf.format(myCalendar.getTime()));

    }
}
