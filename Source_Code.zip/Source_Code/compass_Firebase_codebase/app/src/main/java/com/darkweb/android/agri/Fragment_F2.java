package com.darkweb.android.agri;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.darkweb.android.compass.R;

import java.util.ArrayList;

public class Fragment_F2 extends Fragment implements AdapterView.OnItemSelectedListener {
    Spinner f2_sp_culti;
    String [] ans_f2_sp_culti, listItems, listItems_lease;
    boolean [] checkedItems, checkedItems_lease;
    ArrayList<Integer> mUserItems = new ArrayList<>();
    ArrayList<Integer> mUserItems_lease = new ArrayList<>();
    Button f3_bt_own, f3_bt_lease;
    TextView f3_tx_own;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d("Fragment ","2");
        View f2View = inflater.inflate(R.layout.ag_fragment_f2, container, false); //tab_fragment_2

        f2_sp_culti  = f2View.findViewById(R.id.f2_sp_culti);

        f3_bt_own = f2View.findViewById(R.id.f3_bt_own);
        f3_tx_own = f2View.findViewById(R.id.f3_tx_own);
        f3_bt_lease =  f2View.findViewById(R.id.f3_bt_lease);

        f2Spculti();
        return f2View;
    }

    private void f2Spculti() {
        ans_f2_sp_culti = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f2_sp_culti);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f2_sp_culti.setAdapter(memAdapter);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        listItems = new String[]{"Personal property", "Leased", "Family property","Communal land","Other"};
        checkedItems = new boolean[listItems.length];
                f3_bt_own.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
                        mBuilder.setTitle("Who own the lands you farm on?");
                        mBuilder.setMultiChoiceItems(listItems, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                                if(isChecked){
                                    Log.d("**CHECKED**", String.valueOf(isChecked));
                                    if(!mUserItems.contains(position)){
                                        mUserItems.add(position);
                                        Log.d("**MULTI CHOICE**", mUserItems.toString());
                                    }
                                }else {
                                    Log.d("**CHECKED**", String.valueOf(isChecked));
                                    mUserItems.remove(position);
                                    Log.d("**MULTI CHOICE2**", mUserItems.toString());
                                }
                            }
                        });
                        mBuilder.setCancelable(false);
                        mBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String item = "";
                                for (int i = 0; i< mUserItems.size(); i++){
                                    item = item + listItems [mUserItems.get(i)];
                                    if( i != mUserItems.size() -1){
                                        item = item + ", ";
                                    }
                                }
                                f3_bt_own.setText(item);
                            }
                        });
                        mBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        mBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                for (int i = 0; i < checkedItems.length; i++){
                                    checkedItems [i] = false;
                                    mUserItems.clear();
                                    f3_bt_own.setText("Select an answer");
                                }
                            }
                        });

                        AlertDialog mDialog = mBuilder.create();
                        mDialog.show();

                    }
                });

        listItems_lease = new String[]{"Cash payment", "Harvest sharing", "Other"};
        checkedItems_lease = new boolean[listItems_lease.length];
        f3_bt_lease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
                mBuilder.setTitle("If the land is not personal or family property, what are the terms of lease?");
                mBuilder.setMultiChoiceItems(listItems_lease, checkedItems_lease, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                        if(isChecked){
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            if(!mUserItems_lease.contains(position)){
                                mUserItems_lease.add(position);
                                Log.d("**MULTI CHOICE**", mUserItems_lease.toString());
                            }
                        }else {
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            mUserItems_lease.remove(position);
                            Log.d("**MULTI CHOICE2**", mUserItems_lease.toString());
                        }
                    }
                });
                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String item = "";
                        for (int i = 0; i< mUserItems_lease.size(); i++){
                            item = item + listItems_lease [mUserItems_lease.get(i)];
                            if( i != mUserItems_lease.size() -1){
                                item = item + ", ";
                            }
                        }
                        f3_bt_lease.setText(item);
                    }
                });
                mBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                mBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for (int i = 0; i < checkedItems_lease.length; i++){
                            checkedItems_lease [i] = false;
                            mUserItems_lease.clear();
                            f3_bt_lease.setText("Select an answer");
                        }
                    }
                });

                AlertDialog mDialog = mBuilder.create();
                mDialog.show();

            }
        });
   }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
