package com.darkweb.android.adapter;

import android.app.LauncherActivity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.SearchAdapterList;

import java.util.ArrayList;
import java.util.List;

public class SearchArrayAdapter extends ArrayAdapter<OrganizationDescription> {

    private List<SearchAdapterList> searchAdapterListAll;
    ArrayList<OrganizationDescription> finalOrganizationArrayListAll;

    public SearchArrayAdapter(@NonNull Context context, ArrayList<OrganizationDescription> finalOrganizationArrayList) {
        super(context, 0,finalOrganizationArrayList);

        //searchAdapterListAll = new ArrayList<>(searchAdapterLists);
        finalOrganizationArrayListAll = new ArrayList<>();
    }

    @NonNull
    @Override
    public Filter getFilter(){
        return listFilter;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.search_adap_row_format,parent,false);
        }

        TextView textView = convertView.findViewById(R.id.textView);


        String listItem = getItem(position).getOrganizationName();

        if(listItem != null){
            textView.setText(listItem);
            //imageView.setImageResource(listItem.getImage());
        }

        return convertView;
    }


    private Filter listFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            ArrayList<OrganizationDescription> suggestion = new ArrayList<>();
            ArrayList<String> suggestionOrgName = new ArrayList<>();

            if (constraint==null || constraint.length() ==0){
                suggestion.addAll(finalOrganizationArrayListAll);
            } else {
                String filterText = constraint.toString().toLowerCase().trim();
                for (OrganizationDescription orgObj : finalOrganizationArrayListAll){
                    if(orgObj.getOrganizationName().toLowerCase().contains(filterText) || orgObj.getDescription().toLowerCase().contains(filterText)){
                        suggestion.add(orgObj); //this is pop up list items
                        suggestionOrgName.add(orgObj.getOrganizationName());
                    }
                }
            }

            results.values = suggestionOrgName;
            results.count = suggestionOrgName.size();
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            clear();
            addAll((OrganizationDescription) results.values);
            notifyDataSetChanged();
        }
    };

}
