package com.darkweb.android.model.ObjectsForMapper;

import java.util.List;

public class ServicesFilters {
    private int clientId;
    private List<RequestedServiceStatus> checkedOptions;
    private String sortByWhat;

    public ServicesFilters() {
    }

    public ServicesFilters(int clientId, List<RequestedServiceStatus> checkedOptions, String sortByWhat) {
        this.clientId = clientId;
        this.checkedOptions = checkedOptions;
        this.sortByWhat = sortByWhat;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public List<RequestedServiceStatus> getCheckedOptions() {
        return checkedOptions;
    }

    public void setCheckedOptions(List<RequestedServiceStatus> checkedOptions) {
        this.checkedOptions = checkedOptions;
    }

    public String getSortByWhat() {
        return sortByWhat;
    }

    public void setSortByWhat(String sortByWhat) {
        this.sortByWhat = sortByWhat;
    }
}
