package com.darkweb.android.service.HttpHandlers;

import android.os.AsyncTask;

import com.darkweb.android.global.MyBackendLinks;

import java.io.File;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.util.Objects;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class HttpFileUploadHandler extends AsyncTask<String, Void, String> {

    private File file;
    private int clientId;
    private int serviceId;
    private int organizationId;

    public HttpFileUploadHandler(File file, int clientId, int serviceId, int organizationId) {
        this.file = file;
        this.clientId = clientId;
        this.serviceId = serviceId;
        this.organizationId = organizationId;
    }

    // This chunk of code just used too many times
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory, (X509TrustManager)trustAllCerts[0]);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    protected String doInBackground(String... strings) {
        String resStr = "";
        OkHttpClient client = getUnsafeOkHttpClient();
        RequestBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.getName(),
                        RequestBody.create(file, MediaType.parse("text/plain")))
                .addFormDataPart("other_field", "other_field_value")
                .build();

        Request request = new Request.Builder()
                .url(new MyBackendLinks().mobileEndPoint
                        + "uploadFile/" + clientId + "/" + organizationId + "/" + serviceId)
                .method("POST", body)
                .build();
        try {
            Response response = client.newCall(request).execute();
            resStr = Objects.requireNonNull(response.body()).string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  resStr;
    }

    protected void onPostExecute(String result){
        super.onPostExecute(result);
    }
}
