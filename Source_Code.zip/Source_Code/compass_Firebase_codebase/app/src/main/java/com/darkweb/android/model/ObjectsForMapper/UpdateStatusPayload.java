package com.darkweb.android.model.ObjectsForMapper;

public class UpdateStatusPayload {
    private int requestId;
    private int clientId;
    private String status;

    public UpdateStatusPayload() {
    }

    public UpdateStatusPayload(int requestId, int clientId, String status) {
        this.requestId = requestId;
        this.clientId = clientId;
        this.status = status;
    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
