package com.darkweb.android.login;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.darkweb.android.global.MyGlobalVars;
import com.darkweb.android.model.User;
import com.darkweb.android.compass.R;
import com.darkweb.android.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;


public class LoginActivity extends AppCompatActivity {

    EditText inputLayoutEmail, inputLayoutPassword;
   Button login;
   UserService userService;
   TextView register,errorTextView ;
    int itemId=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        userService = new UserService();
        inputLayoutEmail = (EditText) findViewById(R.id.input_email);
        inputLayoutPassword = (EditText) findViewById(R.id.input_password);
        login = (Button) findViewById(R.id.login);
        register = (TextView) findViewById(R.id.register);
        errorTextView=(TextView)findViewById(R.id.errortextview);
        itemId=getIntent().getIntExtra(getString(R.string.itemId),0);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User user=new User();
                user.setUserName(inputLayoutEmail.getText().toString());
                user.setPassword(inputLayoutPassword.getText().toString());
                ProgressDialog progressDialog;
                progressDialog = new ProgressDialog(LoginActivity.this);
                progressDialog.setMessage("Logging in...");
                progressDialog.setCancelable(false);
                progressDialog.show();

//                /**
//                 * Sending request to backend for registering
//                 */
//                ObjectMapper objectMapper = new ObjectMapper();
//                Boolean login = false;
//                String userDataToBackend = null;
//                try {
//                    userDataToBackend = objectMapper.writeValueAsString(user);
//                } catch (JsonProcessingException e) {
//                    e.printStackTrace();
//                }
//                String result = "";
//                try {
//                    result = new HttpSignupLogin().execute(userDataToBackend, "login").get();
//                    JSONObject serverResult = new JSONObject(result);
//                    String userIDBackend = serverResult.getString("message");
//                    login = serverResult.getBoolean("success");
//                    user.setUserUID(userIDBackend);
//                    MyGlobalVars.getInstance().userStatus.setUserId(Integer.parseInt(userIDBackend));
//                    MyGlobalVars.getInstance().userStatus.setLoginStatus(true);
//                } catch (ExecutionException | InterruptedException | JSONException e) {
//                    e.printStackTrace();
//                }

                if(userService.signInUser(LoginActivity.this,user,itemId,errorTextView)) {
                    SharedPreferences sp = LoginActivity.this.getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
                    Intent intent=new Intent();
                    intent.putExtra(getString(R.string.itemId)+"", itemId);
                    setResult(2,intent);
                    finish();
                }
                else{
                    errorTextView.setText("Wrong username or password");
                    errorTextView.setTextColor(getResources().getColor(R.color.pending));
                }
                if(progressDialog.isShowing())
                    progressDialog.dismiss();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InputMethodManager imm = (InputMethodManager)getSystemService(LoginActivity.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(inputLayoutPassword.getWindowToken(),
                        InputMethodManager.RESULT_UNCHANGED_SHOWN);
                Intent i = new Intent(LoginActivity.this,RegisterActivity.class);
                i.putExtra(getString(R.string.itemId),itemId);
                startActivityForResult(i, 2);// Activity is started with requestCode 2

            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("req:", requestCode + "");
        if (requestCode == 2 && data!=null)
        {
            User user = (User) data.getSerializableExtra(getString(R.string.userObject));
            Log.d("itemId:",itemId+""+getString(R.string.itemId));
            Intent intent=new Intent();
            intent.putExtra(getString(R.string.itemId)+"", itemId);
            setResult(2,intent);
            finish();//finishing activity
        }
        else
        {
            errorTextView.setText("Cannot register the user");
        }
    }
}
