package com.darkweb.android.model;

import android.util.Log;

import java.util.Comparator;
import java.util.Date;

/**
 * Created by kotak on 08/08/2018.
 */

public class NewsFeedDateComparator implements Comparator<Object> {
    @Override
    public int compare(Object o2, Object o1) {
        if(o1 instanceof  CalandarEvent && o2 instanceof  CalandarEvent)
        {
            Log.d("time:",""+((CalandarEvent)o1).getEventDateTime().compareTo(((CalandarEvent)o2).getEventDateTime())+" o1:"+((CalandarEvent)o1).getEventDateTime()+ " o2:"+((CalandarEvent)o2).getEventDateTime());
            return ((CalandarEvent)o1).getEventDateTime().compareTo(((CalandarEvent)o2).getEventDateTime());
        }
        else if(o1 instanceof  CalandarEvent && o2 instanceof  ServiceDetails)
        {
            return ((CalandarEvent)o1).getEventDateTime().compareTo(new Date(((ServiceDetails)o2).getExpectingServiceDate()));
        }
        else if(o1 instanceof  ServiceDetails && o2 instanceof  CalandarEvent)
        {
            return (new Date(((ServiceDetails)o1).getExpectingServiceDate())).compareTo(((CalandarEvent)o2).getEventDateTime());
        }
        else if(o1 instanceof  ServiceDetails && o2 instanceof  ServiceDetails)
        {
            return (new Date(((ServiceDetails)o1).getExpectingServiceDate())).compareTo(new Date(((ServiceDetails)o2).getExpectingServiceDate()));
        }

        return 0;
    }
}
