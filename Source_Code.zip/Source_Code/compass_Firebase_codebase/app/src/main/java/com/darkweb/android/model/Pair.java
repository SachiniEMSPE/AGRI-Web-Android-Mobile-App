package com.darkweb.android.model;

public class Pair {
	String styleUrl;
	String key;

}
