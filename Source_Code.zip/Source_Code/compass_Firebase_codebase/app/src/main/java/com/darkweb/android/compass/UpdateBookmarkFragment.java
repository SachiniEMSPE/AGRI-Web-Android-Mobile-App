package com.darkweb.android.compass;

public interface UpdateBookmarkFragment {
    public void updateFragment();
}
