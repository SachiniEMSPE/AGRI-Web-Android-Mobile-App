package com.darkweb.android.compass;

import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;

import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.darkweb.android.adapter.AndroidListAdapter;
import com.darkweb.android.adapter.CalendarAdapter;
import com.darkweb.android.adapter.MyExpandableListAdapter;
import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.model.CategoryList;
import com.darkweb.android.model.OrganizationDescription;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;

import static android.app.Activity.RESULT_OK;

/**
 * Created by kotak on 19/07/2018.
 */

//For both calender activities
public class FragmentCalendarView extends Fragment {
    private View view;
    public GregorianCalendar cal_month, cal_month_copy;
    private CalendarAdapter cal_adapter;
    private TextView tv_month;
    private ListView lv_android;
    private AndroidListAdapter list_adapter,list_adapter1;
    private ArrayList<CalandarEvent> calendarEventList=new ArrayList<CalandarEvent>();
    private ArrayList<CalandarEvent> currentCalendarEventList=new ArrayList<CalandarEvent>();
    Button filterApplybutton, filtercancelbutton;
    ArrayList<CategoryList> categoryLists1 = new ArrayList<CategoryList>();

    String url;
    File myEventsFile;
    private Dialog dialog;
    private SimpleDateFormat df= new SimpleDateFormat("yyyy-MM-dd",Locale.US);;
    private ImageButton previous;
    ImageButton next ;
    GridView gridview ;
    private String strtext;
    private AutoCompleteTextView organizationAutoTextView;
    private ImageButton filter;
    private ArrayList<OrganizationDescription> organizationDescriptionArrayList;
    private ArrayList<CalandarEvent> currentEventList=new ArrayList<CalandarEvent>();
    private ExpandableListView categoryListview;
    private MyExpandableListAdapter myExpandableListAdapter;
    CategoryList cl1 = new CategoryList();
    private TextView resetAllTextView;
    private HashMap<String, Boolean> checkBoxBooleanList;
    private TextView monthNameTextView;
    public FragmentCalendarView() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if(getArguments()!=null)
        strtext = getArguments().getString(getString(R.string.fragment_string));
        else
            strtext=getString(R.string.My_Volunteer_services);
        if(strtext.equals(getString(R.string.My_Volunteer_services)))
            return inflater.inflate(R.layout.activity_calendar, container, false);
        else
            return  inflater.inflate(R.layout.opportunity_calendar_layout, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        url=getActivity().getFilesDir().toString();
        cal_month = (GregorianCalendar) GregorianCalendar.getInstance();
        cal_month_copy = (GregorianCalendar) cal_month.clone();
        tv_month = (TextView) view.findViewById(R.id.tv_month);
        previous = (ImageButton) view.findViewById(R.id.ib_prev);
        next = (ImageButton) view.findViewById(R.id.Ib_next);
        gridview = (GridView) view.findViewById(R.id.gv_calendar);
        monthNameTextView = (TextView) view.findViewById(R.id.monthEvents);




        if(strtext.equals(getString(R.string.Volunteer_Oppurtunity)))
        {
           filter = (ImageButton) view.findViewById(R.id.filterButton);
            organizationAutoTextView = (AutoCompleteTextView)view.findViewById(R.id.Organization_name_searchview);
            organizationAutoTextView.setOnTouchListener(new View.OnTouchListener() {

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    final int DRAWABLE_LEFT = 0;
                    final int DRAWABLE_TOP = 1;
                    final int DRAWABLE_RIGHT = 2;
                    final int DRAWABLE_BOTTOM = 3;

               /*     if(event.getAction() == MotionEvent.ACTION_UP) {
                        if(event.getRawX() >= (organizationAutoTextView.getRight() - organizationAutoTextView.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {


                            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

                            if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                                startActivityForResult(intent, 10);
                            }
                            return true;
                        }
                    }*/

                    if(event.getRawX() <= organizationAutoTextView.getTotalPaddingLeft()) {
                        // your action for drawable click event
                        String searchText = organizationAutoTextView.getText().toString();
                        if (!searchText.equals(""))
                            updateEventList(searchText, categoryLists1);
                        else
                            updateEventList(null, categoryLists1);
                        return true;
                    }

                    return false;
                }
            });


            filter.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Dialog filterDialogue = new Dialog(getActivity());
                    filterDialogue.setContentView(R.layout.filterlistdialogue);

                    filterDialogue.findViewById(R.id.spinnersortlayout).setVisibility(View.GONE);

                    resetAllTextView=(TextView) filterDialogue.findViewById(R.id.reset_all);
                    filterApplybutton = (Button) filterDialogue.findViewById(R.id.applybutton);
                    filtercancelbutton = (Button) filterDialogue.findViewById(R.id.cancelbutton);
                    categoryListview = (ExpandableListView) filterDialogue.findViewById(R.id.checkboxlistexpamdable);
                    myExpandableListAdapter = new MyExpandableListAdapter(getActivity(), categoryLists1);
                    Log.d("Null:", "Adapter:" + (categoryListview.isShown()) + "  view:" + (categoryListview == null) + " size:" + categoryLists1.get(0).getOptions().size());

                    categoryListview.setAdapter(myExpandableListAdapter);
                    // categoryListview.addHeaderView(myExpandableListAdapter.getGroupView(0,true,null,null));
                    Log.d("Null:", "Adapter:" + (categoryListview.isShown()) + "  view:" + (categoryListview == null) + " size:" + categoryLists1.get(0).getOptions().size());
                    ArrayList<CategoryList> cancelCategoryAdapterList = myExpandableListAdapter.getCategoryList();

                    checkBoxBooleanList=new HashMap<String,Boolean>();
                    if(cancelCategoryAdapterList!=null)
                    {
                        for (int i = 0; i < cancelCategoryAdapterList.size(); i++) {
                            for (int j = 0; j < cancelCategoryAdapterList.get(i).getBoxChecked().size(); j++) {
                                if(!checkBoxBooleanList.containsKey(cancelCategoryAdapterList.get(i).getOptions().get(j)))
                                {
                                    checkBoxBooleanList.put(cancelCategoryAdapterList.get(i).getOptions().get(j),cancelCategoryAdapterList.get(i).getBoxChecked().get(j));
                                }
                            }
                        }
                    }
                    resetAllTextView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                            if(clTemp!=null)
                            {
                                for (int i = 0; i < clTemp.size(); i++) {
                                    for (int j = 0; j < clTemp.get(i).getBoxChecked().size(); j++) {
                                        myExpandableListAdapter.getCategoryList().get(i).getBoxChecked().set(j,new Boolean(true) );
                                        ((BaseAdapter) categoryListview.getAdapter()).notifyDataSetChanged();
                                    }
                                }
                            }
                        }
                    });

                    filtercancelbutton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                            if(clTemp!=null)
                            {
                                for (int i = 0; i < clTemp.size(); i++) {
                                    for (int j = 0; j < clTemp.get(i).getBoxChecked().size(); j++) {
                                        myExpandableListAdapter.getCategoryList().get(i).getBoxChecked().set(j, checkBoxBooleanList.get(myExpandableListAdapter.getCategoryList().get(i).getOptions().get(j)));
                                        ((BaseAdapter) categoryListview.getAdapter()).notifyDataSetChanged();
                                    }
                                }
                            }
                            filterDialogue.dismiss();
                       }
                    });
                    filterApplybutton.setOnClickListener(new View.OnClickListener() {
                        @RequiresApi(api = Build.VERSION_CODES.N)
                        @Override
                        public void onClick(View v) {
                            ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                            String searchText = organizationAutoTextView.getText().toString();
                            if (!searchText.equals(""))
                                updateEventList(searchText,clTemp);
                            else
                                updateEventList(null,clTemp);
                            filterDialogue.dismiss();
                        }
                    });

                    categoryListview.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                        @Override
                        public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                            CategoryList categoryGroup = categoryLists1.get(groupPosition);
                            String checkboxItem = categoryGroup.getOptions().get(childPosition);
                            return false;
                        }
                    });

                    categoryListview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
                        @Override
                        public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                            CategoryList categoryGroup = categoryLists1.get(groupPosition);

                            return false;
                        }
                    });
                    filterDialogue.show();
                }
            });
        }
    }

    protected void setNextMonth() {
        if (cal_month.get(GregorianCalendar.MONTH) == cal_month
                .getActualMaximum(GregorianCalendar.MONTH)) {
            cal_month.set((cal_month.get(GregorianCalendar.YEAR) + 1),
                    cal_month.getActualMinimum(GregorianCalendar.MONTH), 1);
        } else {
                    cal_month.set(GregorianCalendar.MONTH,
                    cal_month.get(GregorianCalendar.MONTH) + 1);
        }

    }

    protected void setPreviousMonth() {
        if (cal_month.get(GregorianCalendar.MONTH) == cal_month
                .getActualMinimum(GregorianCalendar.MONTH)) {
            cal_month.set((cal_month.get(GregorianCalendar.YEAR) - 1),
                    cal_month.getActualMaximum(GregorianCalendar.MONTH), 1);
        } else {
            cal_month.set(GregorianCalendar.MONTH,
                    cal_month.get(GregorianCalendar.MONTH) - 1);
        }

    }

    public void refreshCalendar() {
        cal_adapter.refreshDays();
        cal_adapter.notifyDataSetChanged();

        tv_month.setText(android.text.format.DateFormat.format("MMMM yyyy", cal_month));
        monthNameTextView.setText(android.text.format.DateFormat.format("MMMM yyyy", cal_month)+" Events");
        currentCalendarEventList.clear();

        for (CalandarEvent obj:currentEventList)
        {
            Log.d("date added: ",new SimpleDateFormat("MMMM yyyy").format(obj.getEventDateTime())+" s:"+tv_month.getText().toString());
            if((new SimpleDateFormat("MMMM yyyy").format(obj.getEventDateTime())).equals(tv_month.getText().toString()))
            {
                currentCalendarEventList.add(obj);
            }
        }

        if (lv_android==null)
            lv_android = (ListView) view.findViewById(R.id.lv_android);

        if (list_adapter==null)
        {//calendar_list_item
            list_adapter = new AndroidListAdapter(getActivity(),R.layout.calendar_list_item, currentCalendarEventList);
            lv_android.setAdapter(list_adapter);

        }
        else
        {
            list_adapter.notifyDataSetChanged();
            //
            Log.d("size:",list_adapter.getCount()+" s:"+calendarEventList.size());
        }

        lv_android.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CalandarEvent calEventObj=currentCalendarEventList.get(position);
                String item = calEventObj.getEventDescription();
                Log.e("item",item.toString());
                Intent i = new Intent(getActivity(),ViewCalandarEvent.class);
                i.putExtra(getString(R.string.calandarEventObject), calEventObj);
                // i.putExtra("bookmark","true");
                startActivity(i);
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream ;
        Log.d("Resume","yes");
        if(strtext!=null && strtext.equals(getString(R.string.Volunteer_Oppurtunity)))
        {
            myEventsFile=new File(url,getString(R.string.locationDescriptionEventList));
            if (myEventsFile.exists())
            {
                try {
                    fileInputStream = new FileInputStream(myEventsFile);
                    objectInputStream = new ObjectInputStream(fileInputStream);
                    organizationDescriptionArrayList = (ArrayList<OrganizationDescription>) objectInputStream.readObject();
                    if (calendarEventList==null)
                    {
                        calendarEventList=new ArrayList<CalandarEvent>();
                    }
                    else
                    {
                        if(calendarEventList.size()>0) {
                            Log.d("clear:","calendar event list");
                            calendarEventList.clear();
                        }
                    }
                    for (OrganizationDescription locObj: organizationDescriptionArrayList)
                    {
                        calendarEventList.addAll(locObj.getOrganisationEventList());
                    }
                    objectInputStream.close();
                    fileInputStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        else
        {

            try {
                myEventsFile = new File(url, getString(R.string.yourEventListFile));
                if (myEventsFile.exists()) {
                    fileInputStream = new FileInputStream(myEventsFile);
                    objectInputStream = new ObjectInputStream(fileInputStream);
                    if (calendarEventList==null)
                    {
                        calendarEventList=new ArrayList<CalandarEvent>();
                    }
                    else
                    {
                        if(calendarEventList.size()>0) {
                            Log.d("clear:","calendar event list");
                            calendarEventList.clear();
                        }
                    }
                    calendarEventList.addAll((ArrayList<CalandarEvent>) objectInputStream.readObject());
                    objectInputStream.close();
                    fileInputStream.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        cl1.setCategoryName("Categories");
        ArrayList<String> categories = new ArrayList<String>();
        ArrayList<Boolean> isBoxCheckedList = new ArrayList<Boolean>();
        for (CalandarEvent calandarEventObj : calendarEventList) {
            if(!categories.contains(calandarEventObj.getOrganizationDescription().getCategory()))
                categories.add(calandarEventObj.getOrganizationDescription().getCategory());
        }
        for (int i = 0; i < categories.size(); i++) {
            isBoxCheckedList.add(new Boolean(true));
        }
        cl1.setBoxChecked(isBoxCheckedList);
        cl1.setOptions(categories);
        if (categoryLists1.size()>0)
            categoryLists1.clear();
        categoryLists1.add(cl1);


        updateEventList(null, categoryLists1);
    }

    public void updateEventList(String searchText, ArrayList<CategoryList> clTemp)
    {
        currentEventList.clear();
        if (searchText!=null)
            Log.d("searchText:",searchText);

        if(searchText!=null && !searchText.equals(""))
        {

            if(organizationDescriptionArrayList !=null && organizationDescriptionArrayList.size()>0)
            {
                for(OrganizationDescription locationobj: organizationDescriptionArrayList)
                {
                    if ( locationobj.getOrganizationName().contains(searchText) || locationobj.getCategory().contains(searchText) || locationobj.getContact().contains(searchText) || locationobj.getZipcode().contains(searchText) || locationobj.getState().contains(searchText) || locationobj.getCity().contains(searchText) || locationobj.getDescription().contains(searchText)||locationobj.getEmailId().contains(searchText)||locationobj.getStreetAddress().contains(searchText)||locationobj.getWebsite().contains(searchText))
                    {
                        int flag = 0;
                        for (CategoryList categoryobj : clTemp) {
                            String categoryName = categoryobj.getCategoryName();
                            ArrayList<String> categoryOptions = categoryobj.getOptions();
                            ArrayList<Boolean> isCheckedList = categoryobj.getBoxChecked();
                            Log.d("size:",categoryOptions.size()+"");
                            if (categoryName.equals("Categories")) {
                                for (int i = 0; i < categoryOptions.size(); i++) {
                                    Log.d("catgory:",""+categoryOptions.get(i)+" "+isCheckedList.get(i));
                                    if (locationobj.getCategory().equals(categoryOptions.get(i)))
                                    {
                                        if (isCheckedList.get(i).equals(new Boolean(true)))
                                        {
                                            currentEventList.addAll(locationobj.getOrganisationEventList());
                                        }
                                        flag = 1;
                                        break;
                                    }
                                }
                                if (flag==1)
                                {
                                    break;
                                }
                            }
                        }

                    }
                    else
                    {
                        for(CalandarEvent calEventObj:locationobj.getOrganisationEventList())
                        {
                            if( calEventObj.getEventName().contains(searchText) || calEventObj.getEventDateTime().toString().contains(searchText) || calEventObj.getEventDescription().contains(searchText) || calEventObj.getStreetAddress().contains(searchText) || calEventObj.getCity().contains(searchText) || calEventObj.getState().contains(searchText) ||   calEventObj.getZipcode().contains(searchText))
                            {
                                int flag = 0;
                                for (CategoryList categoryobj : clTemp) {
                                    String categoryName = categoryobj.getCategoryName();
                                    ArrayList<String> categoryOptions = categoryobj.getOptions();
                                    ArrayList<Boolean> isCheckedList = categoryobj.getBoxChecked();
                                    Log.d("size:",categoryOptions.size()+"");
                                    if (categoryName.equals("Categories")) {
                                        for (int i = 0; i < categoryOptions.size(); i++) {
                                            Log.d("catgory:",""+categoryOptions.get(i)+" "+isCheckedList.get(i));
                                            if (calEventObj.getOrganizationDescription().getCategory().equals(categoryOptions.get(i)))
                                            {
                                                if (isCheckedList.get(i).equals(new Boolean(true)))
                                                {
                                                    currentEventList.add(calEventObj);
                                                }
                                                flag = 1;
                                                break;
                                            }
                                        }
                                        if (flag==1)
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else
        {
            for (CalandarEvent calEventObj:calendarEventList) {
                int flag = 0;
                for (CategoryList categoryobj : clTemp) {
                    String categoryName = categoryobj.getCategoryName();
                    ArrayList<String> categoryOptions = categoryobj.getOptions();
                    ArrayList<Boolean> isCheckedList = categoryobj.getBoxChecked();
                    Log.d("size:", categoryOptions.size() + "");
                    if (categoryName.equals("Categories")) {
                        for (int i = 0; i < categoryOptions.size(); i++) {
                            Log.d("catgory:", "" + categoryOptions.get(i) + " " + isCheckedList.get(i));
                            if (calEventObj.getOrganizationDescription().getCategory().equals(categoryOptions.get(i))) {
                                if (isCheckedList.get(i).equals(new Boolean(true))) {
                                    currentEventList.add(calEventObj);
                                }
                                flag = 1;
                                break;
                            }
                        }
                        if (flag == 1) {
                            break;
                        }
                    }
                }

            }

        }


        Log.d("sizeEvent:",""+currentEventList.size()+" : "+calendarEventList.size());
        cal_adapter = new CalendarAdapter(getActivity(), cal_month, currentEventList);
        tv_month.setText(android.text.format.DateFormat.format("MMMM yyyy", cal_month));
        refreshCalendar();
        previous.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                setPreviousMonth();
                refreshCalendar();
            }
        });

        next.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                setNextMonth();
                refreshCalendar();

            }
        });
        gridview.setAdapter(cal_adapter);  ///////////////////////////////////////////////////////CHECK
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    ((CalendarAdapter) parent.getAdapter()).setSelected(v, position);
                }
                Log.d("position:",position+"");
                String selectedGridDate = CalendarAdapter.day_string
                        .get(position);
                String[] separatedTime = selectedGridDate.split("-");
                String gridvalueString = separatedTime[2].replaceFirst("^0*", "");
                int gridvalue = Integer.parseInt(gridvalueString);
                if ((gridvalue > 10) && (position < 8)) {
                    setPreviousMonth();
                    refreshCalendar();
                } else if ((gridvalue < 7) && (position > 28)) {
                    setNextMonth();
                    refreshCalendar();
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    ((CalendarAdapter) parent.getAdapter()).setSelected(v, position);
                }
                getPositionList(selectedGridDate);
            }
        });

    }

    public void getPositionList( String date){

        ArrayList<CalandarEvent> currentList=new ArrayList<CalandarEvent>();
        dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.dialog_inform);


        ImageView crossimage=(ImageView) dialog.findViewById(R.id.img_cross);
        crossimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                refreshCalendar();


            }
        });

        TextView eventdayanameTextview= dialog.findViewById(R.id.event_name_day_textview);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        try {
            Date oldDate = sdf.parse(date.trim());
            String pattern = "EEEE, MM/dd/yyyy";
            df = new SimpleDateFormat(pattern);
            Log.d("dateerror:",date+" old:"+oldDate);
            eventdayanameTextview.setText("Events on "+df.format(oldDate));
            date=df.format(oldDate);

        } catch (ParseException e) {
            e.printStackTrace();
        }

        dialog.setCancelable(false);

        dialog.setTitle("Event list");
        int width = (int)(getActivity().getResources().getDisplayMetrics().widthPixels*0.90);
        dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);

        for(CalandarEvent obj:currentEventList) {
            String event_date = df.format(obj.getEventDateTime());
            Log.d("Date Listener:",date+" and "+event_date);
            if (date.equals(event_date)) {
                Log.d("List content: ",obj.getEventName());
                currentList.add(obj);
            }
        }
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////SHON Dialog
        ListView lv_android1 = (ListView) dialog.findViewById(R.id.dialog_lv_android);

        list_adapter1 = new AndroidListAdapter(getActivity(),R.layout.calendar_list_item, currentList);
        lv_android1.setAdapter(list_adapter1);
        Log.v("qwerty:",list_adapter1.getCount()+" s:"+currentList.size());
        lv_android1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                CalandarEvent calEventObj=currentList.get(position);
                String item = calEventObj.getEventDescription();
                Log.e("item",item.toString());
                Intent i = new Intent(getActivity(),ViewCalandarEvent.class);
                i.putExtra(getActivity().getString(R.string.calandarEventObject), calEventObj);
                // i.putExtra("bookmark","true");
                getActivity().startActivity(i);
            }
        });
        dialog.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    organizationAutoTextView.setText(result.get(0));
                }
                break;
        }
    }
}
