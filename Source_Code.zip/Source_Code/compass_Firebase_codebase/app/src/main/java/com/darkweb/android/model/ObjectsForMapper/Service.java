package com.darkweb.android.model.ObjectsForMapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Service {
    private Integer id;
    private String name;
    private String description;
    private String aliases;
    private String keywords;
    private String hours;
    private Boolean morningHours;
    private Boolean afternoonHours;
    private Boolean eveningHours;
    private Boolean nightShift;
    private String specificHours;
    private String additionalRequirements;
    private String eligibility;
    private List<Taxonomy> taxonomyList;

    public Service() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name != null ? name : "N/A";
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description != null ? description : "N/A";
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAliases() {
        return aliases;
    }

    public void setAliases(String aliases) {
        this.aliases = aliases;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getHours() {
        return hours != null ? hours : "N/A";
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public Boolean getMorningHours() {
        return morningHours;
    }

    public void setMorningHours(Boolean morningHours) {
        this.morningHours = morningHours;
    }

    public Boolean getAfternoonHours() {
        return afternoonHours;
    }

    public void setAfternoonHours(Boolean afternoonHours) {
        this.afternoonHours = afternoonHours;
    }

    public Boolean getEveningHours() {
        return eveningHours;
    }

    public void setEveningHours(Boolean eveningHours) {
        this.eveningHours = eveningHours;
    }

    public Boolean getNightShift() {
        return nightShift;
    }

    public void setNightShift(Boolean nightShift) {
        this.nightShift = nightShift;
    }

    public String getSpecificHours() {
        return specificHours != null ? specificHours : "N/A";
    }

    public void setSpecificHours(String specificHours) {
        this.specificHours = specificHours;
    }

    public String getAdditionalRequirements() {
        return additionalRequirements != null ? additionalRequirements : "N/A";
    }

    public void setAdditionalRequirements(String additionalRequirements) {
        this.additionalRequirements = additionalRequirements;
    }

    public String getEligibility() {
        return eligibility != null ? eligibility : "N/A";
    }

    public void setEligibility(String eligibility) {
        this.eligibility = eligibility;
    }

    public List<Taxonomy> getTaxonomyList() {
        return taxonomyList;
    }

    public void setTaxonomyList(List<Taxonomy> taxonomyList) {
        this.taxonomyList = taxonomyList;
    }
}

