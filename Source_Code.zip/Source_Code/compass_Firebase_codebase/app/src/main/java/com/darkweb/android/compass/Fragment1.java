package com.darkweb.android.compass;

import android.Manifest;
import android.R.layout;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;

import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import androidx.annotation.*;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.text.Layout;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;

import com.darkweb.android.adapter.CustomDateTimePicker;
import com.darkweb.android.adapter.MyExpandableListAdapter;
import com.darkweb.android.adapter.SearchArrayAdapter;
import com.darkweb.android.dao.NearByRequestDao;
import com.darkweb.android.login.LoginActivity;
import com.darkweb.android.model.CategoryList;
import com.darkweb.android.model.ObjectsForMapper.Organization;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.service.HttpHandlers.HttpNearbyHandler;
import com.darkweb.android.service.OrganizationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import com.google.gson.Gson;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.CONTEXT_INCLUDE_CODE;
import static android.content.Context.MODE_PRIVATE;

// Code for Google Map for search organization and list view for same
public class Fragment1<descriptionsArrayList> extends Fragment implements
        OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener, DatePickerDialog.OnDateSetListener,
        GoogleMap.OnCameraIdleListener {

    String url;
    ArrayList<String> serviceAutoListOrganisation=new ArrayList<String>();
    ArrayList<String> descriptionOrgArrayList = new ArrayList<String>();//sach_added
    ArrayList<String> combinedNameDescriptionArrayList = new ArrayList<String>();//sach_added
    ArrayList<String> combinedNameDescriptionArrayListSearched = new ArrayList<String>();//sach_added
    ArrayList<String> combinedNameDescriptionArrayListTitles = new ArrayList<String>();//sach_added
    Marker m;
    String sortByItem;
    private GoogleMap mMap;
    private GoogleApiClient client;
    private LocationRequest locationRequest;
    private Location lastlocation;
    private Marker currentLocationmMarker;
    public static final int REQUEST_LOCATION_CODE = 99;
    int PROXIMITY_RADIUS = 10000;
    double latitude, longitude;
    ImageButton  filter;
    ImageButton listmapbutton;
    ImageButton maplistbutton;
    ImageButton searchbutton; //sach added
    Button school1, res, hospital1;
    Map<String, Float> categoryListColor = new HashMap<String, Float>();
    float colorFloat = 0.0F; // *sach there color variables are for different color markups in previous design
    float maxColorFloat = 360.0F;
    float totalCategoryIndex = 52.0F;
    float count = maxColorFloat / totalCategoryIndex;
    private ExpandableListView categoryListview;
    private MyExpandableListAdapter myExpandableListAdapter;
    ArrayList<CategoryList> categoryLists1 = new ArrayList<CategoryList>();
    ArrayList<OrganizationDescription> finalOrganizationDescriptionArrayList=new ArrayList<OrganizationDescription>();
    View bottomsheetview;
    Spinner spinnerSortBy;
    BottomSheetBehavior bottomSheetBehavior;
    Button listmapBottomButton;
    ListView serviceListView,searchedListView;
    CategoryList cl1 = new CategoryList();
    CategoryList sortingOptions = new CategoryList();
    Button filterApplybutton, filtercancelbutton,sortApplybutton, sortcancelbutton;
    private String TAG = LoginActivity.class.getSimpleName();
    FloatingActionButton fab;
    ArrayList<HashMap<String, String>> contactList;
    StringBuilder googlePlaceUrl;
    AutoCompleteTextView organizationAutoTextView ;
    TextView resetAllTextView=null;
    private HashMap<String, Boolean> checkBoxBooleanList;
    private int selectedSort=-1;
    private View view;
    private OrganizationService organizationService;
    public LatLng currentlocation;

    private ArrayAdapter<String> organizationAutoAdapter;
    //SearchArrayAdapter searchAdapter;
    private ArrayList<String> categories;
    LinearLayout openNowVerticleLayout;//sach_added1
    EditText inputDateEditText,inputTimeEditText,inputDistanceEditText;//sach added
    DatePickerDialog.OnDateSetListener inputDatelistner;//sach added
    Calendar myCalander = Calendar.getInstance();//sach added
    TextView defaultTV,onemileTV,twomilesTV,threemilesTV;//sach added
    String selectedDate;//sachadded
    int selectedDateIndex;//sachadded
    String selectedTime ;//sachadded
    String selectedDistance ;//sachadded
    Switch openNowSwitch;//sachadded

    private List<Organization> organizations;

    @Override
    //sach_Fragment 1 layout read
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_1, container, false);
        organizationService=new OrganizationService(getActivity());

        return view;

    }

    @Override
    //sach_Notify user to enable gps / floating action button action /
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //sach-search bar functionality , with blinking error
        filter = (ImageButton) view.findViewById(R.id.filterButton);
        searchbutton = (ImageButton) view.findViewById(R.id.searchButton);
        organizationAutoTextView = view.findViewById(R.id.Organization_name_searchview);
        organizationAutoTextView.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                //sach-uncomment
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;
                Log.d("sach_onTouchBoolean","yes");
                if (event.getRawX() <= organizationAutoTextView.getTotalPaddingLeft()) {
                    // your action for drawable click event
                    String searchText = organizationAutoTextView.getText().toString();
                    Log.d("sach_search_Text","_Image_Clicked : yes");
                    if (!searchText.equals("")) {
                        Log.d("sach_drawableClickEvent","yes");
                        //sach_commented below then uncommented
                        organizationService.updateServiceList(getActivity(), finalOrganizationDescriptionArrayList, categoryLists1, bottomsheetview, sortingOptions, null, mMap, m, serviceListView);
                    }
                    else{
                      //Toast.makeText(getContext(),"Please enter an organization!", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
                return false;
            }
        });
        filter.setEnabled(false);

        serviceListView = (ListView) view.findViewById(R.id.servicelist);

        //sach-Floating Action Button
        fab = view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("sach_FABclicked","yes");
                Intent i = new Intent(Fragment1.this.getActivity(), ServiceRequest.class);
                startActivity(i);
            }
        });


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            boolean cotd = checkLocationPermission();

        }

        //sach- map fragment update check GPS enable status - Alert Dialog
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        LocationManager lm = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
        Log.d("sach_GPSenabled","MAPfragment:yes");
        boolean gps_enabled = false;
        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
        }
        if (!gps_enabled) {
            // sach- notify user to enable gps alert dialog
            new AlertDialog.Builder(getContext())
                    .setMessage("Please enable GPS")
                    .setPositiveButton("Open GPS settings", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                            getContext().startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));

                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            Log.d("sach_GPSenabled","No");
        }


            if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                //Toast.makeText(getContext(), "Please Grant permission and restart the Application", Toast.LENGTH_SHORT).show();

            }
        new GetCourseCategoriesMarkerColor().execute();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    organizationAutoTextView.setText(result.get(0));
                    Log.d("sach_What","Ongoing");
                }
                break;
        }
    }

    @Override
    //sach-googlemap permision activity
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_LOCATION_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED) {
                        if (client == null) {
                            bulidGoogleApiClient();
                            Log.d("sach_Onrequest","Permission:TBD");
                        }
                        mMap.setMyLocationEnabled(true);
                        Log.d("sach_Onrequest","Permission:TBD");
                    }
                }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override

    //sach - Map loading
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        Log.d("Sach_MapLoadingHere","yes");

        if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            bulidGoogleApiClient();
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setZoomControlsEnabled(true);
            mMap.setMyLocationEnabled(true);

        }

        mMap.setOnCameraIdleListener(this);

        //Sach_Options
        sortingOptions.setCategoryName("Sort By:");
        ArrayList<String> sortingBy = new ArrayList<String>();
        ArrayList<Boolean> isSortBoxCheckedList = new ArrayList<Boolean>();
        sortingBy.add(getString(R.string.alphanumeric_sortby_service_request));
        sortingBy.add(getString(R.string.distance));
        sortingBy.add(getString(R.string.frequentlyUsed));
        //sortingBy.add(getString(R.string.Open_now));//sach_added to make "OPEN NOW" filter
        isSortBoxCheckedList.add(new Boolean(true));
        isSortBoxCheckedList.add(new Boolean(false));
        isSortBoxCheckedList.add(new Boolean(false));
        //isSortBoxCheckedList.add(new Boolean(false));//sach_added to make "OPEN NOW" filter
        sortingOptions.setOptions(sortingBy);
        sortingOptions.setBoxChecked(isSortBoxCheckedList);


        bottomsheetview = view.findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomsheetview);
    /*   listmapbutton =  bottomsheetview.findViewById(R.id.listmapButton);
        listmapbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bottomSheetBehavior.getState() == bottomSheetBehavior.STATE_EXPANDED) {
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_COLLAPSED);
                } else {
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_EXPANDED);
                }
            }
        });*/

        //sach-maplistbutton process
        maplistbutton = view.findViewById(R.id.maplistButton);
        maplistbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("sach_maplistbutton","Yes");
                if (bottomSheetBehavior.getState() == bottomSheetBehavior.STATE_EXPANDED) {
                    maplistbutton.setImageResource(R.drawable.round_list_white_18);
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_COLLAPSED);
                } else {
                    maplistbutton.setImageResource(R.drawable.maps);
                    bottomSheetBehavior.setState(bottomSheetBehavior.STATE_EXPANDED);
                }
            }
        });

        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {

                switch (newState) {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED: {

                        break;
                    }

                    case BottomSheetBehavior.STATE_COLLAPSED: {

                    }
                    break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        bottomSheetBehavior.setState(bottomSheetBehavior.STATE_EXPANDED);
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:

                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                //       fab.animate().scaleX(1 - slideOffset).scaleY(1 - slideOffset).setDuration(0).start();
            }
        });

        //sach - NOT EXCEUTING filter button activity - same as the below filter.setOnClickListner XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx
        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("sach_filterButton","Clicked:Yes");
                final Dialog sortDialogue=new Dialog(getActivity());
                sortDialogue.setContentView(R.layout.sortlistdialogue);
                sortDialogue.setTitle("Sort Organization");
                sortDialogue.setCancelable(false);
                resetAllTextView=(TextView) sortDialogue.findViewById(R.id.reset_all);
                sortApplybutton = (Button) sortDialogue.findViewById(R.id.applybutton);
                sortcancelbutton = (Button) sortDialogue.findViewById(R.id.cancelbutton);
                sortDialogue.setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                        // Prevent dialog close on back press button
                        if(keyCode == KeyEvent.KEYCODE_BACK)
                            sortDialogue.dismiss();
                        return keyCode == KeyEvent.KEYCODE_BACK;
                    }
                });
                spinnerSortBy = (Spinner) sortDialogue.findViewById(R.id.spinner_sortby);
                spinnerSortBy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        sortByItem = parent.getItemAtPosition(position).toString();
                        //updateCategorySortList(sortByItem);

                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                ArrayAdapter sortAdapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, sortingOptions.getOptions());
                sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerSortBy.setAdapter(sortAdapter);
                if (sortByItem!=null)
                    spinnerSortBy.setSelection(sortingOptions.getOptions().indexOf(sortByItem));

                if (spinnerSortBy !=null)
                    selectedSort=spinnerSortBy.getSelectedItemPosition();
                //sach resetAll select
                resetAllTextView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (spinnerSortBy!=null)
                            spinnerSortBy.setSelection(0);
                    }
                });
                //sach Sort  CANCEL button
                sortcancelbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(selectedSort>=0)
                        {
                            spinnerSortBy.setSelection(selectedSort);
                        }
                        sortDialogue.dismiss();
                    }

                });
                //sach Sort APPLY button
                sortApplybutton.setOnClickListener(new View.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public void onClick(View v) {
                        Log.d("sach_sortby:", sortByItem);
                        sortingOptions= organizationService.updateCategorySortList(sortByItem, sortingOptions);
                        Log.d("size:",sortingOptions.getBoxChecked().size()+"");
                        //organizationService.updateServiceList(getActivity(),finalOrganizationDescriptionArrayList, clTemp, bottomsheetview, sortingOptions,null,mMap,m,serviceListView);
                        sortDialogue.dismiss();
                    }
                });

            }});

        //sach - EXCEUTING filter button activity 2 - same as the below filter.setOnClickListner
        filter.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongViewCast")
            @Override
            public void onClick(View v) {
                Log.d("sach_filterButton","Clicked2:Yes");
                final Dialog filterDialogue = new Dialog(getActivity());
                filterDialogue.setContentView(R.layout.filterlistdialogue);
                filterDialogue.setTitle("Filters");
                filterDialogue.setCancelable(false);
                resetAllTextView=(TextView) filterDialogue.findViewById(R.id.reset_all);
                filterApplybutton = (Button) filterDialogue.findViewById(R.id.applybutton);
                filtercancelbutton = (Button) filterDialogue.findViewById(R.id.cancelbutton);
                categoryListview = (ExpandableListView) filterDialogue.findViewById(R.id.checkboxlistexpamdable);
                openNowVerticleLayout = (LinearLayout) filterDialogue.findViewById(R.id.openNowLayout);//sach_added
                inputDateEditText = (EditText) filterDialogue.findViewById(R.id.input_date_EditText);//sach_added
                inputTimeEditText =(EditText) filterDialogue.findViewById(R.id.input_time_EditText);//sach_added
                inputDistanceEditText = (EditText) filterDialogue.findViewById(R.id.input_distanceEditText);//sach_added
                openNowSwitch = (Switch) filterDialogue.findViewById(R.id.openNowSwitch);//sach_added


                final ArrayList<CategoryList> tempCategoryList=new ArrayList<CategoryList>();
                tempCategoryList.addAll(categoryLists1);
                myExpandableListAdapter = new MyExpandableListAdapter(getActivity(), tempCategoryList);

                filterDialogue.setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                        // Prevent dialog close on back press button
                        if(keyCode == KeyEvent.KEYCODE_BACK)
                            filterDialogue.dismiss();
                        return keyCode == KeyEvent.KEYCODE_BACK;
                    }
                });

                categoryListview.setAdapter(myExpandableListAdapter);
////Sort start
                spinnerSortBy = (Spinner) filterDialogue.findViewById(R.id.spinner_sortby);
                spinnerSortBy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        sortByItem = parent.getItemAtPosition(position).toString();
                        //updateCategorySortList(sortByItem);
                        Log.d("sach_sortByItem",sortByItem);
                        //sach - to make openNow date time distance layout / visible invisible with category option
                        /*
                        switch (sortByItem){
                            case "Alphabetically":
                                openNowVerticleLayout.setVisibility(View.GONE);
                                break;
                            case "Distance":
                                openNowVerticleLayout.setVisibility(View.GONE);
                                break;
                            case "Frequently Used":
                                openNowVerticleLayout.setVisibility(View.GONE);
                                break;
                            default:
                                openNowVerticleLayout.setVisibility(View.VISIBLE);
                                inputDateEditText.setText("");
                                inputTimeEditText.setText("");
                                inputDistanceEditText.setText("");
                                break;
                        }
                        */
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

                //open at on clicked
                openNowSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if(isChecked){
                            openNowSwitch.setText("Open at");
                            openNowVerticleLayout.setVisibility(View.VISIBLE);
                            inputDateEditText.setText("");
                            inputTimeEditText.setText("");
                            inputDistanceEditText.setText("");

                        }else{
                            openNowSwitch.setText("Open now");
                            openNowVerticleLayout.setVisibility(View.GONE);
                            inputDateEditText.setText("");
                            inputTimeEditText.setText("");
                            inputDistanceEditText.setText("");
                        }
                        sortingOptions.setOpenNowSwitch(isChecked);
                        Log.d("sach_opennowSwitch", String.valueOf(sortingOptions.getOpenNowSwitch()));

                    }
                });

                //sach_ set spinner adapter to sorting option list
                ArrayAdapter sortAdapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, sortingOptions.getOptions());
                sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerSortBy.setAdapter(sortAdapter);

                if (sortByItem!=null)
                    spinnerSortBy.setSelection(sortingOptions.getOptions().indexOf(sortByItem));

                ArrayList<CategoryList> cancelCategoryAdapterList = myExpandableListAdapter.getCategoryList();

                checkBoxBooleanList=new HashMap<String,Boolean>();
                if(cancelCategoryAdapterList!=null)
                {
                    for (int i = 0; i < cancelCategoryAdapterList.size(); i++) {
                        for (int j = 0; j < cancelCategoryAdapterList.get(i).getBoxChecked().size(); j++) {
                            if(!checkBoxBooleanList.containsKey(cancelCategoryAdapterList.get(i).getOptions().get(j)))
                            {
                                checkBoxBooleanList.put(cancelCategoryAdapterList.get(i).getOptions().get(j),cancelCategoryAdapterList.get(i).getBoxChecked().get(j));
                            }
                        }
                    }
                }

                Log.d("sach_CancelCate", String.valueOf(cancelCategoryAdapterList));
                Log.d("sach_CancelCate2", String.valueOf(checkBoxBooleanList));

                if (spinnerSortBy !=null)
                    selectedSort=spinnerSortBy.getSelectedItemPosition();

                //sach_resetAll clicked
                resetAllTextView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                        //Log.d("sach_clTemp", String.valueOf(myExpandableListAdapter.getCategoryList()));
                        if(clTemp!=null)
                        {
                            for (int i = 0; i < clTemp.size(); i++) {
                                for (int j = 0; j < clTemp.get(i).getBoxChecked().size(); j++) {
                                    Log.d("sach_clTemp3", String.valueOf(clTemp.get(i).getBoxChecked().size()));
                                    //sach make checkbox all true
                                    myExpandableListAdapter.getCategoryList().get(i).getBoxChecked().set(j,new Boolean(true) );
                                    ((BaseAdapter) categoryListview.getAdapter()).notifyDataSetChanged();
                                }
                            }
                        }
                        if (spinnerSortBy!=null)
                            spinnerSortBy.setSelection(0);


                    }
                });

                //sach_cancel button clicked
                filtercancelbutton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                        if(clTemp!=null)
                        {
                            for (int i = 0; i < clTemp.size(); i++) {
                                for (int j = 0; j < clTemp.get(i).getBoxChecked().size(); j++) {
                                    myExpandableListAdapter.getCategoryList().get(i).getBoxChecked().set(j, checkBoxBooleanList.get(myExpandableListAdapter.getCategoryList().get(i).getOptions().get(j)));
                                    ((BaseAdapter) categoryListview.getAdapter()).notifyDataSetChanged();
                                }
                            }
                        }
                        if(selectedSort>=0)
                        {
                            spinnerSortBy.setSelection(selectedSort);
                        }
                        //sach need to update here with open now remain
                        filterDialogue.dismiss();

                    }

                });

                //sach_Apply button clicked
                filterApplybutton.setOnClickListener(new View.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public void onClick(View v) {
                        ArrayList<CategoryList> clTemp = myExpandableListAdapter.getCategoryList();
                        Log.d("sach_sortby2:", sortByItem);
                        //sach_added opennow cirteria Array - do only when Open Now clicked

                        selectedTime = String.valueOf(inputTimeEditText.getText());
                        selectedDistance = String.valueOf(inputDistanceEditText.getText());

                        sortingOptions.getOpenNowOptions().clear();

                        sortingOptions.getOpenNowOptions().add(selectedDate);
                        sortingOptions.getOpenNowOptions().add(selectedTime);
                        sortingOptions.getOpenNowOptions().add(selectedDistance);


                        Log.d("sach_openNowOptionsA", String.valueOf(sortingOptions.getOpenNowOptions()));
                        /*
                        if(inputDateEditText.getText().equals("") || inputTimeEditText.getText().equals("")|| inputDistanceEditText.getText().equals("")){
                            Toast.makeText(getActivity(),"Select date time and distance ! ",Toast.LENGTH_LONG ).show();
                            sortingOptions.getOpenNowOptions().clear();
                        }else{
                            ////////////

                            sortingOptions.getOpenNowOptions().clear();
                            //sach update open now option array (DATE , Time, Distanceblock)
                            sortingOptions.getOpenNowOptions().add(selectedDate);
                            sortingOptions.getOpenNowOptions().add(selectedTime);
                            sortingOptions.getOpenNowOptions().add(selectedDistance);

                            Log.d("sach_openNowOptions", String.valueOf(sortingOptions.getOpenNowOptions().size()));
                            Log.d("sach_openNowOptionsA", String.valueOf(sortingOptions.getOpenNowOptions()));
                            Log.d("sach_sortbysize2:",sortingOptions.getBoxChecked().size()+"");
                        }

                         */
                          //////////////
                        sortingOptions= organizationService.updateCategorySortList(sortByItem, sortingOptions);
                        organizationService.updateServiceList(getActivity(),finalOrganizationDescriptionArrayList, clTemp, bottomsheetview, sortingOptions,null,mMap,m,serviceListView);
                        filterDialogue.dismiss();

                    }
                });


                categoryListview.expandGroup(0);
                categoryListview.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                    @Override
                    public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                        CategoryList categoryGroup = categoryLists1.get(groupPosition);
                        String checkboxItem = categoryGroup.getOptions().get(childPosition);
                        return false;
                    }
                });

                categoryListview.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
                    @Override
                    public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                        CategoryList categoryGroup = categoryLists1.get(groupPosition);

                        return false;
                    }
                });

                filterDialogue.show();

                //sach - time picker functionality
                inputTimeEditText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        TimePickerDialog timePickerDialog = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                //sach show AM-PM inside TimePickerDialog and EditText.
                                /*
                                String amPm;
                                if(hourOfDay>=12) {
                                    amPm = "PM";
                                }else {
                                    amPm = "AM";
                                }
                                */
                                // appears like this (hh:mm).
                                inputTimeEditText.setText(String.format("%02d:%02d",hourOfDay,minute));

                            }
                        },Calendar.getInstance().get(Calendar.HOUR_OF_DAY),Calendar.getInstance().get(Calendar.MINUTE),false);

                        timePickerDialog.show();
                        //selectedTime = String.valueOf(inputTimeEditText.getText());
                    }
                });

                //sach - date picker functionality new
                inputDateEditText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showDatePickerDialog();
                        /*
                        ZoneId z =ZoneId.of("-05:00");
                        ZonedDateTime zdt = ZonedDateTime.now(z);
                        DayOfWeek dow = zdt.getDayOfWeek();
                        Locale locale = Locale.US;
                        String output = dow.getDisplayName(TextStyle.SHORT,locale);
                        Calendar c = GregorianCalendar.from(zdt);
                        Instant instant = zdt.toInstant() ;
                        java.util.Date myJavaUtilDate = java.util.Date.from( instant ) ;
                        inputDateEditText.setText(output);
                       */

                    }
                });
                //inputDatelistner = CustomDateTimePicker.getCustomDatePicker(inputDateEditText,null,myCalander);

                //sach - distance selection
                inputDistanceEditText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Dialog descriptionCardView = new Dialog(filterDialogue.getContext());
                        descriptionCardView.setContentView(R.layout.sach_distance_select_card);
                        int width = (int) (getContext().getResources().getDisplayMetrics().widthPixels * 0.50);
                        descriptionCardView.getWindow().setLayout(width,ViewGroup.LayoutParams.WRAP_CONTENT);

                        defaultTV = (TextView) descriptionCardView.findViewById(R.id.defaultTextView);//sach_added
                        onemileTV =(TextView) descriptionCardView.findViewById(R.id.oneMileTextView);//sach_added
                        twomilesTV = (TextView) descriptionCardView.findViewById(R.id.twoMileTextView);//sach_added
                        threemilesTV = (TextView) descriptionCardView.findViewById(R.id.threeMileTextView);//sach_added

                        defaultTV.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                inputDistanceEditText.setText(defaultTV.getText().toString());
                                descriptionCardView.dismiss();
                            }
                        });
                        onemileTV.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                inputDistanceEditText.setText(onemileTV.getText().toString());
                                descriptionCardView.dismiss();
                            }
                        });
                        twomilesTV.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                inputDistanceEditText.setText(twomilesTV.getText().toString());
                                descriptionCardView.dismiss();
                            }
                        });
                        threemilesTV.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                inputDistanceEditText.setText(threemilesTV.getText().toString());
                                descriptionCardView.dismiss();
                            }
                        });


                        descriptionCardView.show();
                        //selectedDistance = String.valueOf(inputDistanceEditText.getText());
                    }

                });

            }
        });

        //sach added - to save the searched list corresponding to user entered keyword and keep the list when back pressed
        searchbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchedText = organizationAutoTextView.getText().toString();
                combinedNameDescriptionArrayListSearched.clear();
                //int count = 0;
                /* Filter corresponding items (Orgname + address) from combinedDescriptionArrayList and send it to Search Results*/
                for(String item : combinedNameDescriptionArrayList){
                    if(!searchedText.matches("") && item.toLowerCase().contains(searchedText.toLowerCase())){
                        //count ++;
                        combinedNameDescriptionArrayListSearched.add(item);
                    }
                }

                if(combinedNameDescriptionArrayListSearched.isEmpty()){
                    combinedNameDescriptionArrayListSearched.add("No results! Enter a search word!");
                }
                //Log.d("*COUNT*", String.valueOf(count));
                Intent intent = new Intent(getActivity(),SearchActivity.class);
                intent.putExtra("searched", combinedNameDescriptionArrayListSearched);
                startActivity(intent);

                organizationAutoTextView.setText("");

            }
        });


    }

    //sach added
    private void showDatePickerDialog(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
                );
          String day = Calendar.getInstance().getDisplayName(Calendar.DAY_OF_WEEK,Calendar.SHORT,Locale.US);
          selectedDate = day;
          Log.d("sach", String.valueOf(day)); //always instant day Sat , Mon etc. ******need to change

        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
        datePickerDialog.show();
    }
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String date = month+1 +"/" + dayOfMonth+"/"+year;
        inputDateEditText.setText(date);
    }

    protected synchronized void bulidGoogleApiClient() {
        client = new GoogleApiClient.Builder(this.getActivity()).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
        client.connect();

    }
    //sach- On current location change update
    @Override
    public void onLocationChanged(Location location) {

        latitude = location.getLatitude();
        longitude = location.getLongitude();
        System.out.println("-x-x-x-x-x-x | \uD83C\uDF54\uD83C\uDF54\uD83C\uDF54 Location information update[ Lat: " + latitude + " Long: " + longitude + "].");
        lastlocation = location;
        if (currentLocationmMarker != null) {
            currentLocationmMarker.remove();

        }

        LatLng Ualbany = new LatLng(latitude, longitude);  //DEMO Purpouse
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Ualbany)); //DEMO Purpouse


        Gson gson = new Gson();

        // Get java object list json format string.
        String locationString = gson.toJson(lastlocation);

        // Create SharedPreferences object.
        Context ctx = getActivity();
        SharedPreferences sharedPreferences = ctx.getSharedPreferences("currentlocation", MODE_PRIVATE);

        // Put the json format string to SharedPreferences object.
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("currentlocation1", locationString);
        editor.commit();

        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        currentlocation= latLng;

        if (client != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(client, this);
        }
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onConnected(@Nullable Bundle bundle) {

        locationRequest = new LocationRequest();
        locationRequest.setInterval(100);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);



        if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(client, locationRequest, this);
        }
    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this.getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this.getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            } else {
                ActivityCompat.requestPermissions(this.getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            }
            return false;

        } else
            return true;
    }

    @Override
    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    public void onResume() {
        super.onResume();


    }


    @Override
    public void onPause() {
        super.onPause();
        onPauseOrganizationlistener();
    }

    @Override
    public void onCameraIdle() {
        int limitedDistance = 20;
        int limitedOrganizations = 5;
        NearByRequestDao nearbyRequest = new NearByRequestDao(
                mMap.getCameraPosition().target.latitude,
                mMap.getCameraPosition().target.longitude,
                limitedDistance, limitedOrganizations
        );
        ObjectMapper mapper = new ObjectMapper();
        try {
            String nearByOrganizationsJson =
                    new HttpNearbyHandler().execute(mapper.writeValueAsString(nearbyRequest)).get();
            Log.d("sach_nearby",nearByOrganizationsJson);
            if (!nearByOrganizationsJson.equals("")) {
                List<Organization> organizations = mapper.readValue(
                                nearByOrganizationsJson,
                                new TypeReference<List<Organization>>() {});

            }

        } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
            e.printStackTrace();
        }
    }


    //
    private class GetCourseCategoriesMarkerColor extends AsyncTask<Void, Void, Void> {

        ProgressDialog progressDialog;

        @Override
        //sach- Showing progress loading dialog
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress loading dialog
            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setMessage("Loading map...");
            progressDialog.setCancelable(false);
            progressDialog.show();
            Log.d("sach_Loading","Yes");

        }

        //*sach : this is where the all dots are printed on the map. "finalorganizationDescriptionArrayList" is the big arraylist with all organizations
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                // instead of using the old fetching list function
                 finalOrganizationDescriptionArrayList = organizationService.getOrganizationDescriptionList(getActivity());
                // use the new one
//                organizations = organizationService.getOrganizationsFromBackend(getActivity());
            } catch (IOException e) {
                e.printStackTrace();
            }
            cl1.setCategoryName("Categories");//sach_"Categories" word in Filters cardview
            categories = new ArrayList<String>();
            //Log.d("sach_categories","categories.");
            asynkBackGraoundMethod();
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            try {
                Log.d("sach_post exex","started.");
                asynkPostExecuteMethod();
                Log.d("sach_post async ","done.");
                organizationService.updateServiceList(getActivity(),finalOrganizationDescriptionArrayList, categoryLists1, bottomsheetview, sortingOptions,null,mMap,m,serviceListView);
                Log.d("sach_post update li","done.");
                //   firstTime=false;
                if (progressDialog.isShowing())
                    progressDialog.dismiss();
            } catch (Exception e) {
            }
        }
    }


    public void asynkBackGraoundMethod()
    {
        organizationService.setMarkerToList(getActivity(),finalOrganizationDescriptionArrayList, categories,serviceAutoListOrganisation,descriptionOrgArrayList,combinedNameDescriptionArrayList,categoryListColor,lastlocation);

        ArrayList<Boolean> isBoxCheckedList = new ArrayList<Boolean>();
        for (int i = 0; i < categories.size(); i++) {
            isBoxCheckedList.add(new Boolean(true));
        }
        cl1.setBoxChecked(isBoxCheckedList);
        Collections.sort(categories);
        cl1.setOptions(categories);
        if (categoryLists1.size()>0)
            categoryLists1.clear();
        categoryLists1.add(cl1); //sach _category list refreshes here as per the check box
        //Log.d("sach_Cl1Ogj", cl1.getOptions().toString());
        //Log.d("sach_categorylist1", String.valueOf(categoryLists1));

        if(finalOrganizationDescriptionArrayList!=null)
            Log.d("sach_FinalOrganization","DescriptionArrayList:cl added:"+finalOrganizationDescriptionArrayList.size());
    }

    public  void asynkPostExecuteMethod()
    {
        try {
            if (serviceAutoListOrganisation!=null  && finalOrganizationDescriptionArrayList!=null && finalOrganizationDescriptionArrayList.size()>0)
            {
                if (organizationAutoTextView==null)
                {
                    organizationAutoTextView= view.findViewById(R.id.Organization_name_searchview);
                }
                if(organizationAutoAdapter==null)
                {
                    /*
                    for(String searchNameDes:combinedNameDescriptionArrayList)
                    {
                        getOrganizationTitlesArrayToSearch(searchNameDes);
                    }
                    // remove duplicates from titles
                    Set<String > set = new HashSet<>(combinedNameDescriptionArrayListTitles);
                    combinedNameDescriptionArrayListTitles.clear();
                    combinedNameDescriptionArrayListTitles.addAll(set);
                    Log.d("sach_Title", String.valueOf(combinedNameDescriptionArrayListTitles));
                    Log.d("sach_SIZE2 ", String.valueOf(combinedNameDescriptionArrayListTitles.size()));
                     */

                    organizationAutoAdapter = new ArrayAdapter<String>(getActivity(),R.layout.my_select_dialog_item, combinedNameDescriptionArrayList);
                    organizationAutoTextView.setAdapter(organizationAutoAdapter);
                    organizationAutoTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            String selectedItemText = parent.getItemAtPosition(position).toString();
                            OrganizationDescription organizationDescriptionObj = organizationService.findLocationDescriptionObject(selectedItemText,finalOrganizationDescriptionArrayList);
                            if (organizationDescriptionObj !=null)
                            {
                                Intent intent = new Intent(getActivity(), ViewServices.class);
                                intent.putExtra("serviceObject", organizationDescriptionObj);
                                startActivity(intent);
                            }
                            //sach_remove search word after selecting from the list
                            organizationAutoTextView.setText("");

                        }
                    });
                }
                else {
                    organizationAutoAdapter.notifyDataSetChanged();
                }
            }
            filter.setEnabled(true);
        }
        catch (Exception e) {
        }
    }
    /*
    //sach_get object description as per the org name & description [searched list items] & update Title ONLY arraylist to show in search
    private OrganizationDescription getOrganizationTitlesArrayToSearch(String arrayItem ) {
        if (finalOrganizationDescriptionArrayList==null)
            return null;
        for(OrganizationDescription locDescObj:finalOrganizationDescriptionArrayList)
        {
            if (locDescObj.getOrganizationName().equals(arrayItem) || locDescObj.getDescription().equals(arrayItem))
            {
                combinedNameDescriptionArrayListTitles.add(locDescObj.getOrganizationName());
            }
        }
        Log.d("sach_Content ", String.valueOf(combinedNameDescriptionArrayListTitles));
        return null;
    }
     */

    private void onSignedInInitialize()
    {
        attachDatabaseReadListner();
    }

    private void attachDatabaseReadListner()
    {


    }

    public void onResumeOrganizationlistener()
    {

    }

    public void onPauseOrganizationlistener()
    {

    }

}

