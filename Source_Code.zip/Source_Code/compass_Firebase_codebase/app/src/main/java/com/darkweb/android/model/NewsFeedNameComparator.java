package com.darkweb.android.model;


import android.util.Log;

import java.util.Comparator;

/**
 * Created by kotak on 08/08/2018.
 */

public class NewsFeedNameComparator implements Comparator<Object> {
    @Override
    public int compare(Object o1, Object o2) {
        if(o1 instanceof  CalandarEvent && o2 instanceof  CalandarEvent)
        {
            Log.d("name:",""+((CalandarEvent)o1).getEventName().compareTo(((CalandarEvent)o2).getEventName())+" o1:"+((CalandarEvent)o1).getEventName()+ " o2:"+((CalandarEvent)o2).getEventName());
            return ((CalandarEvent)o1).getEventName().compareTo(((CalandarEvent)o2).getEventName());
        }
        else if(o1 instanceof  CalandarEvent && o2 instanceof  ServiceDetails)
        {
            //return ((CalandarEvent)o1).getEventName().compareTo(((ServiceDetails)o2).getServiceRequestName()); //sach changed
            return ((CalandarEvent)o1).getEventName().compareTo(((ServiceDetails)o2).getTitle());
        }
        else if(o1 instanceof  ServiceDetails && o2 instanceof  CalandarEvent)
        {
            //return ((ServiceDetails)o1).getServiceRequestName().compareTo(((CalandarEvent)o2).getEventName()); //sach changed
            return ((ServiceDetails)o1).getTitle().compareTo(((CalandarEvent)o2).getEventName());
        }
        else if(o1 instanceof  ServiceDetails && o2 instanceof  ServiceDetails)
        {
            //return ((ServiceDetails)o1).getServiceRequestName().compareTo(((ServiceDetails)o2).getServiceRequestName());//sach changed
            return ((ServiceDetails)o1).getTitle().compareTo(((ServiceDetails)o2).getTitle());
        }

        return 0;
    }
}
