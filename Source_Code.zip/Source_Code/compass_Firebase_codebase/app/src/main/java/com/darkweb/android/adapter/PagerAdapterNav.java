package com.darkweb.android.adapter;

/**
 * Created by kotak on 19/08/2018.
 */

import android.content.Context;
import android.os.Bundle;


import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import android.util.Log;


import com.darkweb.android.agri.Form_tab;
import com.darkweb.android.agri.Records;
import com.darkweb.android.agri.UploadAll_tab;
import com.darkweb.android.compass.Service_tab;
import com.darkweb.android.compass.SettingFragment;
import com.darkweb.android.compass.volunteer_tab;
import com.darkweb.android.login.ProfilePageFragment;
import com.darkweb.android.compass.FragmentCalendarView;
import com.darkweb.android.compass.FragmentHome;
import com.darkweb.android.compass.FragmentNewsFeed;
import com.darkweb.android.compass.R;

public class PagerAdapterNav extends FragmentStatePagerAdapter {
    int mNumOfTabs;
    Context context;
    private FragmentCalendarView fragmentCalendarView;
    Toolbar toolbar;

    public PagerAdapterNav(FragmentManager fm, int NumOfTabs, Context context, Toolbar toolbar) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
        this.context=context;
        this.toolbar=toolbar;
    }

    //sach - Define and return whole fragment postions from 1 to 7
    @Override
    public Fragment getItem(int position) {

        Log.d("sach_position home:",position+"");


        switch (position) {
            case 0:
                return new Form_tab();
               // return new FragmentHome();
            case 1:
                return new Records(); //UploadAll_tab(); //Service_tab();
            case 2:
                //Log.d("AGRI_navigation view", "Clicked");
               return new SettingFragment();

/*            case 3:
                Bundle bundle = new Bundle();
                bundle.putString(context.getString(R.string.fragment_string), context.getString(R.string.Volunteer_Oppurtunity));
                fragmentCalendarView=new FragmentCalendarView();
                fragmentCalendarView.setArguments(bundle);
                return fragmentCalendarView;
            case 4:
                return new FragmentNewsFeed();
            case 5:
                bundle = new Bundle();
                bundle.putString(context.getString(R.string.fragment_string), context.getString(R.string.My_Volunteer_services));
                fragmentCalendarView = new FragmentCalendarView();
                fragmentCalendarView.setArguments(bundle);
                return fragmentCalendarView;
            case 6:
                return new ProfilePageFragment();
            case 7:
                return new SettingFragment();*/
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}