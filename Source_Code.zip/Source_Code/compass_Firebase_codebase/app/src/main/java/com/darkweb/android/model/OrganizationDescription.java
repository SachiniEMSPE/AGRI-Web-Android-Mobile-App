package com.darkweb.android.model;

import androidx.annotation.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class OrganizationDescription implements Serializable,Comparable<OrganizationDescription> {

	private static final long serialVersionUID=1L;
	String organizationUID;
	String organizationName;
	String description;
	String styleURL;
	String contact;
	String hours;
	String emailId;
	String longitude;
	String latitude;
	String streetAddress;
	String city;
	String state;
	String zipcode;
	String languages;//sach_added
	String organizationID;//sach added
	Integer serviceID; //sach added

	String category;
	String website;
	float markerColor=0.0F;

	ArrayList<CalandarEvent> organisationEventList=new ArrayList<CalandarEvent>();
	ArrayList<String> programList;
	ArrayList<String> programUIDList; //sach added
	ArrayList<String> taxCategoryList; //sach added to put taxonomy category list
	ArrayList<ArrayList<String>> serviceList;//sach_Added
	ArrayList<ArrayList<String>> serviceUIDList;//sach added
	ArrayList<ArrayList<String>> ServiceArrayDescription;//sach_Added
	ArrayList<ArrayList<String>> ServiceArrayEligibility ;//sach_Added
	ArrayList<ArrayList<String>> ServiceArraySpecificHours;//sach_Added
	ArrayList<ArrayList<String>> ServiceArrayAdditionalReq;//sach_Added



	float distance=0.0F;
	int visitedNumber;

	public String getOrganizationUID() {
		return organizationUID;
	}

	public void setOrganizationUID(String organizationUID) {
		this.organizationUID = organizationUID;
	}

	@Override
	public String toString() {
		return "OrganizationDescription{" +
				"organizationUID='" + organizationUID + '\'' +
				"organizationID='" + organizationID + '\'' +
				", organizationName='" + organizationName + '\'' +
				", description='" + description + '\'' +
				", styleURL='" + styleURL + '\'' +
				", contact='" + contact + '\'' +
				", hours='" + hours + '\'' +
				", emailId='" + emailId + '\'' +
				", longitude='" + longitude + '\'' +
				", latitude='" + latitude + '\'' +
				", streetAddress='" + streetAddress + '\'' +
				", city='" + city + '\'' +
				", state='" + state + '\'' +
				", zipcode='" + zipcode + '\'' +
				", category='" + category + '\'' +
				", website='" + website + '\'' +
				", markerColor=" + markerColor +
				", organisationEventList=" + organisationEventList +
				", programList=" + programList +
				", serviceList=" + serviceList +
				", ServiceArrayEligibility=" + ServiceArrayEligibility +
				", ServiceArrayDescription=" + ServiceArrayDescription +
				", ServiceArraySpecificHours=" + ServiceArraySpecificHours +
				", ServiceArrayAdditionalReq=" + ServiceArrayAdditionalReq +
				", distance=" + distance +
				", visitedNumber=" + visitedNumber +
                ", taxCategoryList=" + taxCategoryList +
				", languages =" +languages +
				'}';
	}//sach_taxCategoryList included

	//sach added
	public String getOrganizationID() {
		return organizationID;
	}
	public void setOrganizationID(String organizationID) {
		this.organizationID = organizationID;
	}

	public ArrayList<String> getProgramList() {
		return programList;
	}

	public void setProgramList(ArrayList<String> programList) {
		this.programList = programList;
	}

	public ArrayList<String> getProgramUIDList() {
		return programUIDList;
	}

	public void setProgramUIDList(ArrayList<String> programUIDList) {
		this.programUIDList = programUIDList;
	}

	public ArrayList<String> getTaxCategoryList(){
	    return taxCategoryList;
    }

    public void setTaxCategoryList(ArrayList<String> taxCategoryList){
	    this.taxCategoryList = taxCategoryList;
    }

	public ArrayList<ArrayList<String>> getServiceList() {
		return serviceList;
	}

	public void setServiceList(ArrayList<ArrayList<String>> serviceList) {
		this.serviceList = serviceList;
	}

	public ArrayList<ArrayList<String>> getServiceUIDList() {
		return serviceUIDList;
	}

	public void setServiceUIDList(ArrayList<ArrayList<String>> serviceUIDList) {
		this.serviceUIDList = serviceUIDList;
	}

	//sach_added
	public ArrayList<ArrayList<String>> getServiceArrayEligibility() {
		return ServiceArrayEligibility;
	}
	public void setServiceArrayEligibility(ArrayList<ArrayList<String>> ServiceArrayEligibility) {
		this.ServiceArrayEligibility = ServiceArrayEligibility;
	}

	public ArrayList<ArrayList<String>> getServiceArrayDescription() {
		return ServiceArrayDescription;
	}
	public void setServiceArrayDescription(ArrayList<ArrayList<String>> ServiceArrayDescription) {
		this.ServiceArrayDescription = ServiceArrayDescription;
	}

	public ArrayList<ArrayList<String>> getServiceArraySpecificHours() {
		return ServiceArraySpecificHours;
	}
	public void setServiceArraySpecificHours(ArrayList<ArrayList<String>> ServiceArraySpecificHours) {
		this.ServiceArraySpecificHours = ServiceArraySpecificHours;
	}

	public ArrayList<ArrayList<String>> getServiceArrayAdditionalReq() {
		return ServiceArrayAdditionalReq;
	}
	public void setServiceArrayAdditionalReq(ArrayList<ArrayList<String>> ServiceArrayAdditionalReq) {
		this.ServiceArrayAdditionalReq = ServiceArrayAdditionalReq;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public ArrayList<CalandarEvent> getOrganisationEventList() {
		return organisationEventList;
	}

	public void setOrganisationEventList(ArrayList<CalandarEvent> organisationEventList) {
		this.organisationEventList = organisationEventList;
	}

	public float getDistance() {

		return distance;
	}

	public void setDistance(float distance) {


		this.distance = distance;
	}

	public int getVisitedNumber() {
		return visitedNumber;
	}

	public void setVisitedNumber(int visitedNumber) {
		this.visitedNumber = visitedNumber;
	}

	public float getMarkerColor() {
		return markerColor;
	}

	public void setMarkerColor(float markerColor) {
		this.markerColor = markerColor;
	}

	public String getStreetAddress() {
		return streetAddress;
	}
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStyleURL() {
		return styleURL;
	}
	public void setStyleURL(String styleURL) {
		this.styleURL = styleURL;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getLanguages(){return languages;} //sach_added
	public void setLanguages(String languages){this.languages = languages;}//sach_added

	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}

	@Override
	public int compareTo(@NonNull OrganizationDescription organizationDescription) {

		return 0;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		OrganizationDescription that = (OrganizationDescription) o;
		return Float.compare(that.markerColor, markerColor) == 0 &&
				Float.compare(that.distance, distance) == 0 &&
				visitedNumber == that.visitedNumber &&
				Objects.equals(organizationUID, that.organizationUID) &&
				Objects.equals(organizationName, that.organizationName) &&
				Objects.equals(description, that.description) &&
				Objects.equals(styleURL, that.styleURL) &&
				Objects.equals(contact, that.contact) &&
				Objects.equals(hours, that.hours) &&
				Objects.equals(emailId, that.emailId) &&
				Objects.equals(longitude, that.longitude) &&
				Objects.equals(latitude, that.latitude) &&
				Objects.equals(streetAddress, that.streetAddress) &&
				Objects.equals(city, that.city) &&
				Objects.equals(state, that.state) &&
				Objects.equals(zipcode, that.zipcode) &&
				Objects.equals(category, that.category) &&
				Objects.equals(website, that.website) &&
				Objects.equals(organisationEventList, that.organisationEventList) &&
				Objects.equals(programList, that.programList) &&
				Objects.equals(serviceList, that.serviceList)&&
				Objects.equals(languages,that.languages); //sach_added
	}

	@Override
	public int hashCode() {
		//sach_updated with languages
		return Objects.hash(organizationUID, organizationName, description, styleURL, contact, hours, emailId, longitude, latitude, streetAddress, city, state, zipcode, category, website, markerColor, organisationEventList, programList, serviceList, distance, visitedNumber,languages);
	}
}
