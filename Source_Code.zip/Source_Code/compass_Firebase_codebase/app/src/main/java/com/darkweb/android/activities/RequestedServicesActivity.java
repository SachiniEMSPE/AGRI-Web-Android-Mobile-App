package com.darkweb.android.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.darkweb.android.adapter.RequestedServiceListAdapter;
import com.darkweb.android.compass.R;
import com.darkweb.android.dialogs.ServiceFilterDialog;
import com.darkweb.android.global.MyGlobalVars;
import com.darkweb.android.model.ObjectsForMapper.RequestedServiceStatus;
import com.darkweb.android.model.ObjectsForMapper.ServicesFilters;
import com.darkweb.android.model.RequestedService;
import com.darkweb.android.service.HttpHandlers.RequestedServicesHandler;
import com.darkweb.android.service.HttpHandlers.RequestsFilterHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

public class RequestedServicesActivity
        extends AppCompatActivity implements ServiceFilterDialog.ServiceFilterDialogListener {

    SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
    int local_user_id = sp.getInt("MobileClientID", 0);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // basic layout
        setContentView(R.layout.activity_requested_services_list);

        // tool bar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        String result = "";
        try {
            // sending user id to backend end, and get the JSON data back
            result = new RequestedServicesHandler().execute(Integer.toString(local_user_id), "client").get();
            if (!result.equals("")) {
                ObjectMapper mapper = new ObjectMapper();
                try {
                    List<RequestedService> requestedServices = mapper.readValue(result, new TypeReference<List<RequestedService>>() {});
                    ListView requestedServicesListView = findViewById(R.id.requested_services);
                    // Render the list above to view
                    RequestedServiceListAdapter adapter = new RequestedServiceListAdapter(
                            this, R.layout.adapter_requested_list_layout, requestedServices
                    );
                    requestedServicesListView.setAdapter(adapter);
                    // Add event listener for each requested service
                    requestedServicesListView.setOnItemClickListener((adapterView, view, i, l) -> {
                        int requestedId = requestedServices.get(i).getRequestedServiceId();
                        // Open another activity page, send the request id to that page
                        Intent intent = new Intent(RequestedServicesActivity.this, RequestedServiceActivity.class);
                        intent.putExtra("requested_id", requestedId);
                        startActivity(intent);
                    });

                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }
            }
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        ImageButton filterIcon = findViewById(R.id.filterservices);
        filterIcon.setOnClickListener(view -> openDialog());
    }

    private void openDialog() {
        ServiceFilterDialog dialog = new ServiceFilterDialog();
        dialog.show(getSupportFragmentManager(), "Services Filter");
    }
    
    @Override
    public void applyFilter(List<RequestedServiceStatus> checkedOptions, String sortByWhat) {
        ServicesFilters filter = new ServicesFilters(local_user_id, checkedOptions, sortByWhat);
        ObjectMapper mapper = new ObjectMapper();

        try {
            String filteredResult =
                    new RequestsFilterHandler().execute(mapper.writeValueAsString(filter)).get();
            System.out.println(filteredResult);
            if (!filteredResult.equals("")) {
                List<RequestedService> filteredRequests = mapper.readValue(filteredResult, new TypeReference<List<RequestedService>>() {});
                ListView requestedServicesListView = findViewById(R.id.requested_services);
                // Render the list above to view
                RequestedServiceListAdapter adapter = new RequestedServiceListAdapter(
                        this, R.layout.adapter_requested_list_layout, filteredRequests
                );
                requestedServicesListView.setAdapter(adapter);
                // Add event listener for each requested service
                requestedServicesListView.setOnItemClickListener((adapterView, view, i, l) -> {
                    int requestedId = filteredRequests.get(i).getRequestedServiceId();
                    // Open another activity page, send the request id to that page
                    Intent intent = new Intent(RequestedServicesActivity.this, RequestedServiceActivity.class);
                    intent.putExtra("requested_id", requestedId);
                    startActivity(intent);
                });
            }
        } catch (JsonProcessingException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
