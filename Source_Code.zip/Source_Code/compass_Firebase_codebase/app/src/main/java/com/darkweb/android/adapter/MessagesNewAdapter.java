package com.darkweb.android.adapter;



import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.Message;
import com.darkweb.android.model.MessageMapper.ClientMessage;

import java.util.List;

/**
 * replacing MessageListAdapter
 */
public class MessagesNewAdapter extends RecyclerView.Adapter {
    private static final int VIEW_TYPE_MESSAGE_SENT = 1;
    private static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;

    private List<ClientMessage> messages;
    private Context mContext;

    public MessagesNewAdapter(Context context, List<ClientMessage> messages) {
        mContext = context;
        this.messages = messages;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == VIEW_TYPE_MESSAGE_SENT) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message_chat_client, parent, false);
            return new SentMessageHolder(view);
        } else {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message_chat_organization, parent, false);
            return new ReceivedMessageHolder(view);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ClientMessage message = messages.get(position);
        if (holder.getItemViewType() == VIEW_TYPE_MESSAGE_SENT) {
            ((SentMessageHolder) holder).bind(message);
        } else {
            ((ReceivedMessageHolder) holder).bind(message);
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    @Override
    public int getItemViewType(int position) {
        ClientMessage message = messages.get(position);
        if (message.getClientFrom() != null) {
            return VIEW_TYPE_MESSAGE_SENT;
        } else {
            return VIEW_TYPE_MESSAGE_RECEIVED;
        }
    }

    private class SentMessageHolder extends RecyclerView.ViewHolder {
        TextView msgBody, timeText, nameText;
        SentMessageHolder(View view) {
            super(view);
            msgBody = view.findViewById(R.id.text_message_body);
        }
        void bind(ClientMessage message) {
            msgBody.setText(message.getContent());
        }
    }

    private class ReceivedMessageHolder extends RecyclerView.ViewHolder {
        TextView msgBody, timeText, nameText;
        ReceivedMessageHolder (View view) {
            super(view);
            msgBody = view.findViewById(R.id.text_message_body);
        }
        void bind(ClientMessage message) {
            msgBody.setText(message.getContent());
        }
    }
}
