package com.darkweb.android.compass.fragments;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.annotation.*;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.darkweb.android.activities.FileUploadActivity;
import com.darkweb.android.compass.HomePage;
import com.darkweb.android.compass.R;
import com.darkweb.android.model.FeedBackDetails;
import com.darkweb.android.model.ObjectsForMapper.Program;
import com.darkweb.android.model.ObjectsForMapper.RequestStatus;
import com.darkweb.android.model.ObjectsForMapper.RequestedServiceDetail;
import com.darkweb.android.model.ObjectsForMapper.Service;
import com.darkweb.android.model.ObjectsForMapper.UpdateStatusPayload;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.service.HttpHandlers.HttpRequestUpdateHandler;
import com.darkweb.android.service.HttpHandlers.RequestedServicesHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;
import org.qap.ctimelineview.TimelineRow;
import org.qap.ctimelineview.TimelineViewAdapter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

import at.blogc.android.views.ExpandableTextView;
import io.github.kobakei.materialfabspeeddial.FabSpeedDial;
import io.github.kobakei.materialfabspeeddial.FabSpeedDialMenu;

//*sach behaviour of this is somewhat similar to ViewServices.java
// so this also contains file read/write options


public class ServiceRequested extends AppCompatActivity {

    String status = "Pending";
    ArrayList<String> DateArrayList = new ArrayList<>();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    String currentDateandTime = sdf.format(new Date());
    private ArrayList<TimelineRow> timelineRowsList = new ArrayList<>();
    ArrayAdapter<TimelineRow> myAdapter;
    ArrayList<ServiceDetails> sdList;
    ArrayList<FeedBackDetails> feedbackDetailsList;
    TextView serviceIdTextView, button_toggle2,serviceNameTextView;
    ExpandableTextView commentDetailExpandableView;

    String url;

    FabSpeedDial fab;
    final Calendar myCalendar = Calendar.getInstance();
    FeedBackDetails feedBackDetails;
    private static Dialog dialog;
    private RatingBar ratingBar;

    TextView svc_description;
    EditText comments;
    Button submitfeedback;
    private EditText updateServiceDateEditText;
    private TextView addnotificationdaysTextView,request_time,request_date,service_name,program_name;
    private View background_dimmer;
    private ImageView imageView;
    Toolbar toolbar;
    private String requestedId;
    private int local_user_id;
    private int organization_id;
    private int service_id;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        DateArrayList.add(currentDateandTime);
        for (int i = 0; i < 3; i++) {
            DateArrayList.add(currentDateandTime + "");
        }


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_requested);


        requestedId = getIntent().getSerializableExtra("requested_id").toString();
        SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        local_user_id = sp.getInt("MobileClientID", 0);
        String serverRes = "";
        try {
            serverRes = new RequestedServicesHandler().execute(requestedId, "request").get();
            // Map JSON to object
            ObjectMapper mapper = new ObjectMapper();
            RequestedServiceDetail rsd = mapper.readValue(serverRes, RequestedServiceDetail.class);

            // set organization id for file uploading activity
            organization_id = rsd.getRequest().getOrganization().getId();
            service_id = rsd.getRequest().getService();

            // Set view object one by one
            TextView organizationNameView = findViewById(R.id.organization_name_textview);
            TextView descriptiveTitleView = findViewById(R.id.descriptive_title_textView);
            TextView commentView = findViewById(R.id.comment_textView);
            TextView programNameView = findViewById(R.id.programNametextView);
            TextView serviceNameView = findViewById(R.id.serviceNametextView);

            commentDetailExpandableView = findViewById(R.id.comment_textView);
            commentDetailExpandableView.setText(rsd.getRequest().getComments());
            // Now map the object to view page
            organizationNameView.setText(rsd.getRequest().getOrganization().getName());
            descriptiveTitleView.setText(rsd.getRequest().getDescriptiveTitle());
            commentView.setText(rsd.getRequest().getComments());
            // In order to get the service description, we need to dig into the organization object
            // Same for the program name, service name
            String programNameFromObj = "N/A";
            String serviceNameFromObj = "N/A";
            for (Program p : rsd.getRequest().getOrganization().getPrograms()) {
                for (Service s : p.getServices()) {
                    if (s.getId() == rsd.getRequest().getService()) {
                        programNameFromObj = p.getName();
                        serviceNameFromObj = s.getName();
                    }
                }
            }
            programNameView.setText(programNameFromObj);
            serviceNameView.setText(serviceNameFromObj);

            // Additional text views need to be mapped
            request_time = findViewById(R.id.request_time);
            request_date = findViewById(R.id.request_date);
            request_time.setText(rsd.getRequest().getPreferredTime());
            request_date.setText(rsd.getRequest().getPreferredDate());

            // Read more
            String check = rsd.getRequest().getComments();
            button_toggle2 = findViewById(R.id.button_toggle2);  //Button for read more attribute
            if(check.length() < 41){
                button_toggle2.setText("");
            } else {
                imageView = findViewById(R.id.ImageView);
                imageView.setImageResource(R.drawable.username);

                button_toggle2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v)
                    {
                        if (commentDetailExpandableView.isExpanded())
                        {
                            commentDetailExpandableView.collapse();
                            button_toggle2.setText("Read More..");
                        }
                        else
                        {
                            commentDetailExpandableView.expand();
                            button_toggle2.setText("Read Less..");
                        }
                    }
                });
            }

            // Timeline of status update
            for (RequestStatus rs : rsd.getStatuses()) {
                timelineRowsList.add(createRandomTimelineRow(rs.getStatus().getName(), rs.getStatus().getCreatedAt(), rs.getId()));
            }

            ListView statusesTimeline = findViewById(R.id.timeline_listView);
            ArrayAdapter<TimelineRow> timelineAdapter = new TimelineViewAdapter(this, 0, timelineRowsList, false);
            statusesTimeline.setAdapter(timelineAdapter);
            statusesTimeline.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    //TODO: Open upload file window when clicked the particular timeline
                }
            });

        } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
            e.printStackTrace();
        }

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fab = findViewById(R.id.fab);
        background_dimmer = findViewById(R.id.background_dimmer);
        imageView = findViewById(R.id.ImageView);

        // config fab button
        FabSpeedDialMenu menu = new FabSpeedDialMenu(this);
        // overwrite preset icons
        menu.add("Edit request").setIcon(R.drawable.outline_create_white_18dp);
        menu.add("Recall service").setIcon(R.drawable.outline_clear_white_18dp);
        menu.add("File upload").setIcon(R.drawable.outline_upload_18dp);
        fab.setMenu(menu);
        background_dimmer.setVisibility(View.GONE);
        fab.addOnMenuItemClickListener((floatingActionButton, textView, i) -> {
            if (i == 1) {
                System.out.println("Edit request");
            } else if (i == 2) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(ServiceRequested.this);
                alertDialog.setMessage("You are about to recall this request. Do you wish to proceed?");
                alertDialog.setCancelable(true);
                alertDialog.setPositiveButton("Yes", (dialog, which) -> {
                    try {
                        UpdateStatusPayload statusPayload = new UpdateStatusPayload(
                                Integer.parseInt(requestedId), local_user_id, "recalled"
                        );
                        ObjectMapper mapper = new ObjectMapper();
                        String resultJSON = new HttpRequestUpdateHandler().execute(mapper.writeValueAsString(statusPayload)).get();
                        JSONObject result = new JSONObject(resultJSON);
                        boolean updated = result.getBoolean("success");
                        if (updated) {
                            Toast.makeText(getApplicationContext(),
                                    "Request has been recalled.", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    } catch (ExecutionException | InterruptedException | JSONException | JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    ServiceRequested.super.onBackPressed();
                });
                alertDialog.setNegativeButton("No", (dialog, which) -> Log.d("",""));
                alertDialog.show();
            } else {
                openFileUploadActivity();
            }
        });

    }

    private void openFileUploadActivity() {
        Intent intent = new Intent(this, FileUploadActivity.class);
        intent.putExtra("clientId", local_user_id);
        intent.putExtra("organizationId", organization_id);
        intent.putExtra("serviceId", service_id);
        intent.putExtra("requestedId", requestedId);
        startActivity(intent);
    }

    private FeedBackDetails getFeedbackDetailsfromFile(ServiceDetails serviceDetails) {
        final File file = new File(url, "feedbackDetails");
        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                feedbackDetailsList=(ArrayList<FeedBackDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (feedbackDetailsList!=null)
                {
                    int i=-1;
                    for (i=0;i<feedbackDetailsList.size();i++)
                    {
                        if (serviceDetails.getRequestUID().equals(feedbackDetailsList.get(i).getServiceDetails().getRequestUID()))//sach changed getServiceID>getRequestUID
                        {
                            Log.d("feedback:",feedbackDetailsList.get(i).getComments()+"");
                            return feedbackDetailsList.get(i);
                        }
                    }
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }
    


    //sach this is where the timelinerow item format.
    @SuppressLint("NewApi")
    private TimelineRow createRandomTimelineRow(String status, String date, int i){

        TimelineRow myRow = new TimelineRow(i);
        myRow.setTitle(status);
        myRow.setDescription(date);
        myRow.setImage(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_background +3 ));
        myRow.setBellowLineColor(getColor(R.color.timeLine_line));
        myRow.setBellowLineSize(6);

        myRow.setImageSize(30);

        myRow.setBackgroundColor(0xFFA4422D);
        myRow.setBackgroundSize(30);//sach changed 30 > 10
        //myRow.setImageSize(50); //sach added > not working properly
        //myRow.setBellowLineSize(30);//sach added > verticle line size change
        myRow.setDateColor(getColor(R.color.cfdialog_button_black_text_color));
        myRow.setTitleColor(getColor(R.color.cfdialog_button_black_text_color));
        myRow.setDescriptionColor(Color.GRAY);
        return myRow;
    }

    @SuppressLint("NewApi")
    private TimelineRow getTimelineRowWithNotes(String status, String notes, int i) {
        TimelineRow row = new TimelineRow(i);
        row.setTitle(status);
        row.setDescription(notes);
        row.setImage(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_background +3 ));
        row.setBellowLineColor(getColor(R.color.timeLine_line));
        row.setBellowLineSize(6);
        row.setImageSize(30);
        row.setBackgroundColor(0xFFA4422D);
        row.setBackgroundSize(30);
        row.setDateColor(getColor(R.color.cfdialog_button_black_text_color));
        row.setTitleColor(getColor(R.color.cfdialog_button_black_text_color));
        row.setDescriptionColor(getColor(R.color.cfdialog_button_black_text_color));

        return row;
    }




    @Override
    public void onBackPressed() {
        //super.onBackPressed();


        ActivityManager mngr = (ActivityManager) getSystemService( ACTIVITY_SERVICE );

        List<ActivityManager.RunningTaskInfo> taskList = mngr.getRunningTasks(10);

        if(taskList.get(0).numActivities == 1 &&
                taskList.get(0).topActivity.getClassName().equals(this.getClass().getName())) {
            Intent intent=new Intent(ServiceRequested.this, HomePage.class);
            startActivity(intent);

        }
        else
        {
            super.onBackPressed();
        }

    }

}

