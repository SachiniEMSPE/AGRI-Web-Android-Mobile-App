package com.darkweb.android.agri;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.darkweb.android.compass.R;

import java.util.ArrayList;

public class Fragment_F4 extends Fragment {


    Spinner f4_sp_offtake,f4_sp_trans;
    String [] ans_f3_sp_offtake, ans_f4_sp_trans, listItems_buyer;
    Button f3_bt_buyer;
    ArrayList<Integer> mUserItems_buyer = new ArrayList<>();
    boolean [] checkedItems_buyer;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d("Fragment ","2");
        View f4View = inflater.inflate(R.layout.ag_fragment_f4, container, false); //tab_fragment_2

        f4_sp_offtake = f4View.findViewById(R.id.f4_sp_offtake);
        f4_sp_trans = f4View.findViewById(R.id.f4_sp_trans);

        f3_bt_buyer = f4View.findViewById(R.id.f3_bt_buyer);

        f4spofftake();
        f4sptrans();
        return  f4View;
    }

    private void f4sptrans() {
        ans_f4_sp_trans = new String[]{
                "Farmer","Buyer","Other",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f4_sp_trans);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f4_sp_trans.setAdapter(memAdapter);
    }


    private void f4spofftake() {
        ans_f3_sp_offtake = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_offtake);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f4_sp_offtake.setAdapter(memAdapter);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        listItems_buyer= new String[]{
                "Market women", "Aggregation", "Middle men", "Direct sales in a market","Food processors","Other"};
        checkedItems_buyer= new boolean[listItems_buyer.length];
        f3_bt_buyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
                mBuilder.setTitle("Who own the lands you farm on?");
                mBuilder.setMultiChoiceItems(listItems_buyer, checkedItems_buyer, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                        if(isChecked){
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            if(!mUserItems_buyer.contains(position)){
                                mUserItems_buyer.add(position);
                                Log.d("**MULTI CHOICE**", mUserItems_buyer.toString());
                            }
                        }else {
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            mUserItems_buyer.remove(position);
                            Log.d("**MULTI CHOICE2**", mUserItems_buyer.toString());
                        }
                    }
                });
                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String item = "";
                        for (int i = 0; i< mUserItems_buyer.size(); i++){
                            item = item + listItems_buyer [mUserItems_buyer.get(i)];
                            if( i != mUserItems_buyer.size() -1){
                                item = item + ", ";
                            }
                        }
                        f3_bt_buyer.setText(item);
                    }
                });
                mBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                mBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for (int i = 0; i < checkedItems_buyer.length; i++){
                            checkedItems_buyer [i] = false;
                            mUserItems_buyer.clear();
                            f3_bt_buyer.setText("Select an answer");
                        }
                    }
                });

                AlertDialog mDialog = mBuilder.create();
                mDialog.show();

            }
        });

   }

}
