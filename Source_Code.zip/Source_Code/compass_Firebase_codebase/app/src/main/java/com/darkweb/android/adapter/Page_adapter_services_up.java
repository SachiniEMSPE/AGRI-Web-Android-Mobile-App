package com.darkweb.android.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.darkweb.android.agri.Fragment_F1;
import com.darkweb.android.agri.Fragment_F2;
import com.darkweb.android.agri.Fragment_F3;
import com.darkweb.android.agri.Fragment_Up1;
import com.darkweb.android.agri.Fragment_Up2;
import com.darkweb.android.compass.FragmentCalendarView;
import com.darkweb.android.compass.fragments.FragmentMyService;
//agri
public class Page_adapter_services_up extends FragmentStatePagerAdapter {

        int mNumOfTabs;
        FragmentCalendarView fragmentCalendarView;

        public Page_adapter_services_up(FragmentManager fm, int NumOfTabs) {
            super(fm);
            this.mNumOfTabs = NumOfTabs;
        }

    @Override
    public Fragment getItem(int position) {
        FragmentMyService fragmentMyService = new FragmentMyService();
        switch (position) {
            case 0:
                return new Fragment_Up1(); //fragmentMyService
            case 1:
                return new Fragment_Up2(); //FragmentBookmark();
            default:
                return null;
        }
    }


        public int getCount() {
            return mNumOfTabs;
        }
}
