package com.darkweb.android.compass;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;


import android.widget.TextView;
public class NFClass extends AppCompatActivity {

    TextView title1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LocalBroadcastManager.getInstance(this).registerReceiver(mHandler,new IntentFilter("com.darkweb.android.pginfotech"));
        setContentView(R.layout.activity_nf);

            title1 = (TextView)findViewById(R.id.title);

            if(getIntent().getExtras() != null){

                for(String key : getIntent().getExtras().keySet()){
                    if(key.equals("title")){

                        title1.setText(getIntent().getExtras().getString(key));

                    }else{
                    }
                }
            }
    }

    private BroadcastReceiver mHandler = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

        String title = intent.getStringExtra("title");
        title1.setText(title);

        }
    };

    @Override
    protected void onPause() {
        super.onPause();
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mHandler);

    }


}

