package com.darkweb.android.compass.fragments;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.darkweb.android.adapter.CustomServiceListAdapter;
import com.darkweb.android.compass.R;
import com.darkweb.android.global.MyGlobalVars;
import com.darkweb.android.model.RequestedService;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.service.HttpHandlers.RequestedServicesHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

//List view of all services requested by user

public class FragmentMyService_old extends Fragment {

    String sortby_dialogue;
    ListView pendingListView;
    ArrayList<ServiceDetails> serviceDetailsList;
    ArrayList<ServiceDetails> completedServices;
    ArrayList<ServiceDetails> cancelledServices;
    ArrayList<ServiceDetails> currentServices=new ArrayList<ServiceDetails>();
    String url;
    CheckBox pending_checkbox,cancelled_checkbox,completed_checkbox;
    Map<String,Boolean> statusMap=new HashMap<>();
    ArrayList<String> statusArrayList;
    Button apply_dialogue_button,cancel_dialogue_button;
    private OnFragmentInteractionListener mListener;
    private View view;
    CustomServiceListAdapter serviceListAdapter;
    EditText search_service;
    ImageButton filter  , search;
    Dialog mdialog;
    Spinner  sort;
    private LinearLayout viewCheckBox;
    private String[] checkBoxStringArray;
    private ArrayList<CheckBox> checkBoxArray;
    private ArrayList<Boolean> ischecked;
    private int selectedSort=-1;
    TextView resetAll;

    public FragmentMyService_old() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_services, container, false);

    }



    @Override
    public void onStart() {
        super.onStart();
        System.out.println("------ Service Fragment onStart() ------");
        System.out.println("------ Backend data is loading, please wait ------");
        System.out.println("------ FragmentMyService_old.java ------");
        SharedPreferences sp = Objects.requireNonNull(this.getActivity())
                .getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);

        String result = "";
        try {
            // sending user id to backend end, and get the JSON data back
            result = new RequestedServicesHandler().execute(Integer.toString(local_user_id), "client").get();
            if (!result.equals("")) {
                ObjectMapper mapper = new ObjectMapper();
                List<RequestedService> requestedServices = mapper.readValue(result, new TypeReference<List<RequestedService>>() {});
                System.out.println("------ Data pulling from the list ------");
                for (RequestedService rs: requestedServices) {
                    System.out.println(rs.getOrganizationName());
                }
            }
        } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view=view;
        url = getActivity().getFilesDir().toString();
        sortby_dialogue =getString(R.string.alphanumeric_sortby_service_request );


        if (statusArrayList==null)
        {
            statusArrayList=new ArrayList<String>();
        }
        else
        {
            statusArrayList.clear();
        }
        statusArrayList.addAll(Arrays.asList(getResources().getStringArray(R.array.status_type)));

        for (String s:statusArrayList)
        {
            Log.d("qwerty:",s);
            statusMap.put(s,new Boolean(true));
        }

        search_service = view.findViewById(R.id.inpt_search_services);


        //sach Filter dialog only the list related to ' pending, cancelled, completed '
        filter = view.findViewById(R.id.filterservices);
        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mdialog==null)
                {
                    mdialog = new Dialog(getActivity());
                    mdialog.setContentView(R.layout.filter_service_dialog);
                }
                mdialog.setTitle("Filter");
                String title[]={"Pending","Completed","Canceled"};
                viewCheckBox=(LinearLayout) mdialog.findViewById(R.id.view_checkbox);
                resetAll=(TextView)mdialog.findViewById(R.id.reset_all);
                checkBoxStringArray=getResources().getStringArray(R.array.status_type);
                if(checkBoxArray==null )
                {
                    if(checkBoxStringArray.length>0)
                    {
                        checkBoxArray =new ArrayList<CheckBox>();
                    }
                    for(int i=0;i<checkBoxStringArray.length;i++)
                    {
                        CheckBox c=new CheckBox(getActivity());
                        c.setText(title[i]);
                        c.setChecked(true);
                        viewCheckBox.addView(c);
                        checkBoxArray.add(c);
                    }
                }
                else
                {
                    if(checkBoxArray.size()>0)
                    {
                        if (ischecked==null)
                            ischecked=new ArrayList<Boolean>();
                        else
                            if (ischecked.size()>0)
                                ischecked.clear();
                        for (CheckBox c:checkBoxArray)
                            ischecked.add(c.isChecked());
                    }
                }

                apply_dialogue_button=mdialog.findViewById(R.id.apply_my_servicefilter);
                cancel_dialogue_button=mdialog.findViewById(R.id.cancel_my_servicefilter);
                sort = mdialog.findViewById(R.id.sortby_myservice_spinner);
                mdialog.show();
                if (sort !=null)
                selectedSort=sort.getSelectedItemPosition();
                sort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        sortby_dialogue=parent.getItemAtPosition(position).toString();
                        Log.d("spinner position",position+" : "+sortby_dialogue);
                        sort.setSelection(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                cancel_dialogue_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        if (checkBoxArray!=null && checkBoxArray.size()>0 && ischecked!=null && ischecked.size()>0)
                        {
                            for (int i=0;i<checkBoxArray.size();i++)
                            {
                                checkBoxArray.get(i).setChecked(ischecked.get(i));
                            }
                        }
                        if(selectedSort>=0)
                        {
                            sort.setSelection(selectedSort);
                        }
                        mdialog.dismiss();
                    }
                });
                apply_dialogue_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        updateServiceRequest();

                        mdialog.hide();
                    }
                });
                resetAll.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (checkBoxArray!=null && checkBoxArray.size()>0)
                        {
                            for (CheckBox c:checkBoxArray)
                                c.setChecked(true);
                        }
                        if (sort!=null)
                            sort.setSelection(0);

                    }
                });

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        System.out.println("------ Service Fragment onResume()");
        /**
         * The requested services list comes from here
         * Whenever the app is loaded, the list is loading form file
         */
        Log.d("sach_resumeMyService:","yes");
        File file=new File(url,getString(R.string.serviceDetails));
        File completedServicesFile=new File(url,getString(R.string.completedServices));
        File cancelledServicesFile=new File(url,getString(R.string.cancelledServices));
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream ;

        if (file.exists())
        {
            try {
                fileInputStream = new FileInputStream(file);
                objectInputStream = new ObjectInputStream(fileInputStream);
                serviceDetailsList = (ArrayList<ServiceDetails>) objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                System.out.println("\uD83D\uDC4C\uD83D\uDC4C\uD83D\uDC4C------FragmentMyService-file.exists()------------");
                for (ServiceDetails sd: serviceDetailsList) {
                    System.out.println("---| " + sd.getServiceName());
                }
                System.out.println("\uD83D\uDC4C\uD83D\uDC4C\uD83D\uDC4C------End-Of-The-List------------");

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (completedServicesFile.exists())
        {
            try {
                fileInputStream=new FileInputStream(completedServicesFile);
                objectInputStream=new ObjectInputStream(fileInputStream);
                completedServices=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                Log.d("sach_completed status:",completedServices.size()+"");


            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }

        System.out.println("------FragmentMyService-exist-Log.d------------");
        Log.d("exist:",(completedServicesFile.exists())+"");
        if (cancelledServicesFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(cancelledServicesFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                cancelledServices = (ArrayList<ServiceDetails>) objectInputStream.readObject();
                Log.d("cancel size:",cancelledServices.size()+"");
                objectInputStream.close();
                fileInputStream.close();
                Log.d("cancelled :", cancelledServices + "");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        updateServiceRequest();
    }

    private void updateServiceRequest()
    {
        System.out.println("------What is this and when you created? ------------");
        if(currentServices.size()>0)
        {
            currentServices.clear();
        }
        Log.d("check box ar",checkBoxArray+"" );
        if(checkBoxArray!=null && checkBoxArray.size()>0)
        {

            for (CheckBox c:checkBoxArray)
            {
                statusMap.put(c.getText().toString(),c.isChecked());

            }
        }

        Log.d("string:",statusMap.get(getString(R.string.pending_status_service_request))+"  "+getString(R.string.pending_status_service_request));
        if(statusMap.get(getString(R.string.pending_status_service_request)).equals(new Boolean(true)) && serviceDetailsList!=null && serviceDetailsList.size()>0)
        {
            if (sortby_dialogue.equals(getString(R.string.alphanumeric_sortby_service_request)))
            {
                Log.d("sort:","alpha");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    //serviceDetailsList.sort(Comparator.comparing(ServiceDetails::getServiceRequestName));//sach changed serviceRequestName>title / getServiceRequestName > getTitle() / setServiceRequestName > setTitle()
                    serviceDetailsList.sort(Comparator.comparing(ServiceDetails::getTitle));
                }
            }
            else  if (sortby_dialogue.equals(getString(R.string.lastupdated_sortby_service_request)))
            {
                Log.d("sort:","last updated");
                Collections.sort(serviceDetailsList, new Comparator<ServiceDetails>() {
                    @Override
                    public int compare(ServiceDetails o1, ServiceDetails o2) {
                        try {
                            //Date d1 = new Date(o1.getRequestingServiceDate()); //sach changed > submission date
                            //Date d2 = new Date(o2.getRequestingServiceDate()); //sach changed > submission date
                            Date d1 = new Date(o1.getSubmissionDate());
                            Date d2 = new Date(o2.getSubmissionDate());
                            Log.d("last update:",d2.compareTo(d1)+"  d:"+d1.compareTo(d2));
                            return d2.compareTo(d1);
                        }catch (Exception e)
                        {
                         Log.d("exce:",e.toString());
                            return 0;
                        }
                    }
                });
            }
            currentServices.addAll(serviceDetailsList);
        }
        if (statusMap.get(getString(R.string.completed_status_service_request)).equals(new Boolean(true)) && completedServices!=null && completedServices.size()>0)
        {
            if (sortby_dialogue.equals(getString(R.string.alphanumeric_sortby_service_request)))
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    //completedServices.sort(Comparator.comparing(ServiceDetails::getServiceRequestName)); //sach changed
                    completedServices.sort(Comparator.comparing(ServiceDetails::getTitle));
                }
            }
            else  if (sortby_dialogue.equals(getString(R.string.lastupdated_sortby_service_request)))
            {
                Collections.sort(completedServices, new Comparator<ServiceDetails>() {
                    @Override
                    public int compare(ServiceDetails o1, ServiceDetails o2) {
                        try {
                            //Date d1 = new Date(o1.getRequestingServiceDate()); //sach changed
                            //Date d2 = new Date(o2.getRequestingServiceDate());//sach changed
                            Date d1 = new Date(o1.getSubmissionDate());
                            Date d2 = new Date(o2.getSubmissionDate());
                            return d2.compareTo(d1);
                        }catch (Exception e)
                        {
                            return 0;
                        }
                    }
                });
            }
            currentServices.addAll(completedServices);
        }
        if (statusMap.get(getString(R.string.cancelled_status_service_request)).equals(new Boolean(true)) && cancelledServices!=null && cancelledServices.size()>0)
        {
            if (sortby_dialogue.equals(getString(R.string.alphanumeric_sortby_service_request)))
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    //cancelledServices.sort(Comparator.comparing(ServiceDetails::getServiceRequestName));//sach changed
                    cancelledServices.sort(Comparator.comparing(ServiceDetails::getTitle));
                }else{
                    Toast.makeText(getContext(), "fail", Toast.LENGTH_SHORT).show();
                }
            }
            else  if (sortby_dialogue.equals(getString(R.string.lastupdated_sortby_service_request)))
            {
                Collections.sort(cancelledServices, new Comparator<ServiceDetails>() {
                    @Override
                    public int compare(ServiceDetails o1, ServiceDetails o2) {
                        try {
                            //Date d1 = new Date(o1.getRequestingServiceDate());//sach changed
                            //Date d2 = new Date(o2.getRequestingServiceDate());//sach changed
                            Date d1 = new Date(o1.getSubmissionDate());
                            Date d2 = new Date(o2.getSubmissionDate());
                            return d2.compareTo(d1);
                        }catch (Exception e)
                        {
                            return 0;
                        }
                    }
                });
            }

            currentServices.addAll(cancelledServices);
        }

        if(pendingListView==null)
        {
            pendingListView=view.findViewById(R.id.my_service_list_view);
        }


        for(int i=0;i<currentServices.size();i++)
            Log.d("list-", String.valueOf(currentServices.get(i).getStatusArray()));
//keep user services
     //  removerOtherServices();
        for(int i=0;i<currentServices.size();i++)
        //Log.d("list-of", String.valueOf(currentServices.get(i).getServiceRequestName()));//sach changed
        Log.d("sach_FMS_Services", String.valueOf(currentServices.get(i).getTitle()));
       removeDuplicates();


        for(int i=0;i<currentServices.size();i++)
            //Log.d("list-of-new", String.valueOf(currentServices.get(i).getServiceRequestName()));//sach changed
//            Log.d("list-of-new", String.valueOf(currentServices.get(i).getTitle()));
        if (serviceListAdapter==null)
        {
            serviceListAdapter=new CustomServiceListAdapter(getActivity(),currentServices);
            pendingListView.setAdapter(serviceListAdapter);
        }
        else
        {
            serviceListAdapter.notifyDataSetChanged();
        }
        if (search_service!=null)
        {
            search_service.addTextChangedListener(new TextWatcher() {

                @Override
                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                    // When user changed the Text

                    String text = search_service.getText().toString().toLowerCase(Locale.getDefault());
                    //FragmentMyService.this.serviceListAdapter.getFilter().filter(cs);
                    if (serviceListAdapter!=null)
                        serviceListAdapter.filter(text);
                }

                @Override
                public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                              int arg3) {

                }

                @Override
                public void afterTextChanged(Editable arg0) {
                }
            });
        }


        //sach requested - pending service list view selected.
        pendingListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Log.d("sach_Item selected"," FragmentMyService : " +position);
                ServiceDetails serviceObj=currentServices.get(position);
                Log.d("sach_FMS_serviceObj", String.valueOf(serviceObj));
                //String item = currentServices.get(position).getServiceDescription();//sach changed as below
                String item = currentServices.get(position).getComments();
                Log.d("sach__FMS_ item","serviceDescription " + item.toString());
                Intent i = new Intent(FragmentMyService_old.this.getActivity(), ServiceRequested.class);
                i.putExtra("serviceRequestObject", serviceObj);
                startActivity(i);
            }
        }); //check this

    }

    public void removeDuplicates(){
        for(int i=0;i<currentServices.size();i++){
            for(int j=currentServices.size()-1;j>0;j--){
                //if(currentServices.get(i).getServiceRequestName().equals(currentServices.get(j).getServiceRequestName())){ //sach changed
                if(currentServices.get(i).getTitle().equals(currentServices.get(j).getTitle())){

                    //if((currentServices.get(i).getRequestingServiceDate()).compareTo(currentServices.get(j).getRequestingServiceDate())>0){ //sach changed
                    if((currentServices.get(i).getSubmissionDate()).compareTo(currentServices.get(j).getSubmissionDate())>0){
                            currentServices.remove(j);
                    //}else if((currentServices.get(i).getRequestingServiceDate()).compareTo(currentServices.get(j).getRequestingServiceDate())<0){ //sach changed
                    }else if((currentServices.get(i).getSubmissionDate()).compareTo(currentServices.get(j).getSubmissionDate())<0){
                        currentServices.remove(i);
                    }



                }
            }
        }
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

}
