package com.darkweb.android.model.ObjectsForMapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestedServiceDetail {
    private Request request;
    private List<RequestStatus> statuses;

    public RequestedServiceDetail() {
    }

    public Request getRequest() {
        return request;
    }

    public void setRequest(Request request) {
        this.request = request;
    }

    public List<RequestStatus> getStatuses() {
        return statuses;
    }

    public void setStatuses(List<RequestStatus> statuses) {
        this.statuses = statuses;
    }
}
