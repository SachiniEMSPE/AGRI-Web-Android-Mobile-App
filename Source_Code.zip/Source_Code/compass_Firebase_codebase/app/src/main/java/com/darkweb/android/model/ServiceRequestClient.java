package com.darkweb.android.model;

import java.io.Serializable;
import java.util.UUID;
// sach created 2020.02.22 - to communicate with server


public class ServiceRequestClient extends ServiceDetails implements Serializable,Comparable<ServiceRequestClient> {

    String userUID;
    String attachments;
    String message;
    String organizationID;
    UUID requestUID;
    String serviceID;
    String comments;
    String submissionDate;
    String eligibility;

    public String toString() {
        return "{" +
                " URI='" + requestUID + '\'' +
                ", OrganizationID='" + organizationID + '\'' +
                ", ClientID='" + userUID + '\'' +
                ", ServiceID=" + serviceID +
                ", Date=" + comments +'\'' +
                ", Comments=" + submissionDate+'\'' +
                ", Eligibility='" + eligibility + '\'' +
                ", Attachments=" + attachments +
                ", Message='" + message+ '\'' +
                '}';
    }


      public String getURI() {
        return String.valueOf(getRequestUID());
    }
    public void setClientID(String userUID) {
        this.userUID = userUID;
    }




    @Override
    public int compareTo(ServiceRequestClient o) {
        return 0;
    }
}


