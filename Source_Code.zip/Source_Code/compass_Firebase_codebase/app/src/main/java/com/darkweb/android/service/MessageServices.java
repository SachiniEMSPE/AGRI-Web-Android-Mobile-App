package com.darkweb.android.service;

import android.content.Context;
import android.util.Log;

import com.darkweb.android.model.Message;
import com.darkweb.android.compass.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by kotak on 04/09/2018.
 */

public class MessageServices {

    public static void writeMessageToFile(Context context, Message messageObj) {
        String url = context.getFilesDir().toString();
        ArrayList<Message> messageList = new ArrayList<Message>();
        final File file = new File(url, context.getString(R.string.message_file_name));
        try {
            if (file.exists()) {
                FileInputStream fileInputStream = new FileInputStream(file);
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                messageList = (ArrayList<Message>) objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (messageList != null) {
                    messageList.add(0, messageObj);
                } else {
                    messageList = new ArrayList<Message>();
                    messageList.add(0, messageObj);
                }
            } else {
                messageList = new ArrayList<Message>();
                messageList.add(0, messageObj);
            }
            FileOutputStream fileOutputStream;
            ObjectOutputStream objectOutputStream;
            fileOutputStream = context.openFileOutput(file.getName(), Context.MODE_PRIVATE);
            Log.d("filename:", file.getName());
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(messageList);
            objectOutputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static ArrayList<Message> getUsersMessageListFromFile(Context context, String userName, String orgName) {
        String url = context.getFilesDir().toString();
        ArrayList<Message> messageList = getMessageListFromFile(context);
        ArrayList<Message> returnList=new ArrayList<Message>();
        if (messageList != null && messageList.size()>0) {

            for (Message messageObj:messageList ) {
                Log.d("useD:","msg:"+messageObj.getUserName()+" "+messageObj.getOrganisationName()+" "+userName+ " "+orgName);
                if ((messageObj.getUserName().equals(userName) && messageObj.getOrganisationName().equals(orgName))) {
                    returnList.add(messageObj);
                }
            }

           sortMessageList(returnList);
        }
        return returnList;
    }

    public static void sortMessageList(ArrayList<Message> messageList)
    {
        Collections.sort(messageList, new Comparator<Message>() {
            @Override
            public int compare(Message o1, Message o2) {
                try {
                    Date d1 =o1.getCreatedDate();
                    Date d2 = o2.getCreatedDate();
                    return d1.compareTo(d2);
                }catch (Exception e)
                {
                    Log.d("exce:",e.toString());
                    return 0;
                }
            }
        });

    }
    public static ArrayList<Message> getMessageListFromFile(Context context) {
        String url = context.getFilesDir().toString();
        ArrayList<Message> messageList = null;
        final File file = new File(url, context.getString(R.string.message_file_name));
        try {
            if (file.exists()) {
                FileInputStream fileInputStream = new FileInputStream(file);
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                messageList = (ArrayList<Message>) objectInputStream.readObject();
                objectInputStream.close();

            }
        } catch (Exception e) {
            return null;
        }
        return messageList;
    }

    public static HashMap<String,ArrayList<Message>> getMessagListOrganisation(Context context, String orgName)
    {
        ArrayList<Message> messageList= getMessageListFromFile(context);
        sortMessageList(messageList);
        Log.d("mesgsSixe:",messageList.size()+"");
        HashMap<String,ArrayList<Message>> returnMessagMap=new HashMap<String,ArrayList<Message>>();
        if (messageList != null) {
            for (Message messageObj : messageList) {
                Log.d("mesgsSixe:",messageObj.getOrganisationName()+"  "+orgName+"  bool:"+(messageObj.getOrganisationName().equals(orgName)));

                if ((messageObj.getOrganisationName().equals(orgName))) {
     //               orgMessageList.add(messageObj);
                    if(returnMessagMap.containsKey(messageObj.getUserName()))
                    {
                        returnMessagMap.get(messageObj.getUserName()).add(messageObj);
                    }
                    else
                    {
                        ArrayList<Message> msgList=new ArrayList<Message>();
                        msgList.add(messageObj);
                        returnMessagMap.put(messageObj.getUserName(),msgList);
                    }
                }
            }
        }
        return returnMessagMap;
    }
}
