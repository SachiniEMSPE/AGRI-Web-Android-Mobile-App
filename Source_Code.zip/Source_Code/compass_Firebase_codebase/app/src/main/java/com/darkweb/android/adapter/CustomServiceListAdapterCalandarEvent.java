package com.darkweb.android.adapter;

import android.app.Activity;
import android.os.Build;
import androidx.annotation.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.compass.R;

import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by kotak on 12/07/2018.
 */

public class CustomServiceListAdapterCalandarEvent extends ArrayAdapter<CalandarEvent> {
    private final Activity context;
    private final ArrayList<CalandarEvent> serviceList;
    private  ArrayList<CalandarEvent> arrayList;

    public CustomServiceListAdapterCalandarEvent(Activity context, ArrayList<CalandarEvent> serviceList) {
        super(context, R.layout.servicelistview,serviceList);
        this.context = context;
        this.serviceList = serviceList;
        this.arrayList=new ArrayList<CalandarEvent>();
        this.arrayList.addAll(serviceList);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        CalandarEvent serviceDetailsObj=serviceList.get(position);
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.custom_service_list_adapter_view, null,true);
        TextView serviceName=(TextView)rowView.findViewById(R.id.servicename_textview);
        TextView serviceDescription=(TextView)rowView.findViewById(R.id.service_description_textView);
        ImageView iconImage=(ImageView) rowView.findViewById(R.id.service_image_icon);
        TextView lastupdatedDate=(TextView) rowView.findViewById(R.id.last_updateddate);
        lastupdatedDate.setText(serviceDetailsObj.getEventDateTime()+"");
        serviceName.setText(serviceDetailsObj.getEventName());
        serviceDescription.setText(serviceDetailsObj.getEventDescription());
        iconImage.setVisibility(View.GONE);
        if(serviceDetailsObj.getEventDateTime().compareTo(new Date()) < 0) {
            lastupdatedDate.setTextColor(context.getColor(R.color.grey_color));
            serviceName.setTextColor(context.getColor(R.color.grey_color));
            serviceDescription.setTextColor(context.getColor(R.color.grey_color));
        }
        else {
            lastupdatedDate.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
            serviceName.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
            serviceDescription.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
        }


        return rowView;
    }

    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        serviceList.clear();
        if (charText.length() == 0) {
            serviceList.addAll(arrayList);
        }
        else
        {
            for (CalandarEvent sd : arrayList)
            {
                if (sd.getEventName().toString().toLowerCase(Locale.getDefault()).contains(charText))
                {
                    serviceList.add(sd);
                }
                else if(sd.getEventDescription().toString().toLowerCase(Locale.getDefault()).contains(charText))
                {
                    serviceList.add(sd);
                }
                else if(sd.getEventDateTime().toString().toLowerCase(Locale.getDefault()).contains(charText))
                {
                    serviceList.add(sd);
                }
                else
                {}
            }
        }
        notifyDataSetChanged();
    }

}
