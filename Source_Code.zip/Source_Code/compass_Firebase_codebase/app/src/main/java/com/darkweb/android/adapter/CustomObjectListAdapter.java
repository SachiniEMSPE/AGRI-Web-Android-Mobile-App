package com.darkweb.android.adapter;

import android.app.Activity;
import android.os.Build;
import androidx.annotation.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.compass.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by kotak on 07/06/2018.
 */

public class CustomObjectListAdapter extends ArrayAdapter<Object>{
    private final ArrayList<Object> objectArrayList;
    private final Activity context;
    private ArrayList<Object> arrayList;

    public CustomObjectListAdapter(Activity context, ArrayList<Object> objectList) {
        super(context, R.layout.servicelistview,objectList);
        this.context = context;
        this.objectArrayList = objectList;
        this.arrayList=new ArrayList<Object>();
        this.arrayList.addAll(objectArrayList);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {


        Object object=(CalandarEvent) objectArrayList.get(position);
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.custom_service_list_adapter_view, null,true);
        TextView serviceName=(TextView)rowView.findViewById(R.id.servicename_textview);
        TextView serviceDescription=(TextView)rowView.findViewById(R.id.service_description_textView);
        ImageView iconImage=(ImageView) rowView.findViewById(R.id.service_image_icon);
        TextView lastupdatedDate=(TextView) rowView.findViewById(R.id.last_updateddate);
        //iconImage.setVisibility(View.GONE);

        if(object instanceof CalandarEvent)
        {
            CalandarEvent calandarEvent=(CalandarEvent)object;
            String pattern = "EEEE, MM/dd/yyyy hh:mm a";
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
            lastupdatedDate.setText("("+simpleDateFormat.format(calandarEvent.getEventDateTime())+")");
            serviceName.setText(calandarEvent.getEventName());
            serviceName.setTextColor(context.getColor( R.color.pending));

            serviceDescription.setText(calandarEvent.getOrganizationDescription().getOrganizationName());
            iconImage.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_event_black_24dp));
            if(calandarEvent.getEventDateTime().compareTo(new Date()) < 0) {
                lastupdatedDate.setTextColor(context.getColor(R.color.grey_color));
                serviceName.setTextColor(context.getColor(R.color.grey_color));
                serviceDescription.setTextColor(context.getColor(R.color.grey_color));
                //rowView.setBackgroundColor(context.getColor(R.color.grey_color));
            }
            else
            {
                lastupdatedDate.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
                serviceName.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
                serviceDescription.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
            }   // rowView.setBackgroundColor(context.getColor(R.color.white));

        }
        else if(object instanceof  ServiceDetails)
        {
            iconImage.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_local_play_black_24dp));
        }
        else
        {
        }


        return rowView;
    }
    //@RequiresApi(api = Build.VERSION_CODES.N)
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        objectArrayList.clear();
        if (charText.length() == 0) {
            objectArrayList.addAll(arrayList);
        }
        else
        {
            for (Object object : arrayList)
            {
                if(object instanceof CalandarEvent)
                {
                    CalandarEvent calEventObj=(CalandarEvent)object;
                    OrganizationDescription locationobj=calEventObj.getOrganizationDescription();
                    String searchText=charText;
                    if( calEventObj.getEventName().contains(searchText) || calEventObj.getEventDateTime().toString().contains(searchText) || calEventObj.getEventDescription().contains(searchText) || calEventObj.getStreetAddress().contains(searchText) || calEventObj.getCity().contains(searchText) || calEventObj.getState().contains(searchText) ||   calEventObj.getZipcode().contains(searchText))
                    {
                        objectArrayList.add(calEventObj);
                    }
                    else  if ( locationobj.getOrganizationName().contains(searchText) || locationobj.getCategory().contains(searchText) || locationobj.getContact().contains(searchText) || locationobj.getZipcode().contains(searchText) || locationobj.getState().contains(searchText) || locationobj.getCity().contains(searchText) || locationobj.getDescription().contains(searchText)||locationobj.getEmailId().contains(searchText)||locationobj.getStreetAddress().contains(searchText)||locationobj.getWebsite().contains(searchText))
                    {
                        objectArrayList.add(calEventObj);
                    }
                }
                else if(object instanceof ServiceDetails)
                {
                    ServiceDetails sd=(ServiceDetails)object;
                    if (sd.getRequestUID().toString().toLowerCase(Locale.getDefault()).contains(charText))//sach changed getServiceId()>getRequestDate()
                    {
                        objectArrayList.add(sd);
                    }
                    //else if(sd.getServiceDescription().toString().toLowerCase(Locale.getDefault()).contains(charText)) //sach changed serviceDescription>comments / getserviceDescription()>getComments() / setserviceDescription()>setComments()
                    else if(sd.getComments().toString().toLowerCase(Locale.getDefault()).contains(charText))
                    {
                        objectArrayList.add(sd);
                    }
                    else if(sd.getOrganizationDescription().getOrganizationName().toLowerCase(Locale.getDefault()).contains(charText)) //sach commented and updated as below ,  @RequiresApi(api = Build.VERSION_CODES.N) added
                    //else if(sd.getOrganizationDescription(context).getOrganizationName().toLowerCase(Locale.getDefault()).contains(charText)) // sach commented this 2020-02-06 and uncommented above
                    {
                        objectArrayList.add(sd);
                    }
                    else
                    {}
                }
            }

        }
        notifyDataSetChanged();
    }


}
