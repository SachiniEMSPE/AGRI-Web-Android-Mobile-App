package com.darkweb.android.agri;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.darkweb.android.adapter.Page_adapter_services;
import com.darkweb.android.compass.R;
import com.google.android.material.tabs.TabLayout;

public class Form_tab extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.ag_form_tab,container,false); //activity_service_tab
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TabLayout tabLayout = (TabLayout) view.findViewById(R.id.tabs_ser);
        tabLayout.addTab(tabLayout.newTab().setText("FARMER BIO DATA"));
        tabLayout.addTab(tabLayout.newTab().setText("PRODUCTION AREA"));
        tabLayout.addTab(tabLayout.newTab().setText("AGRONOMIC DATA"));
        tabLayout.addTab(tabLayout.newTab().setText("MARKETING DATA"));

        viewPager = (ViewPager)view.findViewById(R.id.viewpager_ser);


        final Page_adapter_services adapter = new Page_adapter_services
                (getChildFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);


        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        viewPager.setCurrentItem(0);
        viewPager.setOffscreenPageLimit(4);

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {


                if (tab.getPosition() == 0) {
                    viewPager.setCurrentItem(0);

                } else if (tab.getPosition() == 1) {
                    /**
                     * When bookmark tab has been clicked
                     */
                    viewPager.setCurrentItem(1);

                } else if (tab.getPosition() == 2) {
                    /**
                     * When pathways tab has been clicked
                     */
                    viewPager.setCurrentItem(2);

                } else  {
                    /**
                     * When pathways tab has been clicked
                     */
                    viewPager.setCurrentItem(3);
                }
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

        });



    }

}
