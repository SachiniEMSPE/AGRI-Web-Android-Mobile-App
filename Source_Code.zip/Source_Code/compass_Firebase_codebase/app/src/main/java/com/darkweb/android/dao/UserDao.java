package com.darkweb.android.dao;

import android.content.Context;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.User;
import com.darkweb.android.service.RestoreSettingService;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class UserDao {

    public User getUserSignedIn(Context context)
    {
        String url = (String) context.getFilesDir().toString();
        File userFile = new File(url, context.getString(R.string.UserInfo));
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream;
        ArrayList<User> userInfoList;
        if (userFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(userFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                userInfoList = (ArrayList<User>) objectInputStream.readObject();
                if (userInfoList!=null)
                {
                    if (userInfoList.size()>0)
                        return userInfoList.get(0);
                }
            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return null;
    }

    public static boolean signOutUser(Context context)
    {
        String url = (String) context.getFilesDir().toString();
        File userFile = new File(url, context.getString(R.string.UserInfo));
        try
        {
            userFile.delete();
        }
        catch (Exception e)
        {
            return false;
        }
        return  true;
    }

    public static boolean userAdded(Context context, User user) {
        String url = (String) context.getFilesDir().toString();
        File userFile = new File(url, context.getString(R.string.UserInfo));
        FileOutputStream fileOutputStream;
        ObjectOutputStream objectOutputStream;
        ArrayList<User> userArrayList=new ArrayList<User>();
        try {
            fileOutputStream = context.openFileOutput(userFile.getName(), Context.MODE_PRIVATE);
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
//            Log.d("userAdded:",user.getUserUID());
            userArrayList.add(user);
            objectOutputStream.writeObject(userArrayList);
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }


    public static User userinUserList(Context context,User user) {
        String url = (String) context.getFilesDir().toString();
        File userFile = new File(url, context.getString(R.string.UserList));
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream;
        ArrayList<User> userInfoList=null;
        if (userFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(userFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                userInfoList = (ArrayList<User>) objectInputStream.readObject();
                if (userInfoList!=null)
                {
                    for (User userObj:userInfoList)
                    {
                        if (userObj.getUserName().equals(user.getUserName())  )
                            return userObj;
                    }

                }
            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }

        return null;
    }
    public static boolean addUserInList(Context context, User user)
    {
        String url = (String) context.getFilesDir().toString();
        File userFile = new File(url, context.getString(R.string.UserList));
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream;
        ArrayList<User> userInfoList=null;
        if (userFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(userFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                userInfoList = (ArrayList<User>) objectInputStream.readObject();
                if (userInfoList!=null)
                {
                    for (User userObj:userInfoList)
                    {
                        Log.d("name:",userObj.getUserName()+" "+user.getUserName());
                        if (userObj.getUserName().equals(user.getUserName())) {
                            Log.d("userExist:","true");
                            return false;
                        }
                    }
                    userInfoList.add(user);
                }
                else
                {
                    userInfoList=new ArrayList<User>();
                    userInfoList.add(user);
                }
            }catch (Exception e)
            {
                e.printStackTrace();
                return false;
            }
        }
        else
        {
            userInfoList=new ArrayList<User>();
            userInfoList.add(user);
        }

        FileOutputStream fileOutputStream;
        ObjectOutputStream objectOutputStream;
        try {
            fileOutputStream = context.openFileOutput(userFile.getName(), Context.MODE_PRIVATE);
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(userInfoList);
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        }catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }


    public static boolean removeUserInList(Context context, User user)
    {
        String url = (String) context.getFilesDir().toString();
        File userFile = new File(url, context.getString(R.string.UserList));
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream;
        ArrayList<User> userInfoList=null;
        if (userFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(userFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                userInfoList = (ArrayList<User>) objectInputStream.readObject();
                if (userInfoList!=null)
                {
                    User tmpUser=null;
                    for (User userObj:userInfoList)
                    {
                        Log.d("name:",userObj.getUserName()+" "+user.getUserName());
                        if (userObj.getUserName().equals(user.getUserName())) {
                            tmpUser=userObj;
                            break;
                        }
                    }
                    if (tmpUser!=null)
                        userInfoList.remove(tmpUser);
                }

            }catch (Exception e)
            {
                e.printStackTrace();
                return false;
            }
        }

        FileOutputStream fileOutputStream;
        ObjectOutputStream objectOutputStream;
        try {
            fileOutputStream = context.openFileOutput(userFile.getName(), Context.MODE_PRIVATE);
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(userInfoList);
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        }catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }


    private void updateUserwithUserUID(Context context, User user) {

        Log.d("update user",user.getUserUID());
        String url = (String) context.getFilesDir().toString();
        File userFile = new File(url, context.getString(R.string.UserList));
        FileInputStream fileInputStream ;
        ObjectInputStream objectInputStream;
        ArrayList<User> userInfoList=null;
        if (userFile.exists())
        {
            try {
                fileInputStream = new FileInputStream(userFile);
                objectInputStream = new ObjectInputStream(fileInputStream);
                userInfoList = (ArrayList<User>) objectInputStream.readObject();
                if (userInfoList!=null)
                {
                    for (User userObj:userInfoList)
                    {
                        Log.d("name:",userObj.getUserName()+" "+user.getUserName());
                        if (userObj.getUserName().equals(user.getUserName())) {
                            userObj.setUserUID(user.getUserUID());
                            Log.d("userObjIdexist:",""+userObj.getUserUID());

                        }
                    }
                }
            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }

        FileOutputStream fileOutputStream;
        ObjectOutputStream objectOutputStream;
        try {
            fileOutputStream = context.openFileOutput(userFile.getName(), Context.MODE_PRIVATE);
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(userInfoList);
            fileOutputStream.flush();
            fileOutputStream.close();

        }catch (Exception e)
        {
            e.printStackTrace();

        }
        signOutUser(context);
        userAdded(context,user);

    }
    
}
