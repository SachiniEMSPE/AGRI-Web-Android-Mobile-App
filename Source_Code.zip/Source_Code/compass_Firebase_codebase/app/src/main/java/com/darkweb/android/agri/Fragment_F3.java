package com.darkweb.android.agri;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.darkweb.android.compass.R;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.Calendar;

public class Fragment_F3 extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener, DatePickerDialog.OnDateSetListener {

    Spinner f3_sp_major,f3_sp_easy,f3_sp_weed,f3_sp_tractor,f3_sp_tractorNo,f3_sp_weedicides,f3_sp_fert,f3_sp_pest,f3_sp_water,
            f3_sp_labo,f3_sp_famlab,f3_sp_plants;
    String [] ans_f3_sp_major, ans_f3_sp_where,ans_f3_sp_easy,ans_f3_sp_weed, ans_f3_sp_tractor,ans_f3_sp_tractorNo,ans_f3_sp_weedicides,ans_f3_sp_fert,
            ans_f3_sp_pest,ans_f3_sp_water, ans_f3_sp_labo, ans_f3_sp_famlab, ans_f3_sp_plants,
            listItems_apply, listItems_fetapp,listItems_control, listItems_fung ;
    TextInputLayout f3_Layout_tractor,f3_Layout_weedi;
    Button f3_bt_when, f3_bt_where, f3_bt_apply, f3_bt_fetapp,f3_bt_control, f3_bt_fung, f3_bt_yes;
    LinearLayout f3_Layout_yes;
    boolean [] checkedItems, checkedItems_apply, checkedItems_fetapp, checkedItems_control, checkedItems_fung;
    ArrayList<Integer> mUserItems = new ArrayList<>();
    ArrayList<Integer> mUserItems_apply = new ArrayList<>();
    ArrayList<Integer> mUserItems_fetapp = new ArrayList<>();
    ArrayList<Integer> mUserItems_control = new ArrayList<>();
    ArrayList<Integer> mUserItems_fung = new ArrayList<>();

    TextView f3_tx_yes;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d("Fragment ","2");
        View f3View = inflater.inflate(R.layout.ag_fragment_f3, container, false); //tab_fragment_2

        f3_sp_major = f3View.findViewById(R.id.f3_sp_major);
        f3_sp_easy = f3View.findViewById(R.id.f3_sp_easy);
        f3_sp_weed = f3View.findViewById(R.id.f3_sp_weed);
        f3_sp_tractor = f3View.findViewById(R.id.f3_sp_tractor);
        f3_sp_tractorNo =  f3View.findViewById(R.id.f3_sp_tractorNo);
        f3_sp_weedicides = f3View.findViewById(R.id.f3_sp_weedicides);
        f3_sp_fert =  f3View.findViewById(R.id.f3_sp_fert);
        f3_sp_pest = f3View.findViewById(R.id.f3_sp_pest);
        f3_sp_water =  f3View.findViewById(R.id.f3_sp_water);
        f3_sp_labo =  f3View.findViewById(R.id.f3_sp_labo);
        f3_sp_famlab =  f3View.findViewById(R.id.f3_sp_famlab);
        f3_sp_plants =  f3View.findViewById(R.id.f3_sp_plants);

        f3_Layout_tractor = f3View.findViewById(R.id.f3_Layout_tractor);
        f3_Layout_weedi = f3View.findViewById(R.id.f3_Layout_weedi);

        f3_tx_yes =  f3View.findViewById(R.id.f3_tx_yes);

        f3_bt_when = f3View.findViewById(R.id.f3_bt_when);
        f3_bt_where =  f3View.findViewById(R.id.f3_bt_where);
        f3_bt_apply =  f3View.findViewById(R.id.f3_bt_apply);
        f3_bt_fetapp =   f3View.findViewById(R.id.f3_bt_fetapp);
        f3_bt_control =  f3View.findViewById(R.id.f3_bt_control);
        f3_bt_fung =  f3View.findViewById(R.id.f3_bt_fung);
        f3_bt_yes =  f3View.findViewById(R.id.f3_bt_yes);

        f3_Layout_yes = f3View.findViewById(R.id.f3_Layout_yes);

        f3spmajor(); f3speasy(); f3spweed();f3sptractor();f3sptractorNo();f3spweedicides();f3spfert();
        f3sppest();f3spwater();f3splabo();f3spfamlab(); f3spplants();

        f3_sp_tractor.setOnItemSelectedListener(this);
        f3_sp_weedicides.setOnItemSelectedListener(this);

        f3_bt_when.setOnClickListener(this);

        return f3View;
    }

    private void f3spplants() {
        ans_f3_sp_plants = new String[]{
                "Manual watering","Mechanized irrigation", "Trenches", "Other",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_plants);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_plants.setAdapter(memAdapter);
    }

    private void f3spfamlab() {
        ans_f3_sp_famlab = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_famlab);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_famlab.setAdapter(memAdapter);

    }

    private void f3splabo() {
        ans_f3_sp_labo = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_labo);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_labo.setAdapter(memAdapter);
    }

    private void f3spwater() {
        ans_f3_sp_water = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_water);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_water.setAdapter(memAdapter);


    }

    private void f3sppest() {
        ans_f3_sp_pest = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_pest);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_pest.setAdapter(memAdapter);
    }

    private void f3spfert() {
        ans_f3_sp_fert = new String[]{
                "Organic","Synthetic","A blend of both",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_fert);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_fert.setAdapter(memAdapter);
    }

    private void f3spweedicides() {
        ans_f3_sp_weedicides = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_weedicides);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_weedicides.setAdapter(memAdapter);
    }

    private void f3sptractorNo() {
        ans_f3_sp_tractorNo = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_tractorNo);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_tractorNo.setAdapter(memAdapter);
    }

    private void f3sptractor() {
        ans_f3_sp_tractor = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_tractor);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_tractor.setAdapter(memAdapter);
    }

    private void f3spweed() {
        ans_f3_sp_weed = new String[]{
                "Manual weeding","Chemical application","Mechanization","A blend of techniques", "Other",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_weed);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_weed.setAdapter(memAdapter);
    }

    private void f3speasy() {
        ans_f3_sp_easy = new String[]{
                "Yes","No",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_easy);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_easy.setAdapter(memAdapter);
    }

    private void f3spmajor() {
        ans_f3_sp_major = new String[]{
                "Maize", "Tomatoes", "Other",
        };
        ArrayAdapter<String> memAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item, ans_f3_sp_major);
        memAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        f3_sp_major.setAdapter(memAdapter);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ans_f3_sp_where = new String[]{
                "Agrochemical shop", "MoFa office", "Farmer saved seeds", "Other farmers","Seed company","Other"};
        checkedItems = new boolean[ans_f3_sp_where.length];
        f3_bt_where.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
                mBuilder.setTitle("Who own the lands you farm on?");
                mBuilder.setMultiChoiceItems(ans_f3_sp_where, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                        if(isChecked){
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            if(!mUserItems.contains(position)){
                                mUserItems.add(position);
                                Log.d("**MULTI CHOICE**", mUserItems.toString());
                            }
                        }else {
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            mUserItems.remove(position);
                            Log.d("**MULTI CHOICE2**", mUserItems.toString());
                        }
                    }
                });
                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String item = "";
                        for (int i = 0; i< mUserItems.size(); i++){
                            item = item + ans_f3_sp_where [mUserItems.get(i)];
                            if( i != mUserItems.size() -1){
                                item = item + ", ";
                            }
                        }
                        f3_bt_where.setText(item);
                    }
                });
                mBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                mBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for (int i = 0; i < checkedItems.length; i++){
                            checkedItems [i] = false;
                            mUserItems.clear();
                            f3_bt_where.setText("Select an answer");
                        }
                    }
                });

                AlertDialog mDialog = mBuilder.create();
                mDialog.show();

            }
        });

        listItems_apply = new String[]{
                "Foliar spraying", "Drill and fill", "Broadcasting", "Other"};
        checkedItems_apply = new boolean[listItems_apply.length];
        f3_bt_apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
                mBuilder.setTitle("Who own the lands you farm on?");
                mBuilder.setMultiChoiceItems(listItems_apply, checkedItems_apply, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                        if(isChecked){
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            if(!mUserItems_apply.contains(position)){
                                mUserItems_apply.add(position);
                                Log.d("**MULTI CHOICE**", mUserItems_apply.toString());
                            }
                        }else {
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            mUserItems_apply.remove(position);
                            Log.d("**MULTI CHOICE2**", mUserItems_apply.toString());
                        }
                    }
                });
                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String item = "";
                        for (int i = 0; i< mUserItems_apply.size(); i++){
                            item = item + listItems_apply [mUserItems_apply.get(i)];
                            if( i != mUserItems_apply.size() -1){
                                item = item + ", ";
                            }
                        }
                        f3_bt_apply.setText(item);
                    }
                });
                mBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                mBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for (int i = 0; i < checkedItems_apply.length; i++){
                            checkedItems_apply [i] = false;
                            mUserItems_apply.clear();
                            f3_bt_apply.setText("Select an answer");
                        }
                    }
                });

                AlertDialog mDialog = mBuilder.create();
                mDialog.show();

            }
        });

        listItems_fetapp = new String[]{
                "Side dressing", "Broadcasting", "Drilling", "Spraying", "Ringing", "Other"};
        checkedItems_fetapp = new boolean[listItems_fetapp.length];
        f3_bt_fetapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
                mBuilder.setTitle("Who own the lands you farm on?");
                mBuilder.setMultiChoiceItems(listItems_fetapp, checkedItems_fetapp, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                        if(isChecked){
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            if(!mUserItems_fetapp.contains(position)){
                                mUserItems_fetapp.add(position);
                                Log.d("**MULTI CHOICE**", mUserItems_fetapp.toString());
                            }
                        }else {
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            mUserItems_fetapp.remove(position);
                            Log.d("**MULTI CHOICE2**", mUserItems_fetapp.toString());
                        }
                    }
                });
                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String item = "";
                        for (int i = 0; i< mUserItems_fetapp.size(); i++){
                            item = item + listItems_fetapp [mUserItems_fetapp.get(i)];
                            if( i != mUserItems_fetapp.size() -1){
                                item = item + ", ";
                            }
                        }
                        f3_bt_fetapp.setText(item);
                    }
                });
                mBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                mBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for (int i = 0; i < checkedItems_fetapp.length; i++){
                            checkedItems_fetapp [i] = false;
                            mUserItems_fetapp.clear();
                            f3_bt_fetapp.setText("Select an answer");
                        }
                    }
                });

                AlertDialog mDialog = mBuilder.create();
                mDialog.show();

            }
        });


        listItems_control = new String[]{
        "Chemical control", "Mechanical/Physial control", "Cultural control", "Biological control"};
        checkedItems_control = new boolean[listItems_control.length];
        f3_bt_control.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
                mBuilder.setTitle("Who own the lands you farm on?");
                mBuilder.setMultiChoiceItems(listItems_control, checkedItems_control, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                        if(isChecked){
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            if(!mUserItems_control.contains(position)){
                                mUserItems_control.add(position);
                                Log.d("**MULTI CHOICE**", mUserItems_control.toString());
                            }
                        }else {
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            mUserItems_control.remove(position);
                            Log.d("**MULTI CHOICE2**", mUserItems_control.toString());
                        }
                    }
                });
                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String item = "";
                        for (int i = 0; i< mUserItems_control.size(); i++){
                            item = item + listItems_control [mUserItems_control.get(i)];
                            if( i != mUserItems_control.size() -1){
                                item = item + ", ";
                            }
                        }
                        f3_bt_control.setText(item);
                    }
                });
                mBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                mBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for (int i = 0; i < checkedItems_control.length; i++){
                            checkedItems_control [i] = false;
                            mUserItems_control.clear();
                            f3_bt_control.setText("Select an answer");
                        }
                    }
                });

                AlertDialog mDialog = mBuilder.create();
                mDialog.show();

            }
        });


        listItems_fung = new String[]{
        "Foliar spraying", "Granular application", "Dusting", "Seed dressing"};
        checkedItems_fung = new boolean[listItems_fung.length];
        f3_bt_fung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(getActivity());
                mBuilder.setTitle("Who own the lands you farm on?");
                mBuilder.setMultiChoiceItems(listItems_fung, checkedItems_fung, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                        if(isChecked){
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            if(!mUserItems_fung.contains(position)){
                                mUserItems_fung.add(position);
                                Log.d("**MULTI CHOICE**", mUserItems_fung.toString());
                            }
                        }else {
                            Log.d("**CHECKED**", String.valueOf(isChecked));
                            mUserItems_control.remove(position);
                            Log.d("**MULTI CHOICE2**", mUserItems_control.toString());
                        }
                    }
                });
                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String item = "";
                        for (int i = 0; i< mUserItems_fung.size(); i++){
                            item = item + listItems_fung [mUserItems_fung.get(i)];
                            if( i != mUserItems_fung.size() -1){
                                item = item + ", ";
                            }
                        }
                        f3_bt_fung.setText(item);
                    }
                });
                mBuilder.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                mBuilder.setNeutralButton("Clear all", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for (int i = 0; i < checkedItems_fung.length; i++){
                            checkedItems_fung [i] = false;
                            mUserItems_fung.clear();
                            f3_bt_fung.setText("Select an answer");
                        }
                    }
                });

                AlertDialog mDialog = mBuilder.create();
                mDialog.show();

            }
        });

   }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
         if (parent.getId() == R.id.f3_sp_tractor) {
             String selected = parent.getSelectedItem().toString();
    /*        if(selected == "Select"){
                Toast.makeText(getActivity()," Please select an answer!", Toast.LENGTH_SHORT).show();
            }*/
             if (selected == "No") {
                 //f1_FBO.setVisibility(View.VISIBLE);
                 f3_Layout_tractor.setVisibility(View.VISIBLE);
                 f3_sp_tractorNo.setVisibility(View.VISIBLE);
             } else {
                 //f1_FBO.setVisibility(View.GONE);
                 f3_Layout_tractor.setVisibility(View.GONE);
                 f3_sp_tractorNo.setVisibility(View.GONE);
             }
         } else if (parent.getId() == R.id.f3_sp_weedicides) {
            String selected = parent.getSelectedItem().toString();
    /*        if(selected == "Select"){
                Toast.makeText(getActivity()," Please select an answer!", Toast.LENGTH_SHORT).show();
            }*/
            if (selected == "Yes") {
                //f1_FBO.setVisibility(View.VISIBLE);
                f3_Layout_weedi.setVisibility(View.VISIBLE);

            } else {
                //f1_FBO.setVisibility(View.GONE);
                f3_Layout_weedi.setVisibility(View.GONE);
            }
        }
         else if (parent.getId() == R.id.f3_sp_labo) {
             String selected = parent.getSelectedItem().toString();
             if (selected == "Yes") {
                 //f1_FBO.setVisibility(View.VISIBLE);
                 f3_tx_yes.setVisibility(View.VISIBLE);
                 f3_bt_yes.setVisibility(View.VISIBLE);

             } else {
                 //f1_FBO.setVisibility(View.GONE);
                 f3_tx_yes.setVisibility(View.GONE);
                 f3_bt_yes.setVisibility(View.GONE);

             }
         }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        showDatePickerDialog();
    }
    private void showDatePickerDialog(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                getActivity(), this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        );
        datePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String date = dayOfMonth +"/"+month+"/"+year;
        f3_bt_when.setText(date);
    }
}
