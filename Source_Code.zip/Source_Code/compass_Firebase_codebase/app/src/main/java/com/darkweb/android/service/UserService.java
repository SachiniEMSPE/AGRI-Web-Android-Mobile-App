package com.darkweb.android.service;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.darkweb.android.dao.UserDao;
import com.darkweb.android.login.HttpSignupLogin;
import com.darkweb.android.model.ObjectsForMapper.BackendClient;
import com.darkweb.android.model.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;


public class UserService {

    UserDao userDao;

    public UserService(){
        userDao=new UserDao();

    }
    public User getUserSignedIn(Context context)
    {
        return userDao.getUserSignedIn(context);
    }

    public boolean signInUser(Context context,User user, int itemId, TextView errorTextView) {

//        if(userAdded(context, user)) {
//            if(errorTextView!=null)
//                errorTextView.setText("");
//           // return  true;
//        }
//        else {
//            if(errorTextView!=null)
//                errorTextView.setText("userAdded() error!");
//           // return false;
//        }

        /**
         * Sending request to backend for registering
         */
        ObjectMapper objectMapper = new ObjectMapper();
        Boolean login = false;
        String userDataToBackend = null;
        try {
            userDataToBackend = objectMapper.writeValueAsString(user);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        String result = "";
        try {
            result = new HttpSignupLogin().execute(userDataToBackend, "login").get();
            JSONObject serverResult = new JSONObject(result);
            String userInfoJSON = serverResult.getString("message");
            ObjectMapper mapper = new ObjectMapper();
            BackendClient client =
                mapper.readValue(userInfoJSON, BackendClient.class);
            login = serverResult.getBoolean("success");
            SharedPreferences sp = context.getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putInt("MobileClientID", client.getId());
            editor.putString("MobileClientName", client.getName());
            editor.apply();

        } catch (ExecutionException | InterruptedException | JSONException | JsonProcessingException e) {
            e.printStackTrace();
        }
        if (login) {
            if(errorTextView!=null) errorTextView.setText("");
            return true;
        } else {
            if(errorTextView!=null) errorTextView.setText("userAdded() error!");
            return false;
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public  boolean signOutUser(Context context)
    {
        context.deleteSharedPreferences("MobileClient");
        return true;
//        return  userDao.signOutUser(context);
    }

    private  boolean userAdded(Context context,User user) {
        return userDao.userAdded(context,user);
    }

    private  User userinUserList(Context context,User user) {

        return userDao.userinUserList(context,user);
    }
    public  boolean addUserInList(Context context, User user)
    {
        return  userDao.addUserInList(context,user);
    }


    public  boolean removeUserInList(Context context, User user)
    {
        return userDao.removeUserInList(context,user);
    }

}
