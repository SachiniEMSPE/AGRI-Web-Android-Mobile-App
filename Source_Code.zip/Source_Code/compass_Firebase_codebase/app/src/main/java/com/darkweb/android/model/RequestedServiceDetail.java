package com.darkweb.android.model;

//This object is used to deserialize the json from server

public class RequestedServiceDetail {

}
