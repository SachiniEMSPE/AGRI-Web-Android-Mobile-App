package com.darkweb.android.adapter;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import androidx.annotation.*;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.compass.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by kotak on 07/06/2018.
 */

public class CustomServiceListAdapter extends ArrayAdapter<ServiceDetails>{
    private final Activity context;
    private final ArrayList<ServiceDetails> serviceList;
    private  ArrayList<ServiceDetails> arrayList;


    public CustomServiceListAdapter(Activity context, ArrayList<ServiceDetails> serviceList) {
        super(context, R.layout.servicelistview,serviceList);
        this.context = context;
        this.serviceList = serviceList;
        this.arrayList=new ArrayList<ServiceDetails>();
        this.arrayList.addAll(serviceList);
    }

    @RequiresApi(api = Build.VERSION_CODES.N) //this is required for '.color '
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ServiceDetails serviceDetailsObj=serviceList.get(position);
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.custom_service_list_adapter_view, null,true);
        TextView serviceName=(TextView)rowView.findViewById(R.id.servicename_textview);
        TextView serviceDescription=(TextView)rowView.findViewById(R.id.service_description_textView);
        ImageView iconImage=(ImageView) rowView.findViewById(R.id.service_image_icon);
        TextView lastupdatedDate=(TextView) rowView.findViewById(R.id.last_updateddate);
        String pattern = "EEEE MM/dd/yyyy hh:mm a";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        //lastupdatedDate.setText(simpleDateFormat.format(new Date(serviceDetailsObj.getRequestingServiceDate())));//sach changed as submissionDate
        lastupdatedDate.setText(simpleDateFormat.format(new Date(serviceDetailsObj.getSubmissionDate())));
        //
        serviceName.setText(serviceDetailsObj.getOrganizationDescription().getOrganizationName());//sach added context | @RequiresApi(api = Build.VERSION_CODES.N) | context removed to convert back to previous version
        //serviceDescription.setText(serviceDetailsObj.getServiceDescription()); //sach changed as below
        serviceDescription.setText(serviceDetailsObj.getComments());
        //if(serviceDetailsObj.getStatus().equals(context.getString(R.string.pending_status_service_request))) //sach changed changed 0 = pending
        if(serviceDetailsObj.getStatusArray().get(0).equals(context.getString(R.string.pending_status_service_request)))
        {
            serviceName.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
            serviceDescription.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
            lastupdatedDate.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
            iconImage.setImageDrawable(context.getResources().getDrawable(R.drawable.progress_led_icron));
            //iconImage.setBackgroundColor(R.drawable.pending_led_icon);
        }
        //else if (serviceDetailsObj.getStatus().equals(context.getString(R.string.cancelled_status_service_request))) //sach changed 0 = pending
        else if (serviceDetailsObj.getStatusArray().get(0).equals(context.getString(R.string.cancelled_status_service_request)))
        {
            Log.d("Apdapter-list",serviceDetailsObj.getTitle()+" || "+serviceDetailsObj.getStatusArray().get(0)); //sach changed getServiceRequestName > getTitle() / changed getStatus() > statusArray(0)
            serviceName.setTextColor(context.getColor(R.color.grey_color));
            serviceDescription.setTextColor(context.getColor(R.color.grey_color));
            lastupdatedDate.setTextColor(context.getColor(R.color.grey_color));
            iconImage.setImageDrawable(context.getResources().getDrawable(R.drawable.cancel_led_icon));
        }
        else
        {
            serviceName.setTextColor(context.getColor(R.color.grey_color));
            serviceDescription.setTextColor(context.getColor(R.color.grey_color));
            lastupdatedDate.setTextColor(context.getColor(R.color.grey_color));
            iconImage.setImageDrawable(context.getResources().getDrawable(R.drawable.completed_led_icon));
        }

    /*    if(new Date(serviceDetailsObj.getExpectingServiceDate().replaceAll("\\s","")+" "+serviceDetailsObj.getExpectingtime().replaceAll("\\s","")).compareTo(new Date()) < 0) {
     //       serviceName.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
       //    serviceDescription.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
        //  lastupdatedDate.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
          //  rowView.setBackgroundColor(context.getColor(R.color.blackText));
        }
        else
        {
            serviceName.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
            serviceDescription.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
            lastupdatedDate.setTextColor(context.getColor(R.color.cfdialog_button_black_text_color));
        }
        //rowView.setBackgroundColor(context.getColor(R.color.white));*/
        return rowView;
    }

    //@RequiresApi(api = Build.VERSION_CODES.N) //sach commented
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        serviceList.clear();
        if (charText.length() == 0) {
            serviceList.addAll(arrayList);
        }
        else
        {
            for (ServiceDetails sd : arrayList)
            {
                if (sd.getRequestUID().toString().toLowerCase(Locale.getDefault()).contains(charText))//sach chnaged serviceID >requestUID
                {
                    serviceList.add(sd);
                }
                //else if(sd.getServiceDescription().toString().toLowerCase(Locale.getDefault()).contains(charText)) //sach changed as below
                else if(sd.getComments().toString().toLowerCase(Locale.getDefault()).contains(charText))
                {
                    serviceList.add(sd);
                }
                else if(sd.getOrganizationDescription().getOrganizationName().toLowerCase(Locale.getDefault()).contains(charText))//sach added context | @RequiresApi(api = Build.VERSION_CODES.N) | context removed and converted back to previous version
                {
                    serviceList.add(sd);
                }
                else
                {}
            }
        }
        notifyDataSetChanged();
    }

}
