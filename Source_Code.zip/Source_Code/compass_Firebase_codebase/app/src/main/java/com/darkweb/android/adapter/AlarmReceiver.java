package com.darkweb.android.adapter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.darkweb.android.model.CalandarEvent;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.compass.HomePage;
import com.darkweb.android.compass.R;
import com.darkweb.android.compass.fragments.ServiceRequested;
import com.darkweb.android.compass.ViewCalandarEvent;

import java.util.UUID;

import static android.app.NotificationManager.IMPORTANCE_DEFAULT;

public class AlarmReceiver extends BroadcastReceiver{
    private static final String CHANNEL_ID = "com.darkweb.android.mycalendar";

    @Override
    public void onReceive(Context context, Intent intent) {
        String objectType=intent.getStringExtra(context.getString(R.string.ObjectType));
        String notificationTitle = "",notificationContent="",notificationTicker="";
        UUID uuid=(UUID) intent.getSerializableExtra("id");
        if(uuid==null)
            return;
        Log.d("rectype:",objectType+" id:"+uuid);
        Intent notificationIntent=null;
            if (objectType.equals(context.getString(R.string.calandarEventObject))) {
                CalandarEvent calandarEventObject = CalandarEvent.getCalendarEventObject(uuid,context);
                notificationTitle = calandarEventObject.getEventName();
                notificationContent = calandarEventObject.getEventDateTime().toString();
                notificationTicker = "Calender Event";
                notificationIntent = new Intent(context, ViewCalandarEvent.class);
            } else if (objectType.equals(context.getString(R.string.ServiceDetailsObject))) {
                ServiceDetails serviceDetailsObj = ServiceDetails.getServiceDetailsObject(uuid,context);
             //null pointer exception
                Log.d("null:",(serviceDetailsObj==null)+"");
                if(serviceDetailsObj!=null)
                {
                    notificationTitle = serviceDetailsObj.getTitle(); ////sach changed serviceRequestName>title / getServiceRequestName > getTitle() / setServiceRequestName > setTitle()
                    //notificationContent = serviceDetailsObj.getStatus();//sach changed
                    notificationContent = serviceDetailsObj.getStatusArray().get(0);
                }
                notificationTicker = "Sevice Details";
                notificationIntent = new Intent(context, ServiceRequested.class);
            }
        notificationIntent.putExtra(context.getString(R.string.id), uuid);
        notificationIntent.putExtra(context.getString(R.string.ObjectType),objectType);


        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
        stackBuilder.addParentStack(HomePage.class);
        stackBuilder.addNextIntent(notificationIntent);

        PendingIntent pendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
         Notification.Builder builder = new Notification.Builder(context);

        Notification notification = builder.setContentTitle(notificationTitle)
                .setContentText(notificationContent)
                .setTicker(notificationTicker)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent).build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(CHANNEL_ID);
        }

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "NotificationDemo",
                    IMPORTANCE_DEFAULT
            );
            notificationManager.createNotificationChannel(channel);
        }
        notificationManager.notify(0, notification);
    }




}