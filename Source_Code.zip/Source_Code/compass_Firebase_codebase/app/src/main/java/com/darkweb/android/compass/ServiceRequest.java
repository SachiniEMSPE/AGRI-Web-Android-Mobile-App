package com.darkweb.android.compass;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.annotation.*;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;

import com.darkweb.android.login.LoginActivity;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.model.User;
import com.darkweb.android.parser.JsontoObject;
import com.darkweb.android.service.LocationDescriptionServices;
import com.darkweb.android.service.UserService;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import com.darkweb.android.adapter.sachExpandableListAdapter;

public class ServiceRequest extends AppCompatActivity {

    Spinner category_name_spinner,service_name_spinner,serviceDescriptionList;
    AutoCompleteTextView organizationAutoTextView;
    Dialog dialog;
    String selectCategoryText="Select Category";
    String selectOrganisationText="Select Organization";
    ArrayList<OrganizationDescription> finalOrganizationDescriptionArrayList;
    ArrayList<String> categories = new ArrayList<String>();
    ArrayList<String> organisationServices = new ArrayList<String>();
    ArrayAdapter<String> organisationArrayAdapter;
    FloatingActionButton fab1;
    ArrayList<ServiceDetails> sdList;
    String url;
    UserService userService;
    static EditText serviceDescription,addServiceNameTextView;
    static Button submit;
    TextView expectingtime, expectingDate;
    final Calendar myCalendar = Calendar.getInstance();
    boolean cateFlag=false;
    DatePickerDialog.OnDateSetListener addserviceDateListener,addEventDateListener;

    TextView operating_time, service_description, service_address, service_website, service_phone,languages;//sach_added languages
    ArrayList<String> programListOrganisation=new ArrayList<String>();
    ArrayList<ArrayList<String>> serviceListOrganisation = new ArrayList<ArrayList<String>>();


    static String result = "";
    OrganizationDescription organizationDescriptionObj;
    ArrayList<String> serviceAutoListOrganisation=new ArrayList<String>();
    ArrayAdapter<String> categoryArrayAdapter;
    static InputStream is = null;
    static String json = "";
    static JSONObject jobj = null;


    static ArrayList<String> mylist =new ArrayList<String>();

    int hours,minutes;
    private TableLayout tableLayout;
    User user;
    private EditText addServiceTimeEditText,addServiceDateEditText;
    private TextView addReminderTextView;
    private Calendar myCalendar1;
    private TextView event_name_textview;
    private TextView event_description;
    private EditText eventDateEditText;
    private EditText eventTimeEditText;
    private Spinner programDescriptionList;
    public CardView cardView;
    private LinearLayout organizationDataLinear;
    private ExpandableListView listView;//sach_added

    private sachExpandableListAdapter listAdapter ;//sach_added - for program list view
    List<String> listDataHeader = null;//sach_added
    HashMap<String, List<String>> listHash = null;//sach_added

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_service_request);
        CardView cardView = (CardView) findViewById(R.id.cv2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
      //  toolbar.setTitleTextColor(toolbar.getSolidColor());

        userService=new UserService();
        fab1 = findViewById(R.id.addservicefab);
        user = userService.getUserSignedIn(ServiceRequest.this);
        operating_time = (TextView) findViewById(R.id.operating_time);
        languages =(TextView) findViewById(R.id.languages); //sach_added
        service_description = (TextView) findViewById(R.id.service_description);
        service_address = (TextView) findViewById(R.id.service_address);
        service_website = (TextView) findViewById(R.id.service_website);
        service_phone = (TextView) findViewById(R.id.service_phone);
        organizationDataLinear=(LinearLayout) findViewById(R.id.organizationDataLinear);
        organizationAutoTextView=(AutoCompleteTextView)findViewById(R.id.Organization_name_searchview);
        category_name_spinner = (Spinner)findViewById(R.id.spinner_category_name);
        service_name_spinner = (Spinner)findViewById(R.id.spinner_service_name);
        organizationDataLinear.setVisibility(View.GONE);
        fab1.hide();
        fab1.setEnabled(false);
        service_address.setEnabled(false);
        operating_time.setEnabled(false);
        languages.setEnabled(false);
        service_phone.setEnabled(false);
        service_website.setEnabled(false);
        service_description.setEnabled(false);
        service_name_spinner.setEnabled(false);

        SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);

        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if (local_user_id == 0)
                {
                    AlertDialog.Builder alertDialog=new AlertDialog.Builder(ServiceRequest.this);
                    // Setting Dialog Title
                    alertDialog.setTitle("Sign in");
                    // Setting Dialog Message
                    alertDialog.setMessage("You need to sign In to add service. Would you like to sign in?");
                    alertDialog.setCancelable(false);
                    // Setting alert dialog icon
                    alertDialog.setIcon(R.drawable.ic_exit_to_app_black_24dp);
                    alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Log.d("btn clicked","GROWING FAB");
                            System.out.println("Button Pressed");
                            Intent intent = new Intent(ServiceRequest.this, LoginActivity.class);
                            startActivityForResult(intent, 1);

                        }
                    });
                    alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Log.d("btn clicked","GROWING FAB");

                        }
                    });
                    alertDialog.show();
                }
                else {
                 addServiceFab();
                }
            }
        });

        service_address.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.DONUT)
            @Override
            public void onClick(View v) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(service_address.getText().toString()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        service_website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(service_website.getText().toString()));
                startActivity(browserIntent);
            }
        });

        service_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent phoneIntent = new Intent(Intent.ACTION_CALL);
                phoneIntent.setData(Uri.parse("tel:"+ organizationDescriptionObj.getContact().replaceAll("[^0-9]", "")));
                try
                {
                    if(Build.VERSION.SDK_INT > 22)
                    {
                        if (ActivityCompat.checkSelfPermission(ServiceRequest.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(ServiceRequest.this, new String[]{Manifest.permission.CALL_PHONE}, 101);

                            return;
                        }

                        startActivity(phoneIntent);

                    }
                    else {
                        startActivity(phoneIntent);
                    }
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }

            }
        });

        new GetCourseCategoriesMarkerColor().execute();

    }

    private void addServiceFab() {
        LocationDescriptionServices.addServiceDeatailsObj(ServiceRequest.this, organizationDescriptionObj,null,"Request Service");
    }


    private class GetCourseCategoriesMarkerColor extends AsyncTask<Void, Void, Void> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress loading dialog
           progressDialog = new ProgressDialog(ServiceRequest.this);
            progressDialog.setMessage("Fetching data...");
            progressDialog.setCancelable(false);
            progressDialog.show();



            for (int i=0;i<3;i++)
            {
                programListOrganisation.add("program "+i);
                ArrayList<String> strList=new ArrayList<String>();
                for(int j=0;j<2;j++)
                {
                    strList.add("service "+i+" "+j);
                }
                serviceListOrganisation.add(strList);
            }
        }

        @TargetApi(Build.VERSION_CODES.N)
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                finalOrganizationDescriptionArrayList = JsontoObject.jsonToObjectData(getResources().openRawResource(R.raw.newdbnewformattaxonomyupdated));//sachUpdated new DB instead of schenectadymap

            } catch (IOException e) {
                e.printStackTrace();
            }

            //XMLParserJson.writeArraylistToFireBase(finalOrganizationDescriptionArrayList);
            setMarkerToList(finalOrganizationDescriptionArrayList);

            Log.d("cl:","cl added");
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            //XMLParserJson.writeArraylistToFireBase(finalOrganizationDescriptionArrayList);
            Log.d("size OrgList:",""+finalOrganizationDescriptionArrayList.size());

            category_name_spinner=(Spinner)findViewById(R.id.spinner_category_name);
            service_name_spinner=(Spinner)findViewById(R.id.spinner_service_name);
            //service_name_spinner.setEnabled(false);
            Collections.sort(categories);
            if (!categories.contains(selectCategoryText))
                categories.add(0,selectCategoryText);
            if (!organisationServices.contains(selectOrganisationText))
                organisationServices.add(0,selectOrganisationText);

            if (serviceAutoListOrganisation!=null )
            {
                if (organizationAutoTextView==null)
                {
                    organizationAutoTextView=findViewById(R.id.Organization_name_searchview);
                }
                ArrayAdapter<String> organizationAutoAdapter = new ArrayAdapter<String>(ServiceRequest.this,android.R.layout.select_dialog_item, serviceAutoListOrganisation);
                organizationAutoTextView.setAdapter(organizationAutoAdapter);
                organizationAutoTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String selectedItemText = parent.getItemAtPosition(position).toString();
                                               // create Toast with user selected value
                        Log.d("called:","orgTextView");
                       organizationDescriptionObj =getLocationDescriptionObject(selectedItemText);
                        cateFlag=true;
                        service_name_spinner.setEnabled(true);

                        category_name_spinner.setSelection(categoryArrayAdapter.getPosition(organizationDescriptionObj.getCategory()));

                        setOrganisationServices(organizationDescriptionObj.getCategory());

                        if (!organisationServices.contains(selectOrganisationText))
                            organisationServices.add(0,selectOrganisationText);
                        organisationArrayAdapter.notifyDataSetChanged();
                        service_name_spinner.setSelection(organisationArrayAdapter.getPosition(organizationDescriptionObj.getOrganizationName()));

                        updateCardDetails(organizationDescriptionObj);


                    }

                });
            }
            if (categories!=null ) {
                categoryArrayAdapter = new ArrayAdapter<String>(ServiceRequest.this,
                        android.R.layout.simple_spinner_item, categories)
                {
                    @Override
                    public boolean isEnabled(int position){
                        if(position == 0)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                    @Override
                    public View getDropDownView(int position, View convertView,
                                                ViewGroup parent) {
                        View view = super.getDropDownView(position, convertView, parent);
                        TextView tv = (TextView) view;
                        if(position == 0){
                            // Set the hint text color gray
                            tv.setTextColor(Color.GRAY);
                        }
                        else {
                            tv.setTextColor(Color.BLACK);
                        }
                        return view;
                    }
                };
                category_name_spinner.setAdapter(categoryArrayAdapter);
            }
            category_name_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    Log.d("called:","categorySpinner"+position+"  d:"+cateFlag);
                    String selectedItemText = (String) parent.getItemAtPosition(position);
                    // If user change the default selection
                    // First item is disable and it is used for hint
                    if(position > 0){
                        // Notify the selected item text

                        service_name_spinner.setEnabled(true);
                        Log.d("called:","categorySpinner"+selectedItemText);

                        setOrganisationServices(selectedItemText);

                        if (!organisationServices.contains(selectOrganisationText))
                            organisationServices.add(0,selectOrganisationText);
                        organisationArrayAdapter.notifyDataSetChanged();
                        if(cateFlag==false)
                        {
                            updateCardDetails(null);
                            service_name_spinner.setSelection(0);
                            organizationAutoTextView.setText("");
                        }


                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });


            if (organisationServices!=null ) {
                organisationArrayAdapter = new ArrayAdapter<String>(ServiceRequest.this,
                        android.R.layout.simple_spinner_item, organisationServices)
                {
                    @Override
                    public boolean isEnabled(int position){
                        if(position == 0)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                    @Override
                    public View getDropDownView(int position, View convertView,
                                                ViewGroup parent) {
                        View view = super.getDropDownView(position, convertView, parent);
                        TextView tv = (TextView) view;
                        if(position == 0){
                            // Set the hint text color gray
                            tv.setTextColor(Color.GRAY);
                        }
                        else {
                            tv.setTextColor(Color.BLACK);
                        }
                        return view;
                    }
                };
                service_name_spinner.setAdapter(organisationArrayAdapter);
            }
            service_name_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                    Log.d("called:","serviceSpinner");
                    String selectedItemText = (String) parent.getItemAtPosition(position);

                    // If user change the default selection
                    // First item is disable and it is used for hint
                    if(position > 0){
                        if (cateFlag==false) {
                            organizationDescriptionObj =getLocationDescriptionObject(selectedItemText);
                            updateCardDetails(organizationDescriptionObj);
                             Log.d("set:",selectedItemText.toString());
                            organizationAutoTextView.setText(selectedItemText);

                        }
                        else
                        {
                            cateFlag=false;
                        }
                    }

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            if (progressDialog.isShowing())
                progressDialog.hide();
        }
    }

    private void updateCardDetails(OrganizationDescription organizationDescriptionObj) {
//        cardView.setVisibility(View.VISIBLE);
        if (organizationDescriptionObj !=null)
        {
            organizationDataLinear.setVisibility(View.VISIBLE);
            fab1.show();
            //fab1.setVisibility(View.VISIBLE);
            fab1.setEnabled(true);
            service_address.setEnabled(true);
            operating_time.setEnabled(true);
            languages.setEnabled(true);//sach_added
            service_phone.setEnabled(true);
            service_website.setEnabled(true);
            service_description.setEnabled(true);
            if (organizationDescriptionObj.getHours().trim().length() > 0)
                operating_time.setText(organizationDescriptionObj.getHours());
            else
                operating_time.setText("N/A");

            if(organizationDescriptionObj.getLanguages().isEmpty())
                languages.setText("N/A"); //sach_added
            else
                languages.setText(organizationDescriptionObj.getLanguages());

            if(organizationDescriptionObj.getContact().isEmpty())
                service_phone.setText("N/A");
            else
                service_phone.setText(organizationDescriptionObj.getContact());


            if(organizationDescriptionObj.getDescription().isEmpty())
                service_description.setText("N/A");
            else
                service_description.setText(organizationDescriptionObj.getDescription());

            if(organizationDescriptionObj.getWebsite().isEmpty())
                service_website.setText("N/A");
            else
                service_website.setText(organizationDescriptionObj.getWebsite());

            if(organizationDescriptionObj.getStreetAddress().isEmpty())
                service_address.setText("N/A");
            else
                service_address.setText(organizationDescriptionObj.getStreetAddress() + ".\n" + organizationDescriptionObj.getCity() + ", " + organizationDescriptionObj.getState() + " " + organizationDescriptionObj.getZipcode());

            //sach_added - to update program expandable list view
            listView = (ExpandableListView) findViewById(R.id.expandableListView);
            initData();
            listAdapter = new sachExpandableListAdapter(this,listDataHeader,listHash);
            listView.setAdapter(listAdapter);

            //sach_added when program list item clicked move to service info view.
            listView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
                @Override
                public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                    String programName = String.valueOf(listAdapter.getChild(groupPosition,childPosition));
                    LocationDescriptionServices.sachAddServiceObj(ServiceRequest.this,organizationDescriptionObj,null,programName);
                    return false;
                }
            });

            //sach_added to change read more / read less in programs
            listView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
                @Override
                public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                    TextView textView = (TextView) findViewById(R.id.button_toggleProgram);
                    if(listView.isGroupExpanded(0)){
                        textView.setText("Read More...");
                    }else{
                        textView.setText("Read Less...");
                    }
                    return false;
                }
            });

        }
        else {
            organizationDataLinear.setVisibility(View.GONE);
            fab1.hide();
            //fab1.setVisibility(View.GONE);
            fab1.setEnabled(false);
            service_address.setText("");
            service_address.setEnabled(false);
            operating_time.setText("");
            operating_time.setEnabled(false);
            languages.setText("");//sach_added
            languages.setEnabled(false);//sach_added
            service_phone.setText("");
            service_phone.setEnabled(false);
            service_website.setText("");
            service_website.setEnabled(false);
            service_description.setText("");
            service_description.setEnabled(false);
        }
        //cateFlag=false;

    }

    //sach_added to read programs
    private void initData() {
        listDataHeader = new ArrayList<>();
        listHash = new HashMap<>();
        listDataHeader.add("Programs");
        List<String> programs = new ArrayList<>();
        programs = organizationDescriptionObj.getProgramList();
        listHash.put(listDataHeader.get(0),programs);
    }

    //sach_get object description as per the org name
    private OrganizationDescription getLocationDescriptionObject(String selectedItemText) {
        if (finalOrganizationDescriptionArrayList==null)
            return null;
       for(OrganizationDescription locDescObj:finalOrganizationDescriptionArrayList)
            {
                if (locDescObj.getOrganizationName().equals(selectedItemText))
                {
                    return locDescObj;
                }
            }
        return null;
    }

    //sach_to update org name service list with selected category list in spinner
    private void setOrganisationServices(String selectedItemText) {
        organisationServices.clear();

            for(OrganizationDescription locDescObj:finalOrganizationDescriptionArrayList)
            {
                if (locDescObj.getCategory().contains(selectedItemText)) //sach_changed > equal()
                {
                    organisationServices.add(locDescObj.getOrganizationName());
                }
            }
        Collections.sort(organisationServices);
    }

//sach_noneed : color
    private void setMarkerToList(ArrayList<OrganizationDescription> organizationDescriptionArrayList) {
        String color = "";
        for (OrganizationDescription locationDes : organizationDescriptionArrayList)
        {
            serviceAutoListOrganisation.add(locationDes.getOrganizationName());
            //locationDes.setServiceList(serviceListOrganisation); sach_commented
            //locationDes.setProgramList(programListOrganisation); sach_commented
            if (!categories.contains(locationDes.getCategory())) {
                categories.add(locationDes.getCategory());
            }
        }
    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        addServiceDateEditText.setText(sdf.format(myCalendar.getTime()));
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if (requestCode == 1)
        {
            user = userService.getUserSignedIn(ServiceRequest.this);
            if (user != null)
            {
                addServiceFab();
            }
            else
            {/*
                if(fab!=null)
                    fab.closeMenu();*/
            }
        }
    }

}
