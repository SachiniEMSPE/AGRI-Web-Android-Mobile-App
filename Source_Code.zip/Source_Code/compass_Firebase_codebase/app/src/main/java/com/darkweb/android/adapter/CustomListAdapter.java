package com.darkweb.android.adapter;

import android.app.Activity;
import androidx.annotation.*;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.compass.R;

import java.util.ArrayList;

/**
 * Created by kotak on 07/06/2018.
 */

public class CustomListAdapter extends ArrayAdapter<OrganizationDescription>{
    private final Activity context;
    private final ArrayList<OrganizationDescription> serviceList;


    public CustomListAdapter(Activity context, ArrayList<OrganizationDescription> serviceList) {
        super(context, R.layout.servicelistview,serviceList);
        this.context = context;
        this.serviceList = serviceList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        OrganizationDescription locationobj=serviceList.get(position);
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.servicelistview, null,true);
        TextView serviceName=(TextView)rowView.findViewById(R.id.servicename);
        TextView categoryName=(TextView)rowView.findViewById(R.id.categoryName);
        TextView distance = (TextView) rowView.findViewById(R.id.distance);//sach added
        serviceName.setText(locationobj.getOrganizationName());
        categoryName.setText(locationobj.getDescription());//sach changed
        distance.setText("  ("+String.format("%.02f", locationobj.getDistance())+" miles)");//sach added
        //categoryName.setText(locationobj.getCategory()+"  ("+String.format("%.02f", locationobj.getDistance())+" miles)");
        //categoryName.setText("  ("+String.format("%.02f", locationobj.getDistance())+" miles)"); //sach changed this

        return rowView;
    }

}
