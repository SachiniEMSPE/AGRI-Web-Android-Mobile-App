package com.darkweb.android.compass;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.Message;
import com.darkweb.android.service.MessageServices;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class OrganisationChatActivity extends AppCompatActivity {

    private ListView orgChatListView;
    private OrganizationDescription locationDescObj;
    private HashMap<String, ArrayList<Message>> messagMapList;
    private ArrayList<String> userList=new ArrayList<String>();
    private ArrayAdapter<String> messageListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organisation_chat);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Chat with Users");
        locationDescObj=(OrganizationDescription) getIntent().getSerializableExtra("serviceObject");
        orgChatListView=(ListView) findViewById(R.id.orgchatlistview);


    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent(OrganisationChatActivity.this,ViewServices.class);
        startActivity(intent);
        finish();
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(userList.size()>0)
            userList.clear();
        messagMapList= MessageServices.getMessagListOrganisation(OrganisationChatActivity.this,locationDescObj.getOrganizationName());
        for ( String key : messagMapList.keySet() ) {
            Log.d("keys:",key);
            userList.add(key);
        }
        if(messageListAdapter==null) {
            messageListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, userList);
            orgChatListView.setAdapter(messageListAdapter);
        }
        else
            messageListAdapter.notifyDataSetChanged();

        Log.d("size:","c:"+messageListAdapter.getCount()+"  "+ "  list.size"+userList.size()+"  map:size"+messagMapList.size());
        orgChatListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String username=userList.get(position);
                ArrayList<Message> msgList=messagMapList.get(username);
                Intent intent =new Intent(OrganisationChatActivity.this,ChatActivity.class);
                intent.putExtra(getString(R.string.messagList),msgList);
                intent.putExtra(getString(R.string.from),getString(R.string.organisationChat));
                intent.putExtra(getString(R.string.serviceObject),locationDescObj);
                startActivity(intent);
            }
        });


    }
}
