package com.darkweb.android.compass;

import android.os.Bundle;

import com.darkweb.android.adapter.Page_adapter_services;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class Service_tab extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_service_tab,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TabLayout tabLayout = (TabLayout) view.findViewById(R.id.tabs_ser);
        tabLayout.addTab(tabLayout.newTab().setText("MY SERVICES"));
        tabLayout.addTab(tabLayout.newTab().setText("BOOKMARKS"));
        tabLayout.addTab(tabLayout.newTab().setText("PATHWAYS"));


        viewPager = (ViewPager)view.findViewById(R.id.viewpager_ser);



        final Page_adapter_services adapter = new Page_adapter_services
                (getChildFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);


        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        viewPager.setCurrentItem(0);
        viewPager.setOffscreenPageLimit(3);

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {


                if (tab.getPosition() == 0) {
                    viewPager.setCurrentItem(0);

                } else if (tab.getPosition() == 1) {
                    /**
                     * When bookmark tab has been clicked
                     */
                    viewPager.setCurrentItem(1);

                } else {
                    /**
                     * When pathways tab has been clicked
                     */
                    viewPager.setCurrentItem(2);

                }

            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

        });



    }

}
