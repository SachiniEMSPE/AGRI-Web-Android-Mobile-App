package com.darkweb.android.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.RequestedService;

import java.util.List;

public class RequestedServiceListAdapter extends ArrayAdapter<RequestedService> {

    private Context mContext;
    private int mResource;

    public RequestedServiceListAdapter(@NonNull Context context, int resource, List<RequestedService> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String OrganizationName = getItem(position).getOrganizationName();
        String LastUpdated = getItem(position).getLastUpdatedDate();
        String comment = getItem(position).getRequestedComment();
        String status = getItem(position).getStatus();

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView viewOrganizationName = convertView.findViewById(R.id.l_organization_name);
        TextView viewLastUpdated = convertView.findViewById(R.id.l_last_updateddate);
        TextView viewComment = convertView.findViewById(R.id.l_request_comment);
        ImageView statusIcon = convertView.findViewById(R.id.l_service_image_icon);

        viewOrganizationName.setText(OrganizationName);
        viewLastUpdated.setText(LastUpdated);
        viewComment.setText(comment);
        if (status.equalsIgnoreCase("pending")) {
            statusIcon.setImageDrawable(mContext.getResources().getDrawable(R.drawable.progress_led_icron));
        } else {
            statusIcon.setImageDrawable(mContext.getResources().getDrawable(R.drawable.cancel_led_icon));
        }
        return convertView;
    }
}
