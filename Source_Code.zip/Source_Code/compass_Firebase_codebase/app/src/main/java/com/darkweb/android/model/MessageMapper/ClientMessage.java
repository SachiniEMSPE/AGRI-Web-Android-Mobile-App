package com.darkweb.android.model.MessageMapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.sql.Timestamp;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientMessage {

    private MobileClient clientFrom;
    private MobileClient clientTo;
    private String content;
    private Timestamp createdAt;

    public MobileClient getClientFrom() {
        return clientFrom;
    }

    public void setClientFrom(MobileClient clientFrom) {
        this.clientFrom = clientFrom;
    }

    public MobileClient getClientTo() {
        return clientTo;
    }

    public void setClientTo(MobileClient clientTo) {
        this.clientTo = clientTo;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
}
