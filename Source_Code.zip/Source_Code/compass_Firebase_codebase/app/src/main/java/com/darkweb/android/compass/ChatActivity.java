package com.darkweb.android.compass;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.darkweb.android.adapter.MessageListAdapter;
import com.darkweb.android.adapter.MessagesNewAdapter;
import com.darkweb.android.dao.MessageSendDao;
import com.darkweb.android.model.MessageMapper.ClientMessage;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.Message;
import com.darkweb.android.model.User;
import com.darkweb.android.service.HttpHandlers.HttpMessageHandler;
import com.darkweb.android.service.MessageServices;
import com.darkweb.android.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

//ASk us in organization description
// To chat with organization

public class ChatActivity extends AppCompatActivity {

    private RecyclerView mMessageRecycler;
    private Button chatSendButton;
    private EditText inputMessageView;
    private User user;
    private ArrayList<Message> messageList;
    private OrganizationDescription organizationDescriptionObj;
    private MessageListAdapter mMessageAdapter;
    private String fromString;

    private List<ClientMessage> messages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_activity_layout);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        user = new UserService().getUserSignedIn(ChatActivity.this);
        // Asking magic SP to get our user information
        SharedPreferences sp = getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
        int local_user_id = sp.getInt("MobileClientID", 0);

        // None of the messages are getting from the local file system
//        organizationDescriptionObj =(OrganizationDescription)getIntent().getSerializableExtra(getString(R.string.serviceObject));
//        messageList=(ArrayList<Message>)getIntent().getSerializableExtra(getString(R.string.messagList));
//        fromString=(String)getIntent().getSerializableExtra(getString(R.string.from));
        // organizationId

        Intent intent = getIntent();
        String organizationId = intent.getStringExtra("organizationId");
        String organizationName = intent.getStringExtra("organizationName");
        Objects.requireNonNull(getSupportActionBar()).setTitle(organizationName);
        try {
            String msgJson = new HttpMessageHandler().execute(
                    "getmsg", String.valueOf(local_user_id), organizationId
                    ).get();

            ObjectMapper mapper = new ObjectMapper();
            messages =
                    mapper.readValue(msgJson, new TypeReference<List<ClientMessage>>() {});

        } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
            e.printStackTrace();
        }

//        Log.d("name:", organizationDescriptionObj.getOrganizationName());
//        if (fromString!=null && fromString.equals(getString(R.string.organisationChat)))
//            getSupportActionBar().setTitle(user.getUserName()+"");
//        else if(organizationDescriptionObj !=null)
//            getSupportActionBar().setTitle(organizationDescriptionObj.getOrganizationName()+"");
//        else
//            getSupportActionBar().setTitle("ASk us:");
//
//        if(fromString==null)
//            messageList= MessageServices.getUsersMessageListFromFile(ChatActivity.this,user.getUserName(), organizationDescriptionObj.getOrganizationName());
//        if(messageList==null)
//            messageList=new ArrayList<Message>();
//
//        if (fromString!=null && fromString.equals(getString(R.string.organisationChat)))
//        {
//            mMessageAdapter = new MessageListAdapter(this, messageList, user.getUserName(), organizationDescriptionObj.getOrganizationName(), organizationDescriptionObj.getOrganizationName());
//        }
//        else
//        {
//            mMessageAdapter = new MessageListAdapter(this, messageList, user.getUserName(), organizationDescriptionObj.getOrganizationName(),user.getUserName());
//        }


//        mMessageAdapter = new MessageListAdapter(this, messageList, user.getUserName(), organizationDescriptionObj.getOrganizationName(), organizationDescriptionObj.getOrganizationName());

        MessagesNewAdapter adapter = new MessagesNewAdapter(this, messages);
        mMessageRecycler = findViewById(R.id.reyclerview_message_list);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mMessageRecycler.setLayoutManager(mLayoutManager);
        mMessageRecycler.setItemAnimator(new DefaultItemAnimator());
        mMessageRecycler.setAdapter(adapter);

        inputMessageView = findViewById(R.id.edittext_chatbox);
//        scrollToBottom();

        chatSendButton = findViewById(R.id.button_chatbox_send);
        chatSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                try {
//                    attemptSend();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
                String text_in_box = inputMessageView.getText().toString();
                if (text_in_box.length() > 0) {
                    MessageSendDao msgToSend = new MessageSendDao(
                            local_user_id,
                            Integer.parseInt(organizationId),
                            true,
                            text_in_box
                    );
                    ObjectMapper mapper = new ObjectMapper();
                    try {
                        String result =
                        new HttpMessageHandler().execute(mapper.writeValueAsString(msgToSend)).get();
                        System.out.println("message sending result :" + result);
                        // clean up the input box
                        inputMessageView.setText("");
                        // refresh activity
                        finish();
                        startActivity(getIntent());
                    } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
//
//        inputMessageView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView v, int id, KeyEvent event) {
//                if (id == R.id.button_chatbox_send || id == EditorInfo.IME_NULL) {
//                    try {
//                        Log.d("enter","ere");
//                        attemptSend();
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                    return true;
//                }
//                return false;
//            }
//        });
//
//        inputMessageView.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                if (null == user) return;
//                if(null == organizationDescriptionObj) return;
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//            }
//        });




    }


    @Override
    public void onDestroy() {
    super.onDestroy();
    }


    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

//    private void scrollToBottom() {
////        mMessageRecycler.scrollToPosition(mMessageAdapter.getItemCount() - 1);
////    }

    private void attemptSend() throws Exception {
        if (null == user) return;
        String message = inputMessageView.getText().toString().trim();
        inputMessageView.setText("");

        Message messageObj=new Message();

        if(fromString!=null && fromString.equals(getString(R.string.organisationChat)))
            messageObj.setMessageAuthor(organizationDescriptionObj.getOrganizationName());
        else
            messageObj.setMessageAuthor(user.getUserName());

        messageObj.setCreatedDate(new Date());
        messageObj.setMessageId(UUID.randomUUID());
        messageObj.setMessageStatus(true);
        messageObj.setMessageText(message);
        messageObj.setOrganisationCategory(organizationDescriptionObj.getCategory());
        messageObj.setOrganisationName(organizationDescriptionObj.getOrganizationName());
        messageObj.setUpdatedDate(messageObj.getCreatedDate());
        messageObj.setUserName(user.getUserName());
        MessageServices.writeMessageToFile(ChatActivity.this,messageObj);





        if(messageList==null)
        {
            messageList=new ArrayList<Message>();
        }
        messageList.add(messageObj);
        mMessageAdapter.notifyDataSetChanged();
        mMessageRecycler.notifyAll();

    }

}
