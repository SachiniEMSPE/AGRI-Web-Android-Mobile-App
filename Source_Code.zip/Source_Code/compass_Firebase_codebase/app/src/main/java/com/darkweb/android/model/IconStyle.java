package com.darkweb.android.model;

public class IconStyle {	
	String x;
	String y;
	String xunits;
	String yunits;
	String color;
	String scale;
	String iconHref;

}
