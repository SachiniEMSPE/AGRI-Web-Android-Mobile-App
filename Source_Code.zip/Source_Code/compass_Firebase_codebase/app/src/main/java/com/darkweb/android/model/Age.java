package com.darkweb.android.model;

import java.io.Serializable;

/**
 * Created by kotak on 09/08/2018.
 */

public class Age implements Serializable {
    int fromAge;
    int toAge;
    int yourAge=-1;

    @Override
    public String toString() {
        return "Age{" +
                "fromAge=" + fromAge +
                ", toAge=" + toAge +
                ", yourAge=" + yourAge +
                '}';
    }

    public int getYourAge() {
        return yourAge;
    }

    public void setYourAge(int yourAge) {
        this.yourAge = yourAge;
    }

    public int getFromAge() {
        return fromAge;
    }

    public void setFromAge(int fromAge) {
        this.fromAge = fromAge;
    }

    public int getToAge() {
        return toAge;
    }

    public void setToAge(int toAge) {
        this.toAge = toAge;
    }
}
