package com.darkweb.android.login;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;


import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.darkweb.android.model.User;
import com.darkweb.android.compass.R;
import com.darkweb.android.service.UserService;
import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class UpdateProfileActivity extends AppCompatActivity {

    TextInputEditText fname,lname,username,pass,cnfpass,email,phone;
    EditText dob;
    Button register;
    String myFormat = "MM/dd/yy"; //In which you need put here
    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
    UserService userService;
    private RadioGroup radioSexGroup;
    Calendar myCalendar;;
    private String url;
    private File registerFile;
    private ArrayList<User> registerUserList;

    private RadioButton maleRadioButton;
    private RadioButton femaleRadioButton;
    private User user;
    private int itemId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        userService=new UserService();
        user= userService.getUserSignedIn(UpdateProfileActivity.this);

        fname = findViewById(R.id.first_name);
        lname = findViewById(R.id.last_name);
        username = findViewById(R.id.user_name);
        pass = findViewById(R.id.password);
        cnfpass = findViewById(R.id.confirm_password);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone_number);
        dob = findViewById(R.id.date_of_birth);
        dob.setInputType(InputType.TYPE_NULL);
        fname.setText(user.getFirstName());
        lname.setText(user.getLastName());
        username.setText(user.getUserName());
        email.setText(user.getEmailId());
        phone.setText(user.getPhoneNumber());
        if (user.getDateOfBirth()!=null)
            dob.setText(sdf.format(user.getDateOfBirth()));
        pass.setText(user.getPassword());
        cnfpass.setEnabled(false);
        username.setEnabled(false);
        itemId=getIntent().getIntExtra(getString(R.string.itemId),0);

        pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(pass.getText().toString().equals(user.getPassword()))
                    cnfpass.setEnabled(false);
                else
                    cnfpass.setEnabled(true);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        myCalendar = Calendar.getInstance();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };




        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePicker= new DatePickerDialog(UpdateProfileActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                datePicker.getDatePicker().setMaxDate(new Date().getTime());
                datePicker.setCancelable(false);

                datePicker.show();
            }
        });


        radioSexGroup = (RadioGroup) findViewById(R.id.radioSex);
        maleRadioButton = (RadioButton) findViewById(R.id.radioMale);
        femaleRadioButton=(RadioButton)findViewById(R.id.radioFemale);
        maleRadioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    femaleRadioButton.setChecked(false);
            }
        });
        femaleRadioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    maleRadioButton.setChecked(false);
            }
        });


        register = findViewById(R.id.register);
        register.setText("Update Profile");
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean userAdding=true;


                if(fname.getText().toString().isEmpty())
                {
                    fname.setError("Enter First Name");
                    userAdding=false;
                }
                if(lname.getText().toString().isEmpty())
                {
                    lname.setError("Enter Last Name");
                    userAdding=false;
                }
                if(pass.getText().toString().isEmpty())
                {
                    pass.setError("Enter Password");
                    userAdding=false;

                }
                if(cnfpass.getText().toString().isEmpty() && cnfpass.isEnabled())
                {
                    cnfpass.setError("Enter Confirm Password");
                    userAdding=false;

                }
                if(!pass.getText().toString().isEmpty() && !cnfpass.getText().toString().isEmpty())
                {
                    if(!pass.getText().toString().equals(cnfpass.getText().toString()) && cnfpass.isEnabled())
                    {
                        pass.setError("Password not Matched");
                        cnfpass.setError("Confirm Password not Matched");
                        userAdding=false;

                    }
                }
                if(username.getText().toString().isEmpty())
                {
                    username.setError("Enter Username");
                    userAdding=false;

                }
                else {
                    try {
                        User userObj=new User();
                        userObj.setFirstName(fname.getText().toString());
                        userObj.setLastName(lname.getText().toString());
                        userObj.setUserName(username.getText().toString());
                        userObj.setPassword(pass.getText().toString());
                        if(!email.getText().toString().isEmpty())
                            userObj.setEmailId(email.getText().toString());
                        if(!phone.getText().toString().isEmpty())
                            userObj.setPhoneNumber(phone.getText().toString());


                        if(maleRadioButton.isChecked())
                            userObj.setGender(maleRadioButton.getText().toString());
                        if (femaleRadioButton.isChecked())
                            userObj.setGender(femaleRadioButton.getText().toString());

                        Log.d("gen:",userObj.getGender());
                        if(!dob.getText().toString().isEmpty())
                            userObj.setDateOfBirth(dob.getText().toString());
                        if(userAdding)
                        {
                            userService.removeUserInList(UpdateProfileActivity.this,user);
                            if(userService.addUserInList(UpdateProfileActivity.this,userObj))
                            {
                                userService.signInUser(UpdateProfileActivity.this,userObj,itemId,null);
                                // do sign in
                                Intent intent=new Intent();
                                intent.putExtra(getString(R.string.userObject), userObj);
                                setResult(2,intent);
                                finish();//finishing activity
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        });

    }

    private void updateLabel() {

        dob.setText(sdf.format(myCalendar.getTime()));
    }
}
