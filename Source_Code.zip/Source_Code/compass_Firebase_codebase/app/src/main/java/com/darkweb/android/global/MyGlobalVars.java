package com.darkweb.android.global;

public class MyGlobalVars {
    private static MyGlobalVars mInstance = null;
    public UserStatus userStatus = new UserStatus();
    protected MyGlobalVars() {}
    public static synchronized MyGlobalVars getInstance() {
        if (null == mInstance) {
            mInstance = new MyGlobalVars();
        }
        return mInstance;
    }
}
