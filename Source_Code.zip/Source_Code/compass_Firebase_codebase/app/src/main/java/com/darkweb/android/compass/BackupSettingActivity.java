package com.darkweb.android.compass;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.darkweb.android.model.User;
import com.darkweb.android.service.BackupSettingService;
import com.darkweb.android.service.UserService;

import java.io.File;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;


//Back up activity in Settings

public class BackupSettingActivity extends AppCompatActivity {

    private TextView backupDate;
    private TextView backupSize;
    private ListView backupListView;
    private Button backupButton;
    private CheckBox volunteerServicesCheckBox;
    private CheckBox bookmarkCheckBox;
    private CheckBox servicesCheckBox;
    private CheckBox profileCheckBox;
    private String url;
    long BackupLongSize=0;
    private File userInfoFile;
    private File bookmarkOrganization;
    private File bookmarkCalenderEvents;
    private File servicesDetails;
    private File yourEventListFile;
    UserService userService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_backup_setting);
        userService=new UserService();
        BackupSettingService backupSettingServiceObject=new BackupSettingService();
        backupDate=(TextView) findViewById(R.id.backup_date);
        backupDate.setVisibility(View.GONE);
        findViewById(R.id.backup_date_textview).setVisibility(View.GONE);
        backupSize= ( TextView) findViewById(R.id.backup_size);
        backupButton=(Button)findViewById(R.id.backup_button);
        url = BackupSettingActivity.this.getFilesDir().toString();
        profileCheckBox=(CheckBox) findViewById(R.id.profile_backup_checkbox);
        servicesCheckBox=(CheckBox) findViewById(R.id.services_backup_checkbox);
        bookmarkCheckBox=(CheckBox) findViewById(R.id.bookmark_backup_checkbox);
        volunteerServicesCheckBox=(CheckBox) findViewById(R.id.volunteer_services_backup_checkbox);
        profileCheckBox.setChecked(true);
        servicesCheckBox.setChecked(true);
        bookmarkCheckBox.setChecked(true);
        volunteerServicesCheckBox.setChecked(true);
        userInfoFile = new File(url,getString(R.string.UserInfo));
        bookmarkOrganization = new File(url,getString(R.string.bookmarkFile));
        bookmarkCalenderEvents = new File(url,getString(R.string.bookmarkCalendarEvent));
        servicesDetails = new File(url,getString(R.string.serviceDetails));
        yourEventListFile = new File(url, getString(R.string.yourEventListFile));

        BackupLongSize=backupSettingServiceObject.addBackUpLength(userInfoFile,BackupLongSize,backupSize);
        BackupLongSize=backupSettingServiceObject.addBackUpLength(bookmarkOrganization,BackupLongSize,backupSize);
        BackupLongSize=backupSettingServiceObject.addBackUpLength(bookmarkCalenderEvents,BackupLongSize,backupSize);
        BackupLongSize=backupSettingServiceObject.addBackUpLength(servicesDetails,BackupLongSize,backupSize);
        BackupLongSize=backupSettingServiceObject.addBackUpLength(yourEventListFile,BackupLongSize,backupSize);



        profileCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(userInfoFile.exists())
                {
                    if(isChecked)
                    {
                        BackupLongSize=backupSettingServiceObject.addBackUpLength(userInfoFile,BackupLongSize,backupSize);
                    }
                    else {
                        BackupLongSize=backupSettingServiceObject.subtractBackUpLength(userInfoFile,BackupLongSize,backupSize);
                    }
                }

            }
        });

        bookmarkCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(bookmarkCalenderEvents.exists())
                {
                    if(isChecked)
                    {
                        BackupLongSize=backupSettingServiceObject.addBackUpLength(bookmarkCalenderEvents,BackupLongSize,backupSize);
                    }
                    else
                    {
                        BackupLongSize=backupSettingServiceObject.subtractBackUpLength(bookmarkCalenderEvents,BackupLongSize,backupSize);
                    }
                }
                if(bookmarkOrganization.exists())
                {
                    if(isChecked)
                    {
                        BackupLongSize=backupSettingServiceObject.addBackUpLength(bookmarkOrganization,BackupLongSize,backupSize);
                    }
                    else
                    {
                        BackupLongSize=backupSettingServiceObject.subtractBackUpLength(bookmarkOrganization,BackupLongSize,backupSize);
                    }
                }
            }
        });

        servicesCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d("serviceExist:",servicesDetails.exists()+""+" "+yourEventListFile.exists());
                if(servicesDetails.exists())
                {
                    if(isChecked)
                    {
                        BackupLongSize=backupSettingServiceObject.addBackUpLength(servicesDetails,BackupLongSize,backupSize);
                    }
                    else
                        BackupLongSize=backupSettingServiceObject.subtractBackUpLength(servicesDetails,BackupLongSize,backupSize);
                }
                if(yourEventListFile.exists())
                {
                    if(isChecked)
                        BackupLongSize= backupSettingServiceObject.addBackUpLength(yourEventListFile,BackupLongSize,backupSize);
                    else
                        BackupLongSize=backupSettingServiceObject.subtractBackUpLength(yourEventListFile,BackupLongSize,backupSize);
                }
            }
        });



        ArrayList<File> fileArrayList =new ArrayList<File>() ;
        backupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fileArrayList.clear();
                if(profileCheckBox.isChecked())
                {
                    fileArrayList.add(userInfoFile);
                }
                if(bookmarkCheckBox.isChecked())
                {
                    fileArrayList.add(bookmarkOrganization);
                    fileArrayList.add(bookmarkCalenderEvents);
                }
                if(servicesCheckBox.isChecked())
                {
                    fileArrayList.add(servicesDetails);
                    fileArrayList.add(yourEventListFile);
                }
                if(volunteerServicesCheckBox.isChecked())
                {
                //    File
                }
                if(fileArrayList.size()>0)
                {
                    User user=userService.getUserSignedIn(BackupSettingActivity.this);
                    if(user!=null)
                    {
                        backupSettingServiceObject.createBackup(BackupSettingActivity.this,user,fileArrayList);
                        Toast.makeText(BackupSettingActivity.this,"Backed up Successfully",Toast.LENGTH_LONG).show();
                    }

                }

            }
        });
    }

}
