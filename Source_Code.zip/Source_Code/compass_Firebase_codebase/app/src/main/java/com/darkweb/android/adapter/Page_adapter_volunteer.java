package com.darkweb.android.adapter;

/**
 * Created by kotak on 19/08/2018.
 */

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import android.os.Bundle;
import android.util.Log;

import com.darkweb.android.compass.FragmentCalendarView;

public class Page_adapter_volunteer extends FragmentStatePagerAdapter {
    int mNumOfTabs;
    FragmentCalendarView fragmentCalendarView;

    public Page_adapter_volunteer(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        Log.d("Tab position volunteer:",position+"");
        switch (position) {
            case 0:
                Bundle bundle = new Bundle();
                bundle.putString("fragment", "Volunteering Oppurtunities");
                fragmentCalendarView=new FragmentCalendarView();
                fragmentCalendarView.setArguments(bundle);
                return fragmentCalendarView;

            case 1:

                bundle = new Bundle();
                bundle.putString("fragment", "My Volunteering Services");
                fragmentCalendarView = new FragmentCalendarView();
                fragmentCalendarView.setArguments(bundle);
                return fragmentCalendarView;

            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}