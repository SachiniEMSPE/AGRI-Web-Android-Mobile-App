package com.darkweb.android.compass;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.parser.JsontoObject;
import com.darkweb.android.service.OrganizationService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class SearchActivity extends AppCompatActivity {

    ListView searchedListView;
    String SearchedWord;
    private ArrayAdapter<String> orgAdapter;
    ArrayList<String> combinedNameDescriptionArrayListSearch = new ArrayList<String>();
    ArrayList<String> combinedNameDescriptionArrayListTitles = new ArrayList<String>();
    private OrganizationService organizationService;
    ArrayList<OrganizationDescription> finalOrganizationDescriptionArrayList=new ArrayList<OrganizationDescription>();
    ArrayAdapter<String> arrayAdapter;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        searchedListView = (ListView) findViewById(R.id.searched_list_view);

        new GetCourseCategoriesMarkerColor().execute();

        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,combinedNameDescriptionArrayListTitles);
        searchedListView.setAdapter(arrayAdapter);

        searchedListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItemText = parent.getItemAtPosition(position).toString();
                Log.d("*sach item SELECTED ", selectedItemText);
                //Log.d("*sach item SIZE ", String.valueOf(finalOrganizationDescriptionArrayList.size()));
                OrganizationDescription orgDesObj =getLocationDescriptionObject(selectedItemText);
                if(orgDesObj!=null){
                    Intent intent = new Intent(SearchActivity.this,ViewServices.class);
                    intent.putExtra("serviceObject",orgDesObj);
                    startActivity(intent);
                }
            }
        });

    }

    //to update the whole big organizations array
    @SuppressLint("StaticFieldLeak")
    private class GetCourseCategoriesMarkerColor extends AsyncTask<Void, Void, Void> {

        ProgressDialog progressDialog;

        @Override
        //sach- Showing progress loading dialog
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress loading dialog
            progressDialog = new ProgressDialog(SearchActivity.this);
            progressDialog.setMessage("Fetching data...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @TargetApi(Build.VERSION_CODES.N)
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                finalOrganizationDescriptionArrayList = JsontoObject.jsonToObjectData(getResources().openRawResource(R.raw.newdbnewformattaxonomyupdated));//sachUpdated new DB instead of schenectadymap

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            titlefunc();
            arrayAdapter.notifyDataSetChanged();
            if (progressDialog.isShowing())
                progressDialog.dismiss();
        }

    }

    //sach_get object description as per the org name & description [searched list items]
    public OrganizationDescription getLocationDescriptionObject(String selectedItemText) {

        if (finalOrganizationDescriptionArrayList==null) {
            return null;
        }
        Log.d("sach_XXXYY", String.valueOf(finalOrganizationDescriptionArrayList.size()));
        Log.d("sach_XXXYY", String.valueOf(finalOrganizationDescriptionArrayList));

        for(OrganizationDescription locDescObj:finalOrganizationDescriptionArrayList)
        {   Log.d("sach_XXX",selectedItemText);
            Log.d("sach_XXX2",locDescObj.getOrganizationName());
            if (locDescObj.getOrganizationName().equals(selectedItemText) || locDescObj.getDescription().equals(selectedItemText))
            {
                return locDescObj;
            }
        }
        return null;
    }

    public void titlefunc(){
        combinedNameDescriptionArrayListSearch = getIntent().getStringArrayListExtra("searched");
        //sach_get object description as per the org name & description [searched list items] & update Title ONLY arraylist to show in search
        Log.d("sachEEE", String.valueOf(combinedNameDescriptionArrayListSearch));
        for(String searchNameDes:combinedNameDescriptionArrayListSearch)
        { Log.d("sachEEE_33", searchNameDes);

            OrganizationDescription orgDesObj2 =getLocationDescriptionObject(searchNameDes);
            Log.d("sachOB", String.valueOf(orgDesObj2));

            if(orgDesObj2!=null) {
                Log.d("sach","INSIDEEEE 2222222");
                combinedNameDescriptionArrayListTitles.add(orgDesObj2.getOrganizationName());
            }
        }

        // remove duplicates from titles
        Set<String > set = new HashSet<>(combinedNameDescriptionArrayListTitles);
        combinedNameDescriptionArrayListTitles.clear();
        combinedNameDescriptionArrayListTitles.addAll(set);
        Log.d("sach_TitleEE ", String.valueOf(combinedNameDescriptionArrayListTitles));
        Log.d("sach_SIZE2EE ", String.valueOf(combinedNameDescriptionArrayListTitles.size()));
    }

}
