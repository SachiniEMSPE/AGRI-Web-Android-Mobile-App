package com.darkweb.android.agri;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.darkweb.android.adapter.Page_adapter_services;
import com.darkweb.android.adapter.Page_adapter_services_up;
import com.darkweb.android.compass.R;
import com.google.android.material.tabs.TabLayout;

public class UploadAll_tab extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.ag_form_tab,container,false); //activity_service_tab
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TabLayout tabLayout = (TabLayout) view.findViewById(R.id.tabs_ser);
        tabLayout.addTab(tabLayout.newTab().setText("RECORDS"));
        tabLayout.addTab(tabLayout.newTab().setText("UPLOAD ALL"));


        viewPager = (ViewPager)view.findViewById(R.id.viewpager_ser);


        final Page_adapter_services_up adapter = new Page_adapter_services_up
                (getChildFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);


        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        viewPager.setCurrentItem(0);
        viewPager.setOffscreenPageLimit(3);

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {


                if (tab.getPosition() == 0) {
                    viewPager.setCurrentItem(0);

                } else {

                     //When pathways tab has been clicked
                    viewPager.setCurrentItem(2);

                }/*else if (tab.getPosition() == 1) {
                    *//**
                     * When bookmark tab has been clicked
                     *//*
                    viewPager.setCurrentItem(1);

                } else {
                    *//**
                     * When pathways tab has been clicked
                     *//*
                    viewPager.setCurrentItem(2);

                }*/

            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

        });



    }

}
