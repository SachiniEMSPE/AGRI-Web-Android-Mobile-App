package com.darkweb.android.adapter;

/**
 * Created by kotak on 19/08/2018.
 */

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import android.util.Log;
import com.darkweb.android.compass.Fragment1;
import com.darkweb.android.compass.FragmentNewsFeed;
import com.darkweb.android.compass.fragments.Fragment1New;

//sach-

public class PagerAdapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;

    public PagerAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }


    @Override
    public Fragment getItem(int position) {

        Log.d("sach_Tab position:",position+"");
        switch (position) {
            case 0:
                Fragment1 tab1 = new Fragment1();
                return tab1;
//                return new Fragment1New();

            case 1:
                return new FragmentNewsFeed();

            //case 2:
                //Fragment3 tab3 = new Fragment3(); //not yet
                //return tab3;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}