package com.darkweb.android.compass;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

import com.darkweb.android.adapter.PagerAdapter;
import com.darkweb.android.login.LoginActivity;
import com.darkweb.android.model.User;
import com.darkweb.android.service.UserService;
import com.google.android.material.tabs.TabLayout;

import static android.content.Context.INPUT_METHOD_SERVICE;

//TAblayout for homepage
@SuppressLint("ValidFragment")
public class FragmentHome extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private User user;
    private int tempFragmentPosition=0;
    private int previousFragmentPosition=0;
    UserService userService;
    Toolbar toolbar;



    @SuppressLint("ValidFragment")
    public FragmentHome()
    {

    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home,container,false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        userService = new UserService();
        user= userService.getUserSignedIn(getActivity());
        //sach-Home Tab declaration
        tabLayout = (TabLayout)view.findViewById(R.id.tabs);
        tabLayout.addTab(tabLayout.newTab().setText("Explore"));
        tabLayout.addTab(tabLayout.newTab().setText("NewsFeed"));
        Log.d("Sach_TabCreatedTabs","Yes");

        viewPager = (ViewPager)view.findViewById(R.id.viewpager);
        final PagerAdapter adapter = new PagerAdapter
                (getChildFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        viewPager.setCurrentItem(0);
        viewPager.setOffscreenPageLimit(2);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            //sach-Tab selected
            public void onTabSelected(TabLayout.Tab tab) {
                try {
                    InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
                } catch (Exception e) {
                }
                Log.d("Sach_TabSelected","Yes");

                switch (tab.getPosition()){
                    case 2:
                        user= userService.getUserSignedIn(getActivity());
                        Log.d("Sach_Tab","SelectedSignedIn : Yes"); //?
                        if(user==null)
                        {
                            Intent intent = new Intent(getActivity(), LoginActivity.class);
                            startActivityForResult(intent, 1);
                            previousFragmentPosition=tempFragmentPosition;
                            tempFragmentPosition=4;
                            Log.d("Sach_TabSelected","SignedIn:No,Request to sign in");//?
                        }
                        else
                        {
                            tempFragmentPosition=4;
                            viewPager.setCurrentItem(4);
                            Log.d("Sach_TabSelected","SignedIn: Yes,Request to sign in");//?
                        }
                        break;

                    default:
                        //sach-Show selected tab content
                        viewPager.setCurrentItem(tab.getPosition());
                        tempFragmentPosition=tab.getPosition();
                        Log.d("Sach_TabSelectedDefault","Yes");
                        break;
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }

    @Override
    //sach-onresume
    public void onResume() {
        super.onResume();
        if(tempFragmentPosition==4)
        {
            if(userService==null)
                userService=new UserService();
            user= userService.getUserSignedIn(getActivity());
            //sach-if no user and view pager blank direct to Home page "0" position
            if(user==null && viewPager!=null)
            {
                viewPager.setCurrentItem(0);
                Log.d("viewPager","0");
             //   toolbar.setTitle("Home");Shon
            }
            else {
                //toolbar.setTitle("Home");Shon

            }
        }
        Log.d("sach_onresume","yes");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {
        }
        if(tempFragmentPosition==4)
        {
            user=userService.getUserSignedIn(getActivity());
            if(user!=null)
            {
                tempFragmentPosition=4;
                viewPager.setCurrentItem(4);
//                toolbar.setTitle("Home");

            }
            else
            {
                int i;
                viewPager.setCurrentItem(previousFragmentPosition);

                tempFragmentPosition=previousFragmentPosition;
                if(tempFragmentPosition==0)
  //                  toolbar.setTitle("Home");
                if(tempFragmentPosition==2)
                i=0;
                    //                toolbar.setTitle("Home");

            }

        }
    }
}
