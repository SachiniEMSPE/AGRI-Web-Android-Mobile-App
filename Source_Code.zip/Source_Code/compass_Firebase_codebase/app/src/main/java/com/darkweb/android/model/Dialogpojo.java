package com.darkweb.android.model;

public class Dialogpojo {
    private String titles;
    private String subjects;
    private String types;
    private String duedates;
    private String descripts;
    private String attatchmentd;
    private String sections;
    private String classe;

    public void setTitles(String titles) {
        this.titles = titles;
    }

    public void setSubjects(String subjects) {
        this.subjects = subjects;
    }

    public void setTypes(String types) {
        this.types = types;
    }

    public void setDuedates(String duedates) {
        this.duedates = duedates;
    }

    public void setDescripts(String descripts) {
        this.descripts = descripts;
    }

    public void setAttatchmentd(String attatchmentd) {
        this.attatchmentd = attatchmentd;
    }

    public String getTitles() {
        return titles;
    }

    public String getSubjects() {
        return subjects;
    }

    public String getTypes() {
        return types;
    }

    public String getDuedates() {
        return duedates;
    }

    public String getDescripts() {
        return descripts;
    }

    public String getAttatchmentd() {
        return attatchmentd;
    }

    public void setSections(String sections) {
        this.sections = sections;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public String getClasse() {
        return classe;
    }

    public String getSections() {
        return sections;
    }
}