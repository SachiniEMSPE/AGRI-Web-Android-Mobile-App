package com.darkweb.android.model;

import java.util.ArrayList;

public class Folder {
	String name;
	ArrayList<OrganizationDescription> organizationDescriptionArray;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<OrganizationDescription> getOrganizationDescriptionArray() {
		return organizationDescriptionArray;
	}
	public void setOrganizationDescriptionArray(ArrayList<OrganizationDescription> organizationDescriptionArray) {
		this.organizationDescriptionArray = organizationDescriptionArray;
	}
	
}
