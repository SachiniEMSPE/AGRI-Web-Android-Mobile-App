package com.darkweb.android.global;

public class MyBackendLinks {
    private final String localServer = "http://10.0.2.2:8090";
    private final String UAServer = "https://compass-dev.arcc.albany.edu/compassapi";
    // swap local or server down below
    public final String adminEndPoint = UAServer + "/admin/api/";
    public final String mobileEndPoint = UAServer + "/api/mobile/";

}
