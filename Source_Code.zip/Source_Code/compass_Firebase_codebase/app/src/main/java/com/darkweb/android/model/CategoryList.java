package com.darkweb.android.model;

import java.util.ArrayList;

/**
 * Created by kotak on 06/06/2018.
 */

public class CategoryList {
    String categoryName;
    Boolean openNowSwitch = false;//sachadded
    ArrayList<String> options=new ArrayList<String>();
    ArrayList<Boolean> boxChecked=new ArrayList<Boolean>();
    ArrayList<String> openNowOptions= new ArrayList<String>();//sach added

    public ArrayList<Boolean> getBoxChecked() {
        return boxChecked;
    }

    public void setBoxChecked(ArrayList<Boolean> boxChecked) {
        this.boxChecked = boxChecked;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public ArrayList<String> getOptions() {
        return options;
    }

    public void setOptions(ArrayList<String> options) {

        this.options = options;
    }
    public ArrayList<String> getOpenNowOptions() {
        return openNowOptions;
    }

    public void setOpenNowOptions(ArrayList<String> openNowOptions) {

        this.openNowOptions = openNowOptions;
    }
    public Boolean getOpenNowSwitch() {
        return openNowSwitch;
    }

    public void setOpenNowSwitch(Boolean openNowSwitch) {
        this.openNowSwitch = openNowSwitch;
    }

}
