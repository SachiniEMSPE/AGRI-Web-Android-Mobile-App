package com.darkweb.android.compass.fragments;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.annotation.*;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;

import com.darkweb.android.compass.HomePage;
import com.darkweb.android.compass.R;
import com.darkweb.android.model.FeedBackDetails;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.service.LocationDescriptionServices;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.qap.ctimelineview.TimelineRow;
import org.qap.ctimelineview.TimelineViewAdapter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import at.blogc.android.views.ExpandableTextView;
import io.github.kobakei.materialfabspeeddial.FabSpeedDial;
import io.github.kobakei.materialfabspeeddial.FabSpeedDialMenu;

import static com.darkweb.android.compass.R.drawable.username;

public class ServiceRequested_old extends AppCompatActivity {

    String status = "Pending"; //sach added to store status variable ( pending / complete / cancel : since this is required for sorting , and 3 files

    //sach added(copied from LocationDescriptionService) this to make 'dateArray' an internal variable , usage is in oncreate()
    ArrayList<String> DateArrayList = new ArrayList<String>();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    String currentDateandTime = sdf.format(new Date());
    /////

    private ArrayList<TimelineRow> timelineRowsList = new ArrayList<>();
    ArrayAdapter<TimelineRow> myAdapter;
    ServiceDetails serviceDetails;
    ArrayList<ServiceDetails> sdList;
    ArrayList<FeedBackDetails> feedbackDetailsList;
    Spinner serviceDescriptionList,programDescriptionList;
    TextView serviceIdTextView,expectingDate, button_toggle2,expectingtime,serviceNameTextView; //sach Change : serviceName > serviceNameTextView , serviceId>serviceIdTextView
    ExpandableTextView serviceDescriptionTextview;

    Dialog pdialog;
    String url;
    static EditText  serviceDescription;
    static Button submit;
    FabSpeedDial fab;
    final Calendar myCalendar = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener updateServiceDateListener,notificationEventDateListener;
    FeedBackDetails feedBackDetails;
    private static Dialog dialog;
    private RatingBar ratingBar;
    int updateHours, updateMinutes;
    TextView svc_description;
    EditText comments,addServiceNameTextView;
    Button submitfeedback;
    private TableLayout tableLayout;
    private EditText updateServiceDateEditText,updateServiceTimeEditText;
    private TextView addReminderTextView;
    private Calendar myCalendar1;
    private TextView event_name_textview;
    private TextView event_description;
    private EditText eventDateEditText;
    private EditText eventTimeEditText;
    private TextView addnotificationdaysTextView,request_time,request_date,service_name,program_name;
    private View background_dimmer;
    private ImageView imageView;
    Toolbar toolbar;

    //@RequiresApi(api = Build.VERSION_CODES.N) //sach commented due to converting to previous version of service details object
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        //sach added(copied from LocationDescriptionService) this to make 'dateArray' an internal variable , definitions are above
        //DateArrayList.add(serviceDetails.getExpectingServiceDate()+"");//sach commented to make Pending time to currentdate time
        DateArrayList.add(currentDateandTime);
        for (int i = 0; i < 3; i++) { //sach may be this needs to be removed from here and paste near where the statusArray is updating. Also 3 should be changed to lwngth of the statusArray
            DateArrayList.add(currentDateandTime + "");
        }
        ///////

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_requested);

        toolbar= (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //Define Layout Elements
        serviceIdTextView=(TextView)findViewById(R.id.organization_name_textview);
        serviceNameTextView=(TextView)findViewById(R.id.descriptive_title_textView);
        serviceDescriptionTextview =findViewById(R.id.comment_textView);
        fab = (FabSpeedDial) findViewById(R.id.fab);
        background_dimmer=(View)findViewById(R.id.background_dimmer);
        imageView = findViewById(R.id.ImageView);
        request_time= findViewById(R.id.request_time);
        request_date= findViewById(R.id.request_date);
        service_name = findViewById(R.id.serviceNametextView);//sach added
        program_name = findViewById(R.id.programNametextView);//sach added

        url = ServiceRequested_old.this.getFilesDir().toString();
        serviceDetails=(ServiceDetails)getIntent().getSerializableExtra("serviceRequestObject");
        Log.d("sach_SR_url",url);
        Log.d("sach_SR_ServiceDetails", String.valueOf(serviceDetails));
        if (serviceDetails==null)
        {
            UUID uuid=(UUID) getIntent().getSerializableExtra("id");
            if(uuid!=null)
            {
                serviceDetails= ServiceDetails.getServiceDetailsObject(uuid,ServiceRequested_old.this);
                Log.d("serv:",(serviceDetails==null)+"");
            }
        }
        //sach request clicked description view is here - assign Descriptive title/ organization name/comments/ expecting time / expected date
        //serviceIdTextView.setText(serviceDetails.getServiceRequestName());
        serviceIdTextView.setText(
                serviceDetails.getOrganizationDescription().getOrganizationName()
        ); //sach program name - service title //sach added getApplicationContext() | context addition removed to convert back to previous version
        //serviceNameTextView.setText(serviceDetails.getServiceRequestName()); //sach changed
        serviceNameTextView.setText(serviceDetails.getTitle());
        //serviceDescriptionTextview.setText(serviceDetails.getServiceDescription()); //sach changed
        serviceDescriptionTextview.setText(serviceDetails.getComments());
        request_time.setText(serviceDetails.getExpectingtime());
        request_date.setText(serviceDetails.getExpectingServiceDate());
        service_name.setText(serviceDetails.getServiceName());//sach added getServiceProgram()> getServiceName
        //program_name.setText(serviceDetails.getServiceCategory(ServiceRequested.this));//sach added | sach updated with context | sach commented 2020-02-06 and added previous version as below
        program_name.setText(serviceDetails.getProgramName());//sach added again | serviceCategory > programName

        //Log.d("sach_SeviceRequested",serviceDetails.getServiceProgram());

        //String check=serviceDetails.getServiceDescription(); //sach changed
        String check=serviceDetails.getComments();

        //sach set comment elements in layout
        //Set Elements to Layout
        button_toggle2 = findViewById(R.id.button_toggle2);  //Button for read more attribute
        if(check== null || check==" " || check==""){
            button_toggle2.setText("");
        }else{
            imageView.setImageResource(username);
            if(check.length()<41){
                button_toggle2.setText("");
            }else{
                button_toggle2.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(final View v)
                    {
                        if (serviceDescriptionTextview.isExpanded())
                        {
                            serviceDescriptionTextview.collapse();
                            button_toggle2.setText("Read More..");
                        }
                        else
                        {
                            serviceDescriptionTextview.expand();
                            button_toggle2.setText("Read Less..");
                        }
                    }
                });
            }

        }


        //sach status flow is here
        //sach changed getStatus > getServiceArray(0)
        Log.d("srttt:",serviceDetails.getStatusArray().get(0)+" "+getString(R.string.pending_status_service_request)+ " "+serviceDetails.getStatusArray().get(0).equals(getString(R.string.pending_status_service_request)) );

        //if (serviceDetails.getStatus().equals(getString(R.string.pending_status_service_request)))//sach changed
        if (serviceDetails.getStatusArray().get(0).equals(getString(R.string.pending_status_service_request)))
        {
            // Create menu in code
            FabSpeedDialMenu menu = new FabSpeedDialMenu(this);
            menu.add("Edit request").setIcon(R.drawable.outline_create_white_18dp);
            menu.add("Recall service").setIcon(R.drawable.outline_clear_white_18dp);
            //menu.add("Complete service").setIcon(R.drawable.ic_done_black_24dp);
            fab.setMenu(menu);
            background_dimmer.setVisibility(View.GONE);
            fab.addOnMenuItemClickListener(new FabSpeedDial.OnMenuItemClickListener() {
                @Override
                public void onMenuItemClick(FloatingActionButton fab, TextView label, int itemId) {
                    if (itemId == 1) {
                        LocationDescriptionServices.addServiceDeatailsObj(ServiceRequested_old.this,serviceDetails.getOrganizationDescription(),serviceDetails,"Edit Request");//sach updated getOrgDes with ServiceRequested.this | getOrganizationDescription(ServiceRequested.this) romoved and updated as in previous version
                    }
                    if (itemId == 2) {
                        AlertDialog.Builder alertDialog=new AlertDialog.Builder(ServiceRequested_old.this);
                        alertDialog.setMessage("You are about to recall this request. Do you wish to proceed?");
                        alertDialog.setCancelable(true);
                        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                removeOrder(serviceDetails);
                                finish();
                                ServiceRequested_old.super.onBackPressed();
                            }
                        });
                        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Log.d("","");
                            }
                        });
                        alertDialog.show();
                    }
                    if (itemId == 3) {

                        AlertDialog.Builder alertDialog=new AlertDialog.Builder(ServiceRequested_old.this);
                        alertDialog.setTitle("Complete Service");
                        alertDialog.setMessage("Is the service completed ? ");
                        alertDialog.setCancelable(true);
                        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                CompleteOrder(serviceDetails);
                                finish();
                                ServiceRequested_old.super.onBackPressed();
                            }
                        });
                        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });

                        alertDialog.show();
                    }

                }
            });
        }
        //else if (serviceDetails.getStatus().equals(getString(R.string.completed_status_service_request)));//sach changed
        else if (status.equals(getString(R.string.completed_status_service_request)))
        {
            // Create menu in code
            FabSpeedDialMenu menu = new FabSpeedDialMenu(this);
            menu.add("Feedback").setIcon(R.drawable.outline_feedback_white_18dp);
            fab.setMenu(menu);

            fab.addOnMenuItemClickListener(new FabSpeedDial.OnMenuItemClickListener() {
                @SuppressLint("WrongConstant")
                @Override
                public void onMenuItemClick(FloatingActionButton fab, TextView label, int itemId) {
                    if (itemId == 1) {
                       feedBackDetails=getFeedbackDetailsfromFile(serviceDetails);

                        dialog = new Dialog(ServiceRequested_old.this);

                        dialog.setContentView(R.layout.feebackform);
                        dialog.setTitle("Feedback Form");

                        int width = (int)(getResources().getDisplayMetrics().widthPixels*0.90);
                        int height = (int)(getResources().getDisplayMetrics().heightPixels*0.90);

                        dialog.getWindow().setLayout(width, height);

                        ratingBar = dialog.findViewById(R.id.service_ratingBar);
                        comments = dialog.findViewById(R.id.add_service_comments);
                        svc_description = dialog.findViewById(R.id.add_service_description);
                        submitfeedback = dialog.findViewById(R.id.submitfeedback);
                        //svc_description.setText(serviceDetails.getServiceRequestName()); //sach changed
                        svc_description.setText(serviceDetails.getTitle());

                        if (feedBackDetails!=null)
                        {
                            comments.setText(feedBackDetails.getComments());
                            ratingBar.setRating(Float.parseFloat(feedBackDetails.getRatingValue()));
                        }
                        else
                        {
                            feedBackDetails=new FeedBackDetails();
                        }

                        FeedBackDetails finalFeedBackDetails = feedBackDetails;
                        submitfeedback.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                finalFeedBackDetails.setComments(comments.getText().toString());
                                finalFeedBackDetails.setRatingValue(String.valueOf(ratingBar.getRating()));
                                finalFeedBackDetails.setServiceDetails(serviceDetails);
                                addFeedBackToFile(finalFeedBackDetails);

                                dialog.dismiss();
                                }
                        });


                        dialog.show();

                    }
                }
            });

        }
        else
        {
            fab.hide();
        }

        if (serviceDetails.getStatusArray()!=null)
        {
            // sach Add Random Rows to the List timelinelist
            for (int i = 0; i < serviceDetails.getStatusArray().size(); i++) {
                //add the new row to the list // sach in future change .getDateArray.get(i) > date of receiving message to visualize
                //timelineRowsList.add(createRandomTimelineRow(serviceDetails.getStatusArray().get(i),serviceDetails.getDateArray().get(i),i)); // sach commented and replaced dateArray with internal DateArrayList
                timelineRowsList.add(createRandomTimelineRow(serviceDetails.getStatusArray().get(i),DateArrayList.get(i),i));

                Log.d("Status values",""+serviceDetails.getStatusArray().get(i));
            }

        }

        for (TimelineRow obj:timelineRowsList)
        {
            Log.v("rowlist:",obj.getId()+" title:"+obj.getTitle()+"time : ");

        }

        //sach Create the Timeline Adapter / remove 'pending' view from timeline row
        //sach commented
        /*
        Log.d("Check-1",serviceDetails.getStatusArray().get(0));
        if (serviceDetails.getStatusArray().get(0).equals("Pending")) {//sach changed to "P" capital
            //Log.d("Check",serviceDetails.getStatusArray().get(3)); //sach commented
            timelineRowsList.remove(0);
        }
         */

        myAdapter = new TimelineViewAdapter(this, 0, timelineRowsList,false);
        ListView myListView = (ListView) findViewById(R.id.timeline_listView);
        myListView.setAdapter(myAdapter);

        //sach if you wish to handle the clicks on the rows
        AdapterView.OnItemClickListener adapterListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TimelineRow row = timelineRowsList.get(position);
            }
        };
        myListView.setOnItemClickListener(adapterListener);


    }

    private FeedBackDetails getFeedbackDetailsfromFile(ServiceDetails serviceDetails) {
        final File file = new File(url, "feedbackDetails");
        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                feedbackDetailsList=(ArrayList<FeedBackDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (feedbackDetailsList!=null)
                {
                    int i=-1;
                    for (i=0;i<feedbackDetailsList.size();i++)
                    {
                        if (serviceDetails.getRequestUID().equals(feedbackDetailsList.get(i).getServiceDetails().getRequestUID()))//sach changed getServiceID>getRequestUID
                        {
                            Log.d("feedback:",feedbackDetailsList.get(i).getComments()+"");
                            return feedbackDetailsList.get(i);
                        }
                    }
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    private void addFeedBackToFile(FeedBackDetails feedBackDetails) {
        final File file = new File(url, "feedbackDetails");
        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                feedbackDetailsList=(ArrayList<FeedBackDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (feedbackDetailsList!=null)
                {
                    int i=-1;
                    int flag=0;
                    for (i=0;i<feedbackDetailsList.size();i++)
                    {
                        Log.d("compare:",feedBackDetails.getServiceDetails().getRequestUID()+"  h:"+feedbackDetailsList.get(i).getServiceDetails().getRequestUID());//sach changed getServiceID>getRequestUID
                        if (feedBackDetails.getServiceDetails().getRequestUID().equals(feedbackDetailsList.get(i).getServiceDetails().getRequestUID()))//sach changed getServiceID>getRequestUID
                        {
                            Log.d("break i:",i+" size:"+feedbackDetailsList.size());
                            flag=1;
                            break;
                        }
                    }
                    if (i>=0 && flag==1)
                    {
                        Log.d("break i:",i+" size:"+feedbackDetailsList.size());
                        feedbackDetailsList.remove(i);
                    }
                    feedbackDetailsList.add(0,feedBackDetails);
                }
                else
                {
                    feedbackDetailsList=new ArrayList<FeedBackDetails>();
                    feedbackDetailsList.add(0,feedBackDetails);
                }
            }
            else
            {
                feedbackDetailsList=new ArrayList<FeedBackDetails>();
                feedbackDetailsList.add(0,feedBackDetails);
            }
            FileOutputStream fileOutputStream;
            ObjectOutputStream objectOutputStream;
            fileOutputStream = ServiceRequested_old.this.getBaseContext().openFileOutput(file.getName(), Context.MODE_PRIVATE);
            Log.d("filename:",file.getName());
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(feedbackDetailsList);
            objectOutputStream.close();

            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void CompleteOrder(ServiceDetails serviceDetails) {
        final File file = new File(url, getString(R.string.serviceDetails));
        File completeFile=new File(url,getString(R.string.completedServices));
        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                sdList=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (sdList!=null)
                {
                    int i=-1;
                    for (i=0;i<sdList.size();i++)
                    {
                        if (serviceDetails.getRequestUID().equals(sdList.get(i).getRequestUID()))//sach changed getServiceID>getRequestUID
                        {
                            break;
                        }
                    }
                    if (i>=0)
                    {
                        sdList.remove(i);
                    }
                }
            }

            FileOutputStream fileOutputStream;
            ObjectOutputStream objectOutputStream;
            fileOutputStream = ServiceRequested_old.this.getBaseContext().openFileOutput(file.getName(), Context.MODE_PRIVATE);
            Log.d("filename:",file.getName());
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(sdList);
            objectOutputStream.close();

            fileOutputStream.flush();
            fileOutputStream.close();
            //serviceDetails.setStatus(getString(R.string.completed_status_service_request)); //sach changed > updated internal 'status' variable
            status = getString(R.string.completed_status_service_request);
            int i=-1;
            if (serviceDetails.getStatusArray()!=null)
            {
                if(serviceDetails.getStatusArray().contains(getString(R.string.pending_status_service_request)))
                {
                    i=serviceDetails.getStatusArray().indexOf(getString(R.string.pending_status_service_request));
                    //if(i>=0 && i<serviceDetails.getDateArray().size()) //sach commented and updated as below
                    if(i>=0 && i<DateArrayList.size())
                    {
                        //serviceDetails.getDateArray().remove(i); //sach commented and updated as below
                        DateArrayList.remove(i);
                    }
                    serviceDetails.getStatusArray().remove(getString(R.string.pending_status_service_request));
                }
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                String currentDateandTime = sdf.format(new Date());
                //serviceDetails.getDateArray().add(0,currentDateandTime);//sach commented and updated as below
                DateArrayList.add(0,currentDateandTime);

                serviceDetails.getStatusArray().add(0,getString(R.string.completed_status_service_request));
            }

            //adding to cancelService File
            if (completeFile.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(completeFile);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                sdList=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (sdList!=null)
                {
                    sdList.add(0,serviceDetails);
                    //Log.d("adding",serviceDetails.getServiceRequestName());//sach changed
                    Log.d("adding",serviceDetails.getTitle());
                }
                else
                {
                    sdList=new ArrayList<ServiceDetails>();
                    sdList.add(0,serviceDetails);
                    //Log.d("else1adding",serviceDetails.getServiceRequestName()); //sach changed
                    Log.d("else1adding",serviceDetails.getTitle());
                }
            }
            else {
                sdList=new ArrayList<ServiceDetails>();
                sdList.add(0,serviceDetails);
                //Log.d("els2adding",serviceDetails.getServiceRequestName());//sach changed
                Log.d("els2adding",serviceDetails.getTitle());
            }
            Log.d("addingsize",sdList.size()+"");
            fileOutputStream = ServiceRequested_old.this.getBaseContext().openFileOutput(completeFile.getName(), Context.MODE_PRIVATE);
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(sdList);
            objectOutputStream.close();

            fileOutputStream.flush();
            fileOutputStream.close();


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void removeOrder(ServiceDetails serviceDetails) {
        final File file = new File(url, "serviceDetails");
        File cancelFile=new File(url,"CancelledServices");
        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                sdList=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (sdList!=null)
                {
                    int i=-1;
                    for (i=0;i<sdList.size();i++)
                    {
                        if (serviceDetails.getRequestUID().equals(sdList.get(i).getRequestUID()))//sach changed getServiceID>getRequestUID
                        {
                            break;
                        }
                    }
                    if (i>=0)
                    {
                        sdList.remove(i);
                    }
                }
            }


            FileOutputStream fileOutputStream;
            ObjectOutputStream objectOutputStream;
            fileOutputStream = ServiceRequested_old.this.getBaseContext().openFileOutput(file.getName(), Context.MODE_PRIVATE);
            Log.d("filename:",file.getName());
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(sdList);
            objectOutputStream.close();

            fileOutputStream.flush();
            fileOutputStream.close();
            //serviceDetails.setStatus(getString(R.string.cancelled_status_service_request));//sach changed as below > internal variable used 'status'
            status =(getString(R.string.cancelled_status_service_request));
            int i=-1;
            if (serviceDetails.getStatusArray()!=null)
            {
                if(serviceDetails.getStatusArray().contains(getString(R.string.pending_status_service_request)))
                {
                    i=serviceDetails.getStatusArray().indexOf(getString(R.string.pending_status_service_request));
                    //if(i>=0 && i<serviceDetails.getDateArray().size()) //sach commented and updated as below
                    if(i>=0 && i<DateArrayList.size())
                    {
                        //serviceDetails.getDateArray().remove(i); //sach commented and updated as below
                        DateArrayList.remove(i);
                    }
                    serviceDetails.getStatusArray().remove(getString(R.string.pending_status_service_request));
                }
                serviceDetails.getStatusArray().add(0,getString(R.string.cancelled_status_service_request));
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                String currentDateandTime = sdf.format(new Date());
                //serviceDetails.getDateArray().add(0,currentDateandTime); //sach commented and updated as below
                DateArrayList.add(0,currentDateandTime);
            }

            //adding to cancelService File
            if (cancelFile.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(cancelFile);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                sdList=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (sdList!=null)
                {
                    sdList.add(0,serviceDetails);
                }
                else
                {
                    sdList=new ArrayList<ServiceDetails>();
                    sdList.add(0,serviceDetails);
                }
            }
            else {
                sdList=new ArrayList<ServiceDetails>();
                sdList.add(0,serviceDetails);
            }
            fileOutputStream = ServiceRequested_old.this.getBaseContext().openFileOutput(cancelFile.getName(), Context.MODE_PRIVATE);


            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(sdList);
            objectOutputStream.close();

            fileOutputStream.flush();
            fileOutputStream.close();


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void addServciceToFile(ServiceDetails serviceDetails) {

        final File file = new File(url, "serviceDetails");
        try {
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                sdList=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (sdList!=null)
                {
                    int i=-1;
                    for (i=0;i<sdList.size();i++)
                    {
                        if (serviceDetails.getRequestUID().equals(sdList.get(i).getRequestUID()))//sach changed getServiceID>getRequestUID
                        {
                            break;
                        }
                    }
                    if (i>=0)
                    {
                        sdList.remove(i);
                    }
                    sdList.add(0,serviceDetails);
                }
                else
                {
                    sdList=new ArrayList<ServiceDetails>();
                    sdList.add(0,serviceDetails);
                }
            }
            else
            {
                sdList=new ArrayList<ServiceDetails>();
                sdList.add(0,serviceDetails);
            }
            FileOutputStream fileOutputStream;
            ObjectOutputStream objectOutputStream;
            fileOutputStream = ServiceRequested_old.this.getBaseContext().openFileOutput(file.getName(), Context.MODE_PRIVATE);
            Log.d("filename:",file.getName());
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(sdList);
            objectOutputStream.close();

            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    //sach this is where the timelinerow item format.
    @SuppressLint("NewApi")
    private TimelineRow createRandomTimelineRow(String status, String date, int i){

        // Create new timeline row (pass your Id)
        TimelineRow myRow = new TimelineRow(i);

        //to set the row Date (optional)
        String pattern = "EEEE MM/dd/yyyy hh:mm a";
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);

        String status_text;
        switch (status)
        {
            case "Order Placed":{
                //status_text="Request submitted"; //sach changed
                status_text="Order Placed";
                break;
            }
            case "Order Confirmed":{
                //status_text="Request acknowledged"; //sach changed
                status_text="Order Confirmed";
                break;
            }
            case "In progress":{
                //status_text="Request resolution in progress"; //sach changed
                status_text="In progress";
                break;
            }
            case "Pending":{//sach changed to p > P
                //status_text="Request pending"; //sach changed
                status_text="Pending";
                break;
            }case "Completed":{ //sach changed c > C
            //status_text="Service request resolved";//sach changed
            status_text="Completed";
                break;
            }default:{ //sach this executes when "C" is pressed
                status_text="Request recalled";
                break;
            }



        }
        myRow.setTitle(status_text);
        //to set the row Description (optional)
        String date_string=sdf.format(new Date(date));
        Log.d("Status Text",status_text);
        String [] x=date_string.split(" ");
        myRow.setDescription(x[0]+", "+x[1]+", "+x[2]+" "+x[3]);
        myRow.setImage(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_background +3 ));
        myRow.setBellowLineColor(getColor(R.color.timeLine_line));
        myRow.setBellowLineSize(6);

        myRow.setImageSize(30);

        switch (status)
        {
            case "Order Placed":{
                myRow.setBackgroundColor(0xFFA4422D);break;
            }
            case "Order Confirmed":{
                myRow.setBackgroundColor(0xFFA4422D);break;
            }
            case "In progress":{
                myRow.setBackgroundColor(0xFFA4422D);break;
            }
            case "Pending":{ //sach changed p>P
                myRow.setBackgroundColor(0xFFA4422D);    break;
            }case "Completed":{//sach changed c>C
            myRow.setBackgroundColor(0xFFA4422D);break;

        }default:{
            myRow.setBackgroundColor(0xFFA4422D);
            break;
        }

        }
        myRow.setBackgroundSize(30);//sach changed 30 > 10
        //myRow.setImageSize(50); //sach added > not working properly
        //myRow.setBellowLineSize(30);//sach added > verticle line size change
        myRow.setDateColor(getColor(R.color.cfdialog_button_black_text_color));

        myRow.setTitleColor(getColor(R.color.cfdialog_button_black_text_color));

        myRow.setDescriptionColor(getColor(R.color.cfdialog_button_black_text_color));

        return myRow;
    }


    public Date getRandomDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Date startDate = null;
        Date endDate = new Date();
        try {
            startDate = sdf.parse("10/07/2018 00:00");
//                long random = ThreadLocalRandom.current().nextLong(startDate.getTime(), endDate.getTime());
            endDate = sdf.parse("12/07/2018 00:00");
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return endDate;
    }
    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        updateServiceDateEditText.setText(sdf.format(myCalendar.getTime()));
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();


        ActivityManager mngr = (ActivityManager) getSystemService( ACTIVITY_SERVICE );

        List<ActivityManager.RunningTaskInfo> taskList = mngr.getRunningTasks(10);

        if(taskList.get(0).numActivities == 1 &&
                taskList.get(0).topActivity.getClassName().equals(this.getClass().getName())) {
            Intent intent=new Intent(ServiceRequested_old.this, HomePage.class);
            startActivity(intent);

        }
        else
        {
            super.onBackPressed();
        }

    }


}

