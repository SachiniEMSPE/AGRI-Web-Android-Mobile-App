package com.darkweb.android.login;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.annotation.*;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.darkweb.android.model.User;
import com.darkweb.android.compass.R;
import com.darkweb.android.service.UserService;

import java.text.SimpleDateFormat;
import java.util.Locale;


public class ProfilePageFragment extends Fragment {

    TextView fname , lname , uname,email,mobile,pass,dob,gender;
    Button edit_button;
    private User user;
    String myFormat = "MM/dd/yy"; //In which you need put here
    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
    private View view;
    UserService userService;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.out.println("");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_profile,container,false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        this.view=view;
        userService=new UserService();
        fname = view.findViewById(R.id.fname);
        lname = view.findViewById(R.id.lname);
        uname = view.findViewById(R.id.uname);
        email = view.findViewById(R.id.useremail);
        mobile =view.findViewById(R.id.usermobile);
        gender=view.findViewById(R.id.gender);
       /* pass = view.findViewById(R.id.pass);
       */ dob = view.findViewById(R.id.dob);


    }

    @Override
    public void onResume() {
        super.onResume();
        user= userService.getUserSignedIn(getActivity());

        if(user!=null) {
            edit_button = view.findViewById(R.id.editprofile);
            fname.setText(user.getFirstName());
            lname.setText(user.getLastName());
            uname.setText(user.getUserName());
            email.setText(user.getEmailId());
            mobile.setText(user.getPhoneNumber());
            gender.setText(user.getGender());
            if (user.getDateOfBirth() != null)
                dob.setText(sdf.format(user.getDateOfBirth()));
            else
                dob.setText("");
            edit_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(getActivity(), UpdateProfileActivity.class);
                    i.putExtra(getString(R.string.itemId),6);
                    startActivityForResult(i, 2);// Activity is started with requestCode 2

                }
            });
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2)
        {

            //User user = (User) data.getSerializableExtra(getString(R.string.userObject));
            this.user=userService.getUserSignedIn(getActivity());
            if (user!=null) {
                fname.setText(user.getFirstName());
                lname.setText(user.getLastName());
                uname.setText(user.getUserName());
                email.setText(user.getEmailId());
                mobile.setText(user.getPhoneNumber());
                gender.setText(user.getGender());
                if (user.getDateOfBirth() != null)
                    dob.setText(sdf.format(user.getDateOfBirth()));
                else
                    dob.setText("");
            }
        }
        else
        {

        }
    }


}
