package com.darkweb.android.activities;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.darkweb.android.compass.R;
import com.darkweb.android.model.ObjectsForMapper.Program;
import com.darkweb.android.model.ObjectsForMapper.Request;
import com.darkweb.android.model.ObjectsForMapper.Service;
import com.darkweb.android.service.HttpHandlers.RequestedServicesHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.concurrent.ExecutionException;

public class RequestedServiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        // Tell our android, please use the old template
        setContentView(R.layout.activity_service_requested);

        String requestedId = getIntent().getSerializableExtra("requested_id").toString();
        String serverRes = "";
        try {
            serverRes = new RequestedServicesHandler().execute(requestedId, "request").get();

            // Map JSON to object
            ObjectMapper mapper = new ObjectMapper();
            Request requestedService = mapper.readValue(serverRes, Request.class);

            // Set view object one by one
            TextView organizationNameView = findViewById(R.id.organization_name_textview);
            TextView requestDescView = findViewById(R.id.descriptive_title_textView);
            TextView serviceDescriptionView = findViewById(R.id.comment_textView);
            TextView programNameView = findViewById(R.id.programNametextView);
            TextView serviceNameView = findViewById(R.id.serviceNametextView);

            // Now map the object to view page
            organizationNameView.setText(requestedService.getOrganization().getName());
            requestDescView.setText("Not set up in backend yet");
            // In order to get the service description, we need to dig into the organization object
            String serviceDesFromObj = "N/A";
            // Same for the program name, service name
            String programNameFromObj = "N/A";
            String serviceNameFromObj = "N/A";
            for (Program p : requestedService.getOrganization().getPrograms()) {
                for (Service s : p.getServices()) {
                    if (s.getId() == requestedService.getService()) {
                        serviceDesFromObj = s.getDescription();
                        programNameFromObj = p.getName();
                        serviceNameFromObj = s.getName();
                    }
                }
            }
            serviceDescriptionView.setText(serviceDesFromObj);
            programNameView.setText(programNameFromObj);
            serviceNameView.setText(serviceNameFromObj);

        } catch (ExecutionException | InterruptedException | JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
