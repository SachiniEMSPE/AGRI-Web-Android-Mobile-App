package com.darkweb.android.service;

import android.content.Context;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.darkweb.android.dao.BackupSettingDao;
import com.darkweb.android.model.User;

import java.io.File;
import java.util.ArrayList;

public class BackupSettingService {

    public void createBackup(Context context, User user, ArrayList<File> fileArrayList)
    {
        Log.d("creating backup :",""+user.getUserName()+"  "+(user.getUserUID()==null));
        UserService userService = new UserService();

        if(user!=null && user.getUserUID()!=null)
        {
            if(fileArrayList!=null)
            {
                BackupSettingDao backupSettingDaoObject=new BackupSettingDao();
                backupSettingDaoObject.writeFilesToFirebase(context,user,fileArrayList);
                Toast.makeText(context,"Backup successfully",Toast.LENGTH_LONG);
            }
        }
    }

    public long addBackUpLength(File userInfoFile ,long BackupLongSize,TextView backupSize) {
        BackupLongSize+=userInfoFile.length();
        Log.d("add:",BackupLongSize+"");

        updateBackupSize(BackupLongSize,backupSize);
        return BackupLongSize;
    }

    private void updateBackupSize(long BackupLongSize,TextView backupSize)
    {

        if(BackupLongSize>= (1024*1024))
        {
            double size=(double) BackupLongSize/ (1024.0*1024.0);
            backupSize.setText(String.format("%.2f", size)+" MB");
        }
        else if(BackupLongSize>=1024)
        {
            double size=(double) BackupLongSize/ (1024.0);
            backupSize.setText(String.format("%.2f", size)+" KB");
        }
        else if( BackupLongSize<1024)
        {
            double size=(double) BackupLongSize;
            backupSize.setText(String.format("%.2f", size)+" Bytes");
        }
    }
    public long subtractBackUpLength(File userInfoFile,long BackupLongSize,TextView backupSize) {

        BackupLongSize-=userInfoFile.length();
        Log.d("subtra:",BackupLongSize+"");
        updateBackupSize(BackupLongSize,backupSize);
        return  BackupLongSize;
    }


}
