package com.darkweb.android.model;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

/**
 * Created by kotak on 04/09/2018.
 */

public class Message implements Serializable {
    UUID messageId;
    String messageAuthor;
    String messageText;
    String userName;
    String OrganisationName;
    String OrganisationCategory;
    UUID serviceId;
    Date createdDate;
    //delivered_date
    Date updatedDate;
    boolean messageStatus;

    @Override
    public String toString() {
        return "Message{" +
                "messageId=" + messageId +
                ", messageAuthor='" + messageAuthor + '\'' +
                ", messageText='" + messageText + '\'' +
                ", userName='" + userName + '\'' +
                ", OrganisationName='" + OrganisationName + '\'' +
                ", OrganisationCategory='" + OrganisationCategory + '\'' +
                ", serviceId=" + serviceId +
                ", createdDate=" + createdDate +
                ", updatedDate=" + updatedDate +
                ", messageStatus=" + messageStatus +
                '}';
    }

    public String getMessageAuthor() {
        return messageAuthor;
    }

    public void setMessageAuthor(String messageAuthor) {
        this.messageAuthor = messageAuthor;
    }

    public UUID getMessageId() {
        return messageId;
    }

    public void setMessageId(UUID messageId) {
        this.messageId = messageId;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getOrganisationName() {
        return OrganisationName;
    }

    public void setOrganisationName(String organisationName) {
        OrganisationName = organisationName;
    }

    public String getOrganisationCategory() {
        return OrganisationCategory;
    }

    public void setOrganisationCategory(String organisationCategory) {
        OrganisationCategory = organisationCategory;
    }

    public UUID getServiceId() {
        return serviceId;
    }

    public void setServiceId(UUID serviceId) {
        this.serviceId = serviceId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public boolean getMessageStatus() {
        return messageStatus;
    }

    public void setMessageStatus(boolean messageStatus) {
        this.messageStatus = messageStatus;
    }
}
