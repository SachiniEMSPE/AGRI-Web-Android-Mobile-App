package com.darkweb.android.service;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.darkweb.android.adapter.CustomDateTimePicker;
import com.darkweb.android.adapter.NotificationAlarmManager;
import com.darkweb.android.model.OrganizationDescription;
import com.darkweb.android.model.ServiceDetails;
import com.darkweb.android.compass.R;
import com.darkweb.android.model.ServiceRequest;
import com.darkweb.android.model.User;
import com.darkweb.android.service.HttpHandlers.HttpServiceRequestHandler;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/**
 * Created by kotak on 05/09/2018.
 */

public class LocationDescriptionServices {

    private static ServiceDetails serviceDetails;
    private static User user;
    private static ArrayList<ArrayList<String>> additionalReqList;
    private static int program_list_index;
    //@RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("LongLogTag")
    public static void addServiceDeatailsObj(Context context, OrganizationDescription organizationDescriptionObj, ServiceDetails myServiceDetailsObj,String title)
    {

        final Calendar myCalendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd  HH:mm:ss");
        String currentDateandTime = sdf.format(new Date());
        Dialog dialog = new Dialog(context);

        dialog.setContentView(R.layout.add_service_dialog);
        dialog.setTitle("Add New Service");

        int width = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.90);

        dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        TextView dialogue_title= dialog.findViewById(R.id.dialogue_title);
        TextView addServiceNameTextView = (TextView) dialog.findViewById(R.id.add_servicename_textview);
        TextView serviceDescription = (TextView) dialog.findViewById(R.id.dialog_service);
        EditText addServiceDateEditText = (EditText) dialog.findViewById(R.id.input_date);
        EditText addServiceTimeEditText = (EditText) dialog.findViewById(R.id.input_time);
        Spinner programDescriptionList = (Spinner) dialog.findViewById(R.id.program_description_spinnerview);
        Spinner serviceDescriptionList = (Spinner) dialog.findViewById(R.id.service_description_spinnerview);
        TextView addReminderTextView = (TextView) dialog.findViewById(R.id.add_reminder_calendar_text_view);
        CheckBox additionalRequirementCB = dialog.findViewById(R.id.additional_requirement_cb);
        TextView additionalRequirementText = dialog.findViewById(R.id.additional_requirement_text);
        EditText addNotificationDays = (EditText) dialog.findViewById(R.id.add_notification_days);

        additionalReqList = organizationDescriptionObj.getServiceArrayAdditionalReq();
        String additionalRequirementFromObj = "";
        final int[] req_position = {0};

        dialogue_title.setText(title);
        Date date1;

        //sach - copied here
        UserService userService = new UserService();
        user = userService.getUserSignedIn(context);
        Log.d("sach_userUID", String.valueOf(user));//null at the moment

        //sach if serviceDetails object is null -  like initial new request

        if(myServiceDetailsObj==null)
        {
            addNotificationDays.setVisibility(View.GONE);
            addReminderTextView.setVisibility(View.VISIBLE);

            serviceDetails = new ServiceDetails();
            serviceDetails.setRequestUID(UUID.randomUUID());//sach changed setServiceID> setRequestUID

            Log.d("sach_LDS_SeviceID_UUID", String.valueOf(serviceDetails.getRequestUID()));//sach changed getServiceID>getRequestUID

            serviceDetails.setOrganizationDescription(organizationDescriptionObj);
            date1=new Date();
            date1.setHours(date1.getHours()+1);

            if(date1.getMinutes()<10){
                addServiceTimeEditText.setText(date1.getHours()+" : 0"+date1.getMinutes());
            }else {
                addServiceTimeEditText.setText(date1.getHours()+" : "+date1.getMinutes());
            }


            serviceDetails.setExpectingtime(addServiceTimeEditText.getText().toString());

            if (organizationDescriptionObj != null && organizationDescriptionObj.getServiceList() != null && organizationDescriptionObj.getServiceList().size() > 0) {
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
                        android.R.layout.simple_spinner_item, organizationDescriptionObj.getProgramList());
                programDescriptionList.setAdapter(arrayAdapter);
            }

            OrganizationDescription finalOrganizationDescriptionObj = organizationDescriptionObj;

            additionalRequirementCB.setVisibility(View.GONE);
            additionalRequirementText.setVisibility(View.GONE);

            programDescriptionList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    program_list_index = position;
                    if (!additionalReqList.get(position).get(0).equalsIgnoreCase("N/A")) {
                        additionalRequirementCB.setVisibility(View.VISIBLE);
                        additionalRequirementText.setVisibility(View.VISIBLE);
                        additionalRequirementText.setText(additionalReqList.get(position).get(0));
                    } else {
                        additionalRequirementCB.setVisibility(View.GONE);
                        additionalRequirementText.setVisibility(View.GONE);
                    }

                    if (finalOrganizationDescriptionObj != null && finalOrganizationDescriptionObj.getServiceList().get(position) != null && finalOrganizationDescriptionObj.getServiceList().get(position).size() > 0) {
                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
                                android.R.layout.simple_spinner_item, finalOrganizationDescriptionObj.getServiceList().get(position));
                        serviceDescriptionList.setAdapter(arrayAdapter);
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
            serviceDescriptionList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (!additionalReqList.get(program_list_index).get(i).equalsIgnoreCase("N/A")) {
                        additionalRequirementCB.setVisibility(View.VISIBLE);
                        additionalRequirementText.setVisibility(View.VISIBLE);
                        additionalRequirementText.setText(additionalReqList.get(program_list_index).get(i));
                    } else {
                        additionalRequirementCB.setVisibility(View.GONE);
                        additionalRequirementText.setVisibility(View.GONE);
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });


            if (!additionalReqList.get(0).get(0).equalsIgnoreCase("N/A")) {
                additionalRequirementCB.setVisibility(View.VISIBLE);
                additionalRequirementText.setVisibility(View.VISIBLE);
                additionalRequirementFromObj = additionalReqList.get(0).get(0);
                additionalRequirementText.setText(additionalRequirementFromObj);
            } else {
                additionalRequirementCB.setVisibility(View.GONE);
                additionalRequirementText.setVisibility(View.GONE);
            }
        }
        //sach - if serviceDetails object not null
        else
        {
            System.out.println("Should something run in here??");
            addReminderTextView.setVisibility(View.GONE);
            addNotificationDays.setVisibility(View.VISIBLE);


            serviceDetails=myServiceDetailsObj;
            addServiceDateEditText.setText(serviceDetails.getExpectingServiceDate());
            addServiceTimeEditText.setText(serviceDetails.getExpectingtime());
            //addServiceNameTextView.setText(serviceDetails.getServiceRequestName()); //sach changed
            addServiceNameTextView.setText(serviceDetails.getTitle());
            myCalendar.setTime( new Date(serviceDetails.getExpectingServiceDate() + " " + serviceDetails.getExpectingtime().replaceAll("\\s+", "")));

            //serviceDescription.setText(serviceDetails.getServiceDescription()); //sach changed
            serviceDescription.setText(serviceDetails.getComments());

            Log.d("sach_LDS_illegal",""+serviceDetails.getExpectingServiceDate()+" "+serviceDetails.getExpectingtime().replaceAll("\\s+",""));
            date1=new Date(serviceDetails.getExpectingServiceDate()+" "+serviceDetails.getExpectingtime().replaceAll("\\s+","")) ;
         //out if here

            if(date1.getMinutes()<10){
                addServiceTimeEditText.setText(date1.getHours()+" : 0"+date1.getMinutes());
            }else {
                addServiceTimeEditText.setText(date1.getHours()+" : "+date1.getMinutes());
            }



            addNotificationDays.setText(serviceDetails.getRemindarDate()+" "+serviceDetails.getRemindarTime().replaceAll("\\s+",""));
            organizationDescriptionObj =serviceDetails.getOrganizationDescription();//sach added context | context removed to match the preious version



            int programIndex= organizationDescriptionObj.getProgramList().indexOf(serviceDetails.getServiceName()); //sach changed getServiceProgram > getservicename
            if (organizationDescriptionObj !=null && organizationDescriptionObj.getServiceList()!=null && organizationDescriptionObj.getServiceList().size()>0) {
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
                        android.R.layout.simple_spinner_item, organizationDescriptionObj.getProgramList());
                programDescriptionList.setAdapter(arrayAdapter);
                programDescriptionList.setSelection(programIndex);

            }
            OrganizationDescription finalOrganizationDescriptionObj1 = organizationDescriptionObj;
            programDescriptionList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (finalOrganizationDescriptionObj1 !=null && finalOrganizationDescriptionObj1.getServiceList().get(position)!=null && finalOrganizationDescriptionObj1.getServiceList().get(position).size()>0) {
                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,
                                android.R.layout.simple_spinner_item, finalOrganizationDescriptionObj1.getServiceList().get(position));
                        serviceDescriptionList.setAdapter(arrayAdapter);
                        serviceDescriptionList.setSelection(finalOrganizationDescriptionObj1.getServiceList().get(position).indexOf(serviceDetails.getProgramName())); //sach upcated - getServiceCategory(context) | updated back to previous version | serviceCategory>programName
                        //serviceDetails.setServiceID(String.valueOf(finalOrganizationDescriptionObj1.getServiceUIDList().get(position).indexOf(serviceDetails.getServiceName())));//sach added // not working
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

        }

        //sach - add time edit text clicked
        addServiceTimeEditText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                final Calendar c = Calendar.getInstance();
              int  mHour = c.get(Calendar.HOUR_OF_DAY);
               int mMinute = c.get(Calendar.MINUTE);
               SimpleDateFormat simpleDateFormat=new SimpleDateFormat("MM/dd/YY");
               String current_date=simpleDateFormat.format(c.getTime());
               String selected_date=addServiceDateEditText.getText().toString();

               Log.d("value1","selected date"+selected_date);
                Log.d("value2","current date"+current_date);


                int hour=mHour,min=mMinute;
                TimePickerDialog mTimePicker = new TimePickerDialog(context,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {



                                Calendar c = Calendar.getInstance();
                                Calendar datetime = Calendar.getInstance();
                                datetime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                                datetime.set(Calendar.MINUTE, minute);

                            int value=current_date.compareTo(selected_date);
                            Log.d("value","if cotd."+value);
                                    if (current_date.compareTo(selected_date)==0){

                                        //Toast.makeText(context, "Same date", Toast.LENGTH_SHORT).show();

                                if(datetime.getTimeInMillis() >= c.getTimeInMillis()) {

                                    addServiceTimeEditText.setText(hourOfDay + ":" + minute);


                                    if(minute<10){
                                        addServiceTimeEditText.setText(hourOfDay + " : 0" + minute);
                                    }else {
                                        addServiceTimeEditText.setText(hourOfDay + " : " + minute);
                                    }
                                    serviceDetails.setExpectingtime(addServiceTimeEditText.getText().toString());
                                    if(myServiceDetailsObj==null)
                                    {
                                        serviceDetails.setRemindarTime(null);
                                        serviceDetails.setRemindarDate(null);

                                    }
                                    addNotificationDays.setVisibility(View.VISIBLE);
                                    addReminderTextView.setVisibility(View.GONE);

                                    NotificationAlarmManager.setNotificationTime(context,serviceDetails,addNotificationDays);

                                }else {

                                    if(minute<10){
                                        addServiceTimeEditText.setText(hour+1 + " : 0" + min);
                                    }else {
                                        addServiceTimeEditText.setText(hour+1 + " : " + min);
                                    }

                                    Toast.makeText(context, "Invalid time please reselect", Toast.LENGTH_LONG).show();
                                }
                                    }else{

                                        addServiceTimeEditText.setText(hourOfDay + ":" + minute);


                                        if(minute<10){
                                            addServiceTimeEditText.setText(hourOfDay + " : 0" + minute);
                                        }else {
                                            addServiceTimeEditText.setText(hourOfDay + " : " + minute);
                                        }
                                        serviceDetails.setExpectingtime(addServiceTimeEditText.getText().toString());
                                        if(myServiceDetailsObj==null)
                                        {
                                            serviceDetails.setRemindarTime(null);
                                            serviceDetails.setRemindarDate(null);

                                        }
                                        addNotificationDays.setVisibility(View.VISIBLE);
                                        addReminderTextView.setVisibility(View.GONE);

                                        NotificationAlarmManager.setNotificationTime(context,serviceDetails,addNotificationDays);
                                    }



                            }
                        }, mHour, mMinute, false);

                mTimePicker.show();
            }
        });
        //sach - time changed event
        addServiceTimeEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                serviceDetails.setExpectingtime(s.toString());
                if(myServiceDetailsObj==null)
                {
                    serviceDetails.setRemindarTime(null);
                    serviceDetails.setRemindarDate(null);

                }
                addNotificationDays.setVisibility(View.VISIBLE);
                addReminderTextView.setVisibility(View.GONE);

                NotificationAlarmManager.setNotificationTime(context,serviceDetails,addNotificationDays);
            }
        });


        //sach - Date add edit text
        DatePickerDialog.OnDateSetListener addserviceDateListener = CustomDateTimePicker.getCustomDatePicker(addServiceDateEditText, null, myCalendar);

        addServiceDateEditText.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                DatePickerDialog datePicker=new DatePickerDialog(context, addserviceDateListener,
                        myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                datePicker.getDatePicker().setMinDate(new Date().getTime());
                datePicker.setCancelable(false);
                datePicker.show();
            }
        });
        //sach - Date changed event
        addServiceDateEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                serviceDetails.setExpectingServiceDate(s.toString());
                serviceDetails.setRemindarTime(null);
                serviceDetails.setRemindarDate(null);

                addNotificationDays.setVisibility(View.VISIBLE);
                addReminderTextView.setVisibility(View.GONE);

                NotificationAlarmManager.setNotificationTime(context,serviceDetails,addNotificationDays);
            }
        });

        //sach - Reminder edit text
        addNotificationDays.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(!s.toString().isEmpty()) {
         //           notificationLinear.setVisibility(View.VISIBLE);
                    addNotificationDays.setVisibility(View.VISIBLE);
                    addReminderTextView.setVisibility(View.GONE);
                    String myFormat = "MM/dd/yy"; //In which you need put here
                    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                    try {
                        serviceDetails.setRemindarDate(sdf.format(new Date(s.toString())));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    String myFormat1 = "HH:mm"; //In which you need put here
                    SimpleDateFormat sdf1 = new SimpleDateFormat(myFormat1, Locale.US);
                    Log.d("timesss:",s+"");
                    serviceDetails.setRemindarTime(sdf1.format(new Date(s.toString())));
                }
                else
                {
                //    notificationLinear.setVisibility(View.GONE);
                    addNotificationDays.setVisibility(View.GONE);
                    addReminderTextView.setVisibility(View.VISIBLE);
                }


            }
        });
        updateLabel(addServiceDateEditText,myCalendar);
        serviceDetails.setExpectingServiceDate(addServiceDateEditText.getText().toString().replaceAll("\\s+",""));
        Log.d("Notification Time problrm:",serviceDetails.getExpectingServiceDate()+" time:"+serviceDetails.getExpectingtime());
        if(myServiceDetailsObj==null)
        {
            NotificationAlarmManager.setNotificationTime(context,serviceDetails,addNotificationDays);
        }

        addNotificationDays.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_LEFT = 0;
                final int DRAWABLE_TOP = 1;
                final int DRAWABLE_RIGHT = 2;
                final int DRAWABLE_BOTTOM = 3;

                if(event.getAction() == MotionEvent.ACTION_UP) {
                    if(event.getRawX() >= (addNotificationDays.getRight() - addNotificationDays.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {
                        addNotificationDays.setVisibility(View.GONE);
                        addReminderTextView.setVisibility(View.VISIBLE);
                        //notificationLinear.setVisibility(View.GONE);
                        //new NotificationAlarmManager().cancelAlarmManager(serviceDetails.getRequestCode(),context); //sach commented and updated as below
                        new NotificationAlarmManager().cancelAlarmManager((int) serviceDetails.getRequestUID().getLeastSignificantBits(),context);
                      //  addReminderTextView.setText("Add Remindar");

                        return true;
                    }
                }

                return false;

            }
        });


        addNotificationDays.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serviceDetails.setExpectingServiceDate(addServiceDateEditText.getText().toString());
                serviceDetails.setExpectingtime(addServiceTimeEditText.getText().toString());
                serviceDetails.setSubmissionDate(currentDateandTime);
                serviceDetails.setComments(serviceDescription.getText().toString());
                serviceDetails.setTitle(addServiceNameTextView.getText().toString());
                serviceDetails.setProgramName(programDescriptionList.getSelectedItem().toString());
                serviceDetails.setServiceName(serviceDescriptionList.getSelectedItem().toString());
                serviceDetails.setProgramID(String.valueOf(serviceDetails.getOrganizationDescription().getProgramUIDList().get(programDescriptionList.getSelectedItemPosition())));
                serviceDetails.setServiceID(serviceDetails.getOrganizationDescription().getServiceUIDList().get(programDescriptionList.getSelectedItemPosition()).get(serviceDescriptionList.getSelectedItemPosition()));

                if(myServiceDetailsObj==null) {
                    ArrayList<String> statusArrayList = new ArrayList<String>();
                    statusArrayList.add(context.getString(R.string.pending_status_service_request));
                    statusArrayList.add(context.getString(R.string.order_in_progress_status_service_request));
                    serviceDetails.setStatusArray(statusArrayList);
                }
                NotificationAlarmManager.addNotificationEventCalendarServiceDetails(context,serviceDetails,addNotificationDays,addReminderTextView);
                if(serviceDetails!=null && serviceDetails.getRemindarTime()!=null && serviceDetails.getRemindarDate()!=null)
                {
                }

            }
        });

        addReminderTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                serviceDetails.setExpectingServiceDate(addServiceDateEditText.getText().toString());
                serviceDetails.setExpectingtime(addServiceTimeEditText.getText().toString());
                serviceDetails.setSubmissionDate(currentDateandTime);
                serviceDetails.setComments(serviceDescription.getText().toString());
                serviceDetails.setTitle(addServiceNameTextView.getText().toString());
                serviceDetails.setProgramName(programDescriptionList.getSelectedItem().toString());//sach updated with context | context removed and updated back to previous version 2020-02-06 | serviceCategory > programName
                serviceDetails.setServiceName(serviceDescriptionList.getSelectedItem().toString()); //sach changed serviceProgram>setServiceName
                serviceDetails.setProgramID(String.valueOf(serviceDetails.getOrganizationDescription().getProgramUIDList().get(programDescriptionList.getSelectedItemPosition())));//sach added
                serviceDetails.setServiceID(serviceDetails.getOrganizationDescription().getServiceUIDList().get(programDescriptionList.getSelectedItemPosition()).get(serviceDescriptionList.getSelectedItemPosition()));//sach added
                if(myServiceDetailsObj==null)
                {
                    //serviceDetails.setStatus(context.getString(R.string.pending_status_service_request));//sach commented since no status attribute in object
                    //serviceDetails.setRequestCode((int) serviceDetails.getRequestUID().getLeastSignificantBits());//sach changed getServiceID>getRequestUID | sach commented no requestCode attribute
                    Log.d("sach_LDS_requestCode_reminder ", String.valueOf(serviceDetails.getRequestUID().getLeastSignificantBits()));//sach changed getServiceID>getRequestUID
                    ArrayList<String> statusArrayList = new ArrayList<String>();
                    //sach this is where you have to update status array
                    statusArrayList.add(context.getString(R.string.pending_status_service_request));
                    statusArrayList.add(context.getString(R.string.order_in_progress_status_service_request));

                    serviceDetails.setStatusArray(statusArrayList);
                    //serviceDetails.setDateArray(DateArrayList); //sach commented since no dateArray in service obj

                }
                NotificationAlarmManager.addNotificationEventCalendarServiceDetails(context,serviceDetails,addNotificationDays,addReminderTextView);
                if(serviceDetails!=null && serviceDetails.getRemindarTime()!=null && serviceDetails.getRemindarDate()!=null)
                {
                }

            }
        });


        //sach - Submit button clicked

        Button submit = (Button) dialog.findViewById(R.id.dialog_submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(addServiceNameTextView.getText().toString().isEmpty()) {
                    Toast.makeText(context, "Please enter a title", Toast.LENGTH_SHORT).show();//sach added , context > dialog.getContext()
                }else {
                    if (myServiceDetailsObj == null) {

                        Log.d("sach_LDS_requestCode", String.valueOf(serviceDetails.getRequestUID().getLeastSignificantBits()));//sach changed getServiceID>getRequestUID

                        ArrayList<String> statusArrayList = new ArrayList<String>();

                        statusArrayList.add(context.getString(R.string.pending_status_service_request));
                        statusArrayList.add(context.getString(R.string.order_in_progress_status_service_request));
                        serviceDetails.setStatusArray(statusArrayList);

                    }
                    serviceDetails.setExpectingServiceDate(addServiceDateEditText.getText().toString());
                    serviceDetails.setExpectingtime(addServiceTimeEditText.getText().toString());
                    serviceDetails.setSubmissionDate(currentDateandTime);
                    serviceDetails.setComments(serviceDescription.getText().toString());
                    serviceDetails.setTitle(addServiceNameTextView.getText().toString());
                    serviceDetails.setProgramName(programDescriptionList.getSelectedItem().toString());
                    serviceDetails.setServiceName(serviceDescriptionList.getSelectedItem().toString());
                    serviceDetails.setProgramID(String.valueOf(serviceDetails.getOrganizationDescription().getProgramUIDList().get(programDescriptionList.getSelectedItemPosition())));
                    serviceDetails.setServiceID(serviceDetails.getOrganizationDescription().getServiceUIDList().get(programDescriptionList.getSelectedItemPosition()).get(serviceDescriptionList.getSelectedItemPosition()));

//                    final File file = new File(url, context.getString(R.string.serviceDetails));
                    try {
//                        ArrayList<ServiceDetails> sdList;
//                        if (file.exists()) {
//                            FileInputStream fileInputStream = new FileInputStream(file);
//                            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
//                            sdList = (ArrayList<ServiceDetails>) objectInputStream.readObject();
//                            objectInputStream.close();
//                            fileInputStream.close();
//                            if (sdList != null) {
//                                sdList.add(0, serviceDetails);
//                            } else {
//                                sdList = new ArrayList<ServiceDetails>();
//                                sdList.add(0, serviceDetails);
//                            }
//                        } else {
//                            sdList = new ArrayList<ServiceDetails>();
//                            sdList.add(0, serviceDetails);
//                        }

                        /*
                        sach Here add object mapper ? - No
                         */
                        //sach sDList - this saves a list of all submitted service requests , new request added to '0'th index
//                        Log.d("sach_LDS_sdList:", String.valueOf(sdList));
//                        FileOutputStream fileOutputStream;
//                        ObjectOutputStream objectOutputStream;
//                        fileOutputStream = context.openFileOutput(file.getName(), Context.MODE_PRIVATE);
//                        Log.d("sach_LDS_filename:", file.getName());
//                        objectOutputStream = new ObjectOutputStream(fileOutputStream);
//                        objectOutputStream.writeObject(sdList);
//                        objectOutputStream.close();
//                        fileOutputStream.flush();
//                        fileOutputStream.close();
//                        Log.d("sach_LDS_sdListSize:", String.valueOf(sdList.size()));

                    // sending form data to backend
                    SharedPreferences sp = context.getSharedPreferences("MobileClient", Context.MODE_PRIVATE);
                    int local_user_id = sp.getInt("MobileClientID", 0);
                    if (local_user_id != 0) {
                        ServiceRequest serviceReq = new ServiceRequest();
                        serviceReq.setDescriptiveTitle(serviceDetails.getTitle());
                        serviceReq.setRequestUID(String.valueOf(serviceDetails.getRequestUID()));
                        serviceReq.setComments(serviceDetails.getComments());
                        serviceReq.setAttachments("Attachments here if exists (not yet available) ");
                        serviceReq.setEligibility("Eligibility criteria here (not yet available ) ");
                        serviceReq.setOrganizationId(Integer.parseInt(serviceDetails.getOrganizationDescription().getOrganizationID()));
                        serviceReq.setUserID(local_user_id);
                        serviceReq.setRequestDate(serviceDetails.getExpectingServiceDate());
                        serviceReq.setRequestTime(serviceDetails.getExpectingtime());
                        serviceReq.setServiceId(Integer.parseInt(serviceDetails.getServiceID()));
                        ObjectMapper mapper1 = new ObjectMapper();
                        String dataToSend = mapper1.writeValueAsString(serviceReq);

                        // Sending to backend
                        new HttpServiceRequestHandler().execute(dataToSend);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

                    Toast.makeText(context,"Service Request Submitted!",Toast.LENGTH_SHORT).show();//sach copied here
                    dialog.dismiss();
                }



            }
        });
        dialog.show();


    }

    //sach_added to show sach_services_card_view
    public  static void sachAddServiceObj(Context context,OrganizationDescription organizationDescription,ServiceDetails myServiceDetailsObj,String title){
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.sach_services_card_view);
        dialog.setTitle("Add New Service");
        int width = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.90);
        dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        TextView titleTextView = (TextView) dialog.findViewById(R.id.dialogue_servicetitle);
        TextView serviceDescriptionTextView = (TextView) dialog.findViewById(R.id.service_description);
        TextView serviceEligibilityTextView = (TextView) dialog.findViewById(R.id.Eligibility);
        TextView serviceSpecificHoursTextView = (TextView) dialog.findViewById(R.id.Specific_Hours);
        TextView serviceAdditionalRequirementTextView = (TextView) dialog.findViewById(R.id.Additional_Requirements);
        Button backButton = (Button) dialog.findViewById(R.id.dialog_backButton) ;

        titleTextView.setText(title);
        dialog.show();

        Spinner serviceSpinner = (Spinner) dialog.findViewById(R.id.service_spinnerview);
        if(organizationDescription.getServiceList()!=null){
            int index = organizationDescription.getProgramList().indexOf(title);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context,android.R.layout.simple_spinner_item,organizationDescription.getServiceList().get(index));
            serviceSpinner.setAdapter(arrayAdapter);
            serviceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    String description = organizationDescription.getServiceArrayDescription().get(index).get(position);
                    serviceDescriptionTextView.setText(description);
                    String eligibility = organizationDescription.getServiceArrayEligibility().get(index).get(position);
                    serviceEligibilityTextView.setText("Eligibility : " + eligibility );
                    String specificHours = organizationDescription.getServiceArraySpecificHours().get(index).get(position);
                    serviceSpecificHoursTextView.setText("Specific Hours : " + specificHours);
                    String additionalRequirement = organizationDescription.getServiceArrayAdditionalReq().get(index).get(position);
                    serviceAdditionalRequirementTextView.setText("Additional Requirements : " + additionalRequirement);
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            backButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

        }


    }

    private static void updateLabel(EditText addServiceDateEditText,Calendar myCalendar) {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        addServiceDateEditText.setText(sdf.format(myCalendar.getTime()));

    }

    private void addServciceToFile(ServiceDetails serviceDetails,Context context) {
        String url = context.getFilesDir().toString();
        final File file = new File(url, "serviceDetails");
        try {
            ArrayList<ServiceDetails> sdList;
            if(file.exists())
            {
                FileInputStream fileInputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
                sdList=(ArrayList<ServiceDetails>)objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                if (sdList!=null)
                {
                    int i=-1;
                    for (i=0;i<sdList.size();i++)
                    {
                        if (serviceDetails.getRequestUID().equals(sdList.get(i).getRequestUID()))//sach changed getServiceID>getRequestUID

                        {
                            break;
                        }
                    }
                    if (i>=0)
                    {
                        sdList.remove(i);
                    }
                    sdList.add(0,serviceDetails);
                }
                else
                {
                    sdList=new ArrayList<ServiceDetails>();
                    sdList.add(0,serviceDetails);
                }
            }
            else
            {
                sdList=new ArrayList<ServiceDetails>();
                sdList.add(0,serviceDetails);
            }
            FileOutputStream fileOutputStream;
            ObjectOutputStream objectOutputStream;
            fileOutputStream = context.openFileOutput(file.getName(), Context.MODE_PRIVATE);
            Log.d("sach_LDS_filename:",file.getName());
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(sdList);
            objectOutputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
