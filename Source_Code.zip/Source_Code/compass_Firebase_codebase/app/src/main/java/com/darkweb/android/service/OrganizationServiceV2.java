package com.darkweb.android.service;

import android.content.Context;
import android.content.Intent;

import com.darkweb.android.compass.R;
import com.darkweb.android.compass.ViewServices;
import com.darkweb.android.compass.fragments.ViewServicesNew;
import com.darkweb.android.model.ObjectsForMapper.Organization;
import com.darkweb.android.parser.HttpFetchOrganizationsList;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

public class OrganizationServiceV2 {

    private Context mContext;

    public OrganizationServiceV2(Context mContext) {
        this.mContext = mContext;
    }

    /**
     * Fetching organizations list from backend server
     * @return the list of organizations
     * @throws IOException
     */
    public List<Organization> getOrganizationsFromBackend() throws IOException {
        return HttpFetchOrganizationsList.initOrganizationList();
    }

    // render the list of organizations to the Google map
    public void renderListToMap(List<Organization> organizations, GoogleMap mMap) {
        for (Organization organization : organizations) {
            LatLng latLng = new LatLng(organization.getLatitude(), organization.getLongitude());
            if (mMap != null) {
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.circle10));
                markerOptions.title(organization.getName());
                // TODO: Taking organization category out of sub services
                String organization_categories = "Place holder";
                markerOptions.snippet(organization_categories);
                mMap.addMarker(markerOptions);
            }
        }
        assert mMap != null;
        mMap.setOnMarkerClickListener(marker -> {
            marker.showInfoWindow();
            return false;
        });
        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                Organization organization =
                        getOrganizationByMarkerTitle(marker.getTitle(), organizations);
                if (organization != null) {
                     Intent intent = new Intent(mContext, ViewServicesNew.class);
                     intent.putExtra("organizationObj", organization);
                     mContext.startActivity(intent);
                }
            }
        });
    }

    private Organization getOrganizationByMarkerTitle(String title, List<Organization> organizations) {
        for (Organization organization : organizations) {
            if (organization.getName().equalsIgnoreCase(title)) {
                return organization;
            }
        }
        return null;
    }
}
