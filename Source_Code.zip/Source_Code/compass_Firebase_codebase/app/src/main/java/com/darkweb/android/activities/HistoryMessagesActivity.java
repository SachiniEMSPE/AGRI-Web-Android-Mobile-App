package com.darkweb.android.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.darkweb.android.adapter.HistoryMessagesListAdapter;
import com.darkweb.android.compass.R;
import com.darkweb.android.model.MessageMapper.HistoryMessage;
import com.darkweb.android.service.HttpHandlers.HttpHistoryMessagesHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;
import java.util.concurrent.ExecutionException;

public class HistoryMessagesActivity extends AppCompatActivity {

    private List<HistoryMessage> historyMessages;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_messages);
        ListView historyMessagesListView = findViewById(R.id.history_message_listView);


        Intent intent = getIntent();
        String clientId = intent.getStringExtra("clientId");
        try {
            String MsgJson = new HttpHistoryMessagesHandler().execute(clientId).get();
            ObjectMapper mapper = new ObjectMapper();
            historyMessages =
                    mapper.readValue(MsgJson, new TypeReference<List<HistoryMessage>>() {});

            HistoryMessagesListAdapter adapter = new HistoryMessagesListAdapter(this,
                    R.layout.history_messages_adapter_view_layout,
                    historyMessages);
            historyMessagesListView.setAdapter(adapter);

            historyMessagesListView.setOnItemClickListener(((adapterView, view, i, l) -> {
                String organizationId = String.valueOf(historyMessages.get(i).getOrganizationId());
                Intent chatI = new Intent(HistoryMessagesActivity.this, RealtimeChatActivity.class);
                chatI.putExtra("organizationId", organizationId);
                chatI.putExtra("organizationName", historyMessages.get(i).getOrganizationName());
                startActivity(chatI);
            }));

        } catch (JsonProcessingException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

    }
}
