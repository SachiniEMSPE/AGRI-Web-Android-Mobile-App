package com.darkweb.android.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.darkweb.android.model.Message;
import com.darkweb.android.compass.R;

import java.text.DateFormat;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by kotak on 18/04/2018.
 */

public class MessageListAdapter extends RecyclerView.Adapter {
    private static final int VIEW_TYPE_MESSAGE_SENT = 1;
    private static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;
    DateFormat dateFormat=DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT);

    private Context mContext;
    private List<Message> mMessageList;
    private String userName;
    private String organizatioName;
    private String authorName;

    public MessageListAdapter(Context context, List<Message> messageList, String userName, String organizatioName ,String authorName) {
        this.userName=userName;
        mContext = context;
        mMessageList = messageList;
        this.organizatioName=organizatioName;
        this.userName=userName;
        this.authorName=authorName;
    }



    public Message messageContent(int position)
    {
        return mMessageList.get(position);
    }

    @Override
    public int getItemCount() {
        return mMessageList.size();
    }

    // Determines the appropriate ViewType according to the sender of the message.
    @Override
    public int getItemViewType(int position) {
        try {
            Message message = (Message) mMessageList.get(position);
            if (message != null && message.getMessageAuthor() != null) {

              //  Log.d("name:", message.getContent());
                if (message.getMessageAuthor().equals(authorName)) {
                    // If the current user is the sender of the message

                    return VIEW_TYPE_MESSAGE_SENT;
                } else {
                    // If some other user sent the message
                    return VIEW_TYPE_MESSAGE_RECEIVED;
                }
            }
            //not needed
            if (message != null &&  !message.getMessageAuthor().equals(authorName))
            {

                return  VIEW_TYPE_MESSAGE_RECEIVED;
            }
        }catch (Exception e)
        {
            return VIEW_TYPE_MESSAGE_SENT;
        }
        return VIEW_TYPE_MESSAGE_SENT;
    }

    // Inflates the appropriate layout according to the ViewType.
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;

        if (viewType == VIEW_TYPE_MESSAGE_SENT) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message_sent, parent, false);
            return new SentMessageHolder(view);
        } else if (viewType == VIEW_TYPE_MESSAGE_RECEIVED) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message_received, parent, false);
            return new ReceivedMessageHolder(view);
        }

        return null;
    }

    // Passes the message object to a ViewHolder so that the contents can be bound to UI.
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Message message = (Message) mMessageList.get(position);

        switch (holder.getItemViewType()) {
            case VIEW_TYPE_MESSAGE_SENT:
                ((SentMessageHolder) holder).bind(message);
                break;
            case VIEW_TYPE_MESSAGE_RECEIVED:
                ((ReceivedMessageHolder) holder).bind(message);
        }
    }

    private class SentMessageHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText,messageStatus;

        SentMessageHolder(View itemView) {
            super(itemView);

            messageText = (TextView) itemView.findViewById(R.id.text_message_body);
            timeText = (TextView) itemView.findViewById(R.id.text_message_time);
            messageStatus=(TextView) itemView.findViewById(R.id.text_message_status);
        }

        void bind(Message message) {
            messageText.setText(message.getMessageText());

           timeText.setText(dateFormat.format(message.getCreatedDate()));
           if (message.getMessageStatus())
                messageStatus.setText("");
           else
               messageStatus.setText(mContext.getString(R.string.message_status_sending));
        }
    }

    private class ReceivedMessageHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText, nameText;
        //ImageView profileImage;

        ReceivedMessageHolder(View itemView) {
            super(itemView);

            messageText = (TextView) itemView.findViewById(R.id.text_message_body);
            timeText = (TextView) itemView.findViewById(R.id.text_message_time);
               nameText = (TextView) itemView.findViewById(R.id.text_message_name);
            //profileImage = (ImageView) itemView.findViewById(R.id.image_message_profile);
        }

        void bind(Message message) {
            messageText.setText(message.getMessageText());
            timeText.setText(dateFormat.format(message.getCreatedDate()));
            nameText.setText("");
          /*  if(message.getMessageAuthor()!=null)
                nameText.setText(message.getMessageAuthor());
          */  /*else if (message.getUsername()!=null)
                nameText.setText(message.getUsername());*/
        }
    }
}