package com.darkweb.android.global;

public class UserStatus {
    private int userId;
    private boolean LoginStatus;

    public UserStatus() {
        this.userId = -1;
        LoginStatus = false;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public boolean getLoginStatus() {
        return LoginStatus;
    }

    public void setLoginStatus(boolean loginStatus) {
        LoginStatus = loginStatus;
    }
}
